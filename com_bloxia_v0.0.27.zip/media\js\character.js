import * as THREE from './three/three.module.js';

export const CHARACTER_SKINS = [
    { id: 'none', name: 'شخصی‌سازی آزاد', icon: '🎨' },
    { id: 'batman', name: 'بتمن', icon: '🦇' },
    { id: 'superman', name: 'سوپرمن', icon: '🦸' },
    { id: 'green_lantern', name: 'گرین لنترن', icon: '💚' },
    { id: 'spiderman', name: 'اسپایدرمن', icon: '🕷️' },
    { id: 'rick', name: 'ریک (Rick)', icon: '🧪' },
    { id: 'morty', name: 'مورتی (Morty)', icon: '😰' },
    { id: 'dr_strange', name: 'دکتر استرنج', icon: '🔮' },
    { id: 'tanjiro', name: 'تانجیرو (شیطان‌کش)', icon: '🌊' },
    { id: 'nezuko', name: 'نزوکو (شیطان‌کش)', icon: '🎋' },
    { id: 'zenitsu', name: 'زنیتسو (شیطان‌کش)', icon: '⚡' },
    { id: 'inosuke', name: 'اینوسکه (شیطان‌کش)', icon: '🐗' }
];

export const CHARACTER_MOODS = [
    { id: 'happy', name: 'خوشحال', icon: '😊' },
    { id: 'excited', name: 'ذوق‌زده', icon: '🤩' },
    { id: 'angry', name: 'عصبانی', icon: '😠' },
    { id: 'sad', name: 'ناراحت', icon: '😢' },
    { id: 'surprised', name: 'متعجب', icon: '😮' }
];

function createCheckerHaoriTexture() {
    const c = document.createElement('canvas');
    c.width = c.height = 128;
    const g = c.getContext('2d');
    for (let y = 0; y < 4; y++) {
        for (let x = 0; x < 4; x++) {
            g.fillStyle = (x + y) % 2 === 0 ? '#10b981' : '#111827';
            g.fillRect(x * 32, y * 32, 32, 32);
        }
    }
    const t = new THREE.CanvasTexture(c);
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.repeat.set(2, 2);
    if ('SRGBColorSpace' in THREE) t.colorSpace = THREE.SRGBColorSpace;
    return t;
}

function createZenitsuTexture() {
    const c = document.createElement('canvas');
    c.width = c.height = 128;
    const g = c.getContext('2d');
    const grad = g.createLinearGradient(0, 0, 0, 128);
    grad.addColorStop(0, '#facc15');
    grad.addColorStop(1, '#f97316');
    g.fillStyle = grad;
    g.fillRect(0, 0, 128, 128);
    g.fillStyle = '#ffffff';
    [[32, 32], [96, 32], [64, 84], [16, 96], [112, 96]].forEach(([cx, cy]) => {
        g.beginPath();
        g.moveTo(cx, cy - 12);
        g.lineTo(cx + 12, cy + 10);
        g.lineTo(cx - 12, cy + 10);
        g.closePath();
        g.fill();
    });
    const t = new THREE.CanvasTexture(c);
    if ('SRGBColorSpace' in THREE) t.colorSpace = THREE.SRGBColorSpace;
    return t;
}

export function buildHairMesh(style, hairMat) {
    const group = new THREE.Group();

    const cap = new THREE.Mesh(
        new THREE.SphereGeometry(0.41, 24, 18, 0, Math.PI * 2, 0, Math.PI * 0.48),
        hairMat
    );
    cap.scale.set(1.04, 1.06, 1.06);
    cap.position.set(0, 0.05, -0.02);
    cap.rotation.x = -0.14;
    cap.castShadow = true;
    group.add(cap);

    if (style === 'spiky_rick') {
        for (let i = 0; i < 11; i++) {
            const a = (i / 11) * Math.PI * 1.65 + 0.75;
            const spike = new THREE.Mesh(new THREE.ConeGeometry(0.14, 0.44, 8), hairMat);
            spike.position.set(Math.sin(a) * 0.36, 0.24 + (i % 2) * 0.12, Math.cos(a) * 0.24 - 0.08);
            spike.rotation.z = -Math.sin(a) * 0.85;
            spike.rotation.x = Math.cos(a) * 0.55 - 0.2;
            group.add(spike);
        }
        const topSpike = new THREE.Mesh(new THREE.ConeGeometry(0.15, 0.48, 8), hairMat);
        topSpike.position.set(0, 0.52, -0.05);
        group.add(topSpike);
        return group;
    }

    if (style === 'spiky_anime') {
        for (let i = 0; i < 9; i++) {
            const a = (i / 9) * Math.PI * 2;
            const tuft = new THREE.Mesh(new THREE.ConeGeometry(0.15, 0.36, 8), hairMat);
            tuft.position.set(Math.sin(a) * 0.32, 0.28 + (i % 2) * 0.08, Math.cos(a) * 0.3);
            tuft.rotation.z = -Math.sin(a) * 0.65;
            tuft.rotation.x = Math.cos(a) * 0.55;
            group.add(tuft);
        }
        return group;
    }

    const quiffMain = new THREE.Mesh(new THREE.CapsuleGeometry(0.14, 0.24, 8, 14), hairMat);
    quiffMain.rotation.z = 1.25;
    quiffMain.rotation.y = 0.2;
    quiffMain.position.set(0.02, 0.36, 0.23);
    quiffMain.castShadow = true;

    const quiffSide = new THREE.Mesh(new THREE.SphereGeometry(0.13, 14, 12), hairMat);
    quiffSide.scale.set(1.3, 0.65, 0.85);
    quiffSide.position.set(-0.17, 0.31, 0.25);
    group.add(quiffMain, quiffSide);

    [-0.36, 0.36].forEach(sx => {
        const sideburn = new THREE.Mesh(new THREE.CapsuleGeometry(0.045, 0.14, 6, 10), hairMat);
        sideburn.position.set(sx, 0.08, 0.08);
        group.add(sideburn);
    });

    if (style === 'short') {
        const back = new THREE.Mesh(new THREE.SphereGeometry(0.38, 20, 16), hairMat);
        back.scale.set(1.02, 1.02, 0.78);
        back.position.set(0, 0.03, -0.14);
        back.castShadow = true;
        group.add(back);
    } else if (style === 'long') {
        const backLong = new THREE.Mesh(new THREE.CapsuleGeometry(0.34, 0.62, 10, 18), hairMat);
        backLong.scale.set(1.12, 1.0, 0.62);
        backLong.position.set(0, -0.28, -0.23);
        backLong.castShadow = true;

        const strandL = new THREE.Mesh(new THREE.CapsuleGeometry(0.085, 0.46, 8, 12), hairMat);
        strandL.position.set(-0.36, -0.22, 0.07);
        strandL.rotation.z = 0.1;

        const strandR = strandL.clone();
        strandR.position.x = 0.36;
        strandR.rotation.z = -0.1;

        group.add(backLong, strandL, strandR);
    } else if (style === 'ponytail') {
        const tieMat = new THREE.MeshStandardMaterial({ color: 0xf43f5e, roughness: 0.35 });
        const hairTie = new THREE.Mesh(new THREE.TorusGeometry(0.115, 0.042, 10, 18), tieMat);
        hairTie.position.set(0, 0.17, -0.39);
        hairTie.rotation.x = Math.PI / 2.4;

        const tail = new THREE.Mesh(new THREE.CapsuleGeometry(0.14, 0.48, 10, 14), hairMat);
        tail.position.set(0, -0.06, -0.52);
        tail.rotation.x = 0.42;
        tail.castShadow = true;

        group.add(hairTie, tail);
    } else if (style === 'curly') {
        const puffCoords = [
            [-0.29, 0.29, 0.14], [0.29, 0.29, 0.14], [0, 0.41, 0.1],
            [-0.37, 0.15, -0.08], [0.37, 0.15, -0.08], [-0.27, 0.29, -0.23],
            [0.27, 0.29, -0.23], [0, 0.36, -0.27], [-0.23, 0.02, -0.32],
            [0.23, 0.02, -0.32], [0, 0.04, -0.36]
        ];
        puffCoords.forEach(([px, py, pz]) => {
            const puff = new THREE.Mesh(new THREE.SphereGeometry(0.16, 14, 12), hairMat);
            puff.position.set(px, py, pz);
            puff.castShadow = true;
            group.add(puff);
        });
    }

    return group;
}

export function buildHandPropMesh(propId) {
    const group = new THREE.Group();
    if (propId === 'prop_sword') {
        const hilt = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.05, 0.28, 12), new THREE.MeshStandardMaterial({ color: 0x78350f }));
        const pommel = new THREE.Mesh(new THREE.SphereGeometry(0.075, 12, 12), new THREE.MeshStandardMaterial({ color: 0xfbbf24, metalness: 0.75, roughness: 0.25 }));
        pommel.position.y = -0.15;
        const guard = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.08, 0.14), new THREE.MeshStandardMaterial({ color: 0xfbbf24, metalness: 0.75, roughness: 0.25 }));
        guard.position.y = 0.15;
        const blade = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.94, 0.045), new THREE.MeshStandardMaterial({ color: 0x38bdf8, emissive: 0x0ea5e9, emissiveIntensity: 0.55, metalness: 0.65, roughness: 0.2 }));
        blade.position.y = 0.64;
        group.add(hilt, pommel, guard, blade);
        group.rotation.x = Math.PI / 2.3;
    } else if (propId === 'prop_axe') {
        const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.045, 1.05, 12), new THREE.MeshStandardMaterial({ color: 0x92400e }));
        handle.position.y = 0.35;
        const head = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.32, 0.09), new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 0.8, roughness: 0.25 }));
        head.position.set(0.14, 0.75, 0);
        group.add(handle, head);
        group.rotation.x = Math.PI / 2.3;
    } else if (propId === 'prop_flower') {
        const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.55, 10), new THREE.MeshStandardMaterial({ color: 0x16a34a }));
        stem.position.y = 0.2;
        const wrap = new THREE.Mesh(new THREE.ConeGeometry(0.16, 0.28, 14, 1, true), new THREE.MeshStandardMaterial({ color: 0xfef3c7, side: THREE.DoubleSide }));
        wrap.position.y = 0.34;
        wrap.rotation.x = Math.PI;
        [0xf43f5e, 0xfacc15, 0xa855f7].forEach((c, i) => {
            const fl = new THREE.Mesh(new THREE.SphereGeometry(0.11, 12, 12), new THREE.MeshStandardMaterial({ color: c, roughness: 0.4 }));
            const a = (i / 3) * Math.PI * 2;
            fl.position.set(Math.cos(a) * 0.09, 0.5, Math.sin(a) * 0.09);
            group.add(fl);
        });
        group.add(stem, wrap);
        group.rotation.x = Math.PI / 3;
    } else if (propId === 'prop_phone') {
        const body = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.42, 0.04), new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.25 }));
        const screen = new THREE.Mesh(new THREE.PlaneGeometry(0.18, 0.35), new THREE.MeshBasicMaterial({ color: 0x38bdf8 }));
        screen.position.z = 0.022;
        group.add(body, screen);
        group.rotation.x = Math.PI / 3;
    }
    return group;
}

export function createCharacterRig(name, appearance, citizenData = null, options = {}) {
    const root = new THREE.Group();
    if (citizenData) root.userData = { citizenData };

    const skinMat = new THREE.MeshStandardMaterial({ color: appearance.skinColor ?? 0xffdbac, roughness: 0.48, metalness: 0.02 });
    const hairMat = new THREE.MeshStandardMaterial({ color: appearance.hairColor ?? 0x451a03, roughness: 0.65 });
    const shirtMat = new THREE.MeshStandardMaterial({ color: appearance.shirtColor ?? 0x3b82f6, roughness: 0.58 });
    const pantsMat = new THREE.MeshStandardMaterial({ color: appearance.pantsColor ?? 0x1e293b, roughness: 0.68 });
    const shoesMat = new THREE.MeshStandardMaterial({ color: appearance.shoesColor || 0xf8fafc, roughness: 0.35 });
    const whiteTrimMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.4 });

    const contactShadow = new THREE.Mesh(
        new THREE.CircleGeometry(0.55, 24),
        new THREE.MeshBasicMaterial({ color: 0x020617, transparent: true, opacity: 0.26 })
    );
    contactShadow.rotation.x = -Math.PI / 2;
    contactShadow.position.y = 0.02;
    root.add(contactShadow);

    if (citizenData) {
        const ring = new THREE.Mesh(
            new THREE.RingGeometry(0.6, 0.78, 32),
            new THREE.MeshBasicMaterial({ color: 0x38bdf8, side: THREE.DoubleSide, transparent: true, opacity: 0.85 })
        );
        ring.rotation.x = -Math.PI / 2;
        ring.position.y = 0.03;
        root.add(ring);
    }

    // 1. تنه
    const bodyGroup = new THREE.Group();
    bodyGroup.position.y = 1.26;

    const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.33, 0.46, 12, 22), shirtMat);
    torso.scale.set(1.1, 1.0, 0.78);
    torso.castShadow = true;
    bodyGroup.add(torso);

    const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.13, 0.22, 16), skinMat);
    neck.position.set(0, 0.46, 0);
    bodyGroup.add(neck);

    const collar = new THREE.Mesh(new THREE.TorusGeometry(0.18, 0.042, 10, 22), whiteTrimMat);
    collar.rotation.x = Math.PI / 2.15;
    collar.position.set(0, 0.41, 0.02);
    bodyGroup.add(collar);

    const beltMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.5 });
    const belt = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.35, 0.09, 22), beltMat);
    belt.scale.set(1.1, 1.0, 0.8);
    belt.position.y = -0.33;
    const buckle = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.09, 0.06), new THREE.MeshStandardMaterial({ color: 0xfbbf24, metalness: 0.75, roughness: 0.25 }));
    buckle.position.set(0, -0.33, 0.27);
    bodyGroup.add(belt, buckle);

    const chestBadge = new THREE.Mesh(
        new THREE.OctahedronGeometry(0.065, 0),
        new THREE.MeshStandardMaterial({ color: 0xfde047, emissive: 0xf59e0b, emissiveIntensity: 0.35, metalness: 0.5 })
    );
    chestBadge.scale.set(1, 1, 0.35);
    chestBadge.position.set(0.14, 0.16, 0.25);
    bodyGroup.add(chestBadge);

    const bodySkinSlot = new THREE.Group();
    bodyGroup.add(bodySkinSlot);
    root.add(bodyGroup);

    // 2. سر و صورت
    const headGroup = new THREE.Group();
    headGroup.position.y = 2.15;

    const head = new THREE.Mesh(new THREE.SphereGeometry(0.46, 30, 24), skinMat);
    head.scale.set(1.04, 1.06, 0.98);
    head.castShadow = true;
    headGroup.add(head);

    const faceDetailsGroup = new THREE.Group();
    headGroup.add(faceDetailsGroup);

    [-0.44, 0.44].forEach(ex => {
        const ear = new THREE.Mesh(new THREE.SphereGeometry(0.095, 12, 12), skinMat);
        ear.scale.set(0.75, 1.05, 0.85);
        ear.position.set(ex, -0.02, -0.02);
        faceDetailsGroup.add(ear);
    });

    const eyeWhiteMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const irisMat = new THREE.MeshBasicMaterial({ color: 0x1e3a8a });
    const pupilMat = new THREE.MeshBasicMaterial({ color: 0x090d16 });

    const brows = [];
    const eyes = [];
    const tears = [];

    [-0.155, 0.155].forEach(ex => {
        const eyeGroup = new THREE.Group();
        eyeGroup.position.set(ex, 0.03, 0.405);

        const eyeBg = new THREE.Mesh(new THREE.SphereGeometry(0.082, 14, 14), eyeWhiteMat);
        eyeBg.scale.set(0.92, 1.18, 0.5);

        const iris = new THREE.Mesh(new THREE.SphereGeometry(0.058, 14, 14), irisMat);
        iris.scale.set(0.92, 1.15, 0.5);
        iris.position.set(0, 0, 0.023);

        const pupil = new THREE.Mesh(new THREE.SphereGeometry(0.04, 12, 12), pupilMat);
        pupil.scale.set(0.92, 1.15, 0.5);
        pupil.position.set(0, 0, 0.037);

        const shine1 = new THREE.Mesh(new THREE.SphereGeometry(0.021, 8, 8), eyeWhiteMat);
        shine1.position.set(0.02, 0.032, 0.057);
        const shine2 = new THREE.Mesh(new THREE.SphereGeometry(0.01, 8, 8), eyeWhiteMat);
        shine2.position.set(-0.018, -0.02, 0.055);

        eyeGroup.add(eyeBg, iris, pupil, shine1, shine2);
        eyes.push(eyeGroup);

        const brow = new THREE.Mesh(new THREE.CapsuleGeometry(0.024, 0.12, 6, 10), hairMat);
        brow.rotation.z = Math.PI / 2 + (ex < 0 ? 0.1 : -0.1);
        brow.position.set(ex, 0.16, 0.425);
        brows.push({ mesh: brow, side: ex < 0 ? -1 : 1 });

        // قطره اشک برای حالت ناراحت
        const tear = new THREE.Mesh(
            new THREE.SphereGeometry(0.038, 10, 10),
            new THREE.MeshBasicMaterial({ color: 0x38bdf8 })
        );
        tear.scale.set(0.75, 1.35, 0.6);
        tear.position.set(ex * 1.18, -0.055, 0.435);
        tear.visible = false;
        tears.push(tear);

        faceDetailsGroup.add(eyeGroup, brow, tear);
    });

    const blushMat = new THREE.MeshBasicMaterial({ color: 0xfb7185, transparent: true, opacity: 0.45 });
    [-0.24, 0.24].forEach(bx => {
        const blush = new THREE.Mesh(new THREE.CircleGeometry(0.068, 14), blushMat);
        blush.position.set(bx, -0.06, 0.415);
        blush.rotation.y = bx < 0 ? -0.45 : 0.45;
        faceDetailsGroup.add(blush);
    });

    // علامت خشم کمیک روی پیشانی برای حالت عصبانی
    const angerMark = new THREE.Group();
    angerMark.position.set(0.24, 0.22, 0.43);
    const angerMat = new THREE.MeshBasicMaterial({ color: 0xef4444 });
    const a1 = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.032, 0.02), angerMat);
    const a2 = new THREE.Mesh(new THREE.BoxGeometry(0.032, 0.13, 0.02), angerMat);
    angerMark.add(a1, a2);
    angerMark.rotation.z = 0.25;
    angerMark.visible = false;
    faceDetailsGroup.add(angerMark);

    const nose = new THREE.Mesh(new THREE.SphereGeometry(0.038, 12, 12), skinMat);
    nose.scale.set(1.1, 0.85, 1.0);
    nose.position.set(0, -0.025, 0.45);

    const mouthArcMat = new THREE.MeshBasicMaterial({ color: 0x9f1239 });
    const smile = new THREE.Mesh(new THREE.TorusGeometry(0.078, 0.021, 10, 18, Math.PI), mouthArcMat);
    smile.rotation.x = Math.PI;
    smile.position.set(0, -0.105, 0.432);

    const openMouth = new THREE.Mesh(new THREE.CircleGeometry(0.068, 16), new THREE.MeshBasicMaterial({ color: 0x881337 }));
    openMouth.position.set(0, -0.13, 0.438);
    openMouth.visible = false;

    faceDetailsGroup.add(nose, smile, openMouth);

    function applyMood(moodId = 'happy') {
        tears.forEach(t => { t.visible = false; });
        angerMark.visible = false;
        openMouth.visible = false;
        smile.visible = true;
        blushMat.color.setHex(0xfb7185);
        blushMat.opacity = 0.45;
        eyes.forEach(eg => eg.scale.set(1, 1, 1));

        if (moodId === 'angry') {
            brows.forEach(b => {
                b.mesh.position.y = 0.135;
                b.mesh.rotation.z = Math.PI / 2 + (b.side < 0 ? -0.48 : 0.48);
            });
            eyes.forEach(eg => eg.scale.set(1.05, 0.78, 1));
            smile.rotation.x = 0; // لب برعکس اخمو
            smile.position.y = -0.155;
            blushMat.color.setHex(0xef4444);
            blushMat.opacity = 0.65;
            angerMark.visible = true;
        } else if (moodId === 'sad') {
            brows.forEach(b => {
                b.mesh.position.y = 0.175;
                b.mesh.rotation.z = Math.PI / 2 + (b.side < 0 ? 0.46 : -0.46);
            });
            eyes.forEach(eg => eg.scale.set(0.95, 0.88, 1));
            smile.rotation.x = 0; // لب غمگین پایین‌افتاده
            smile.position.y = -0.16;
            tears.forEach(t => { t.visible = true; });
            blushMat.opacity = 0.2;
        } else if (moodId === 'surprised') {
            brows.forEach(b => {
                b.mesh.position.y = 0.21;
                b.mesh.rotation.z = Math.PI / 2;
            });
            eyes.forEach(eg => eg.scale.set(1.18, 1.22, 1));
            smile.visible = false;
            openMouth.visible = true;
            openMouth.scale.set(0.85, 1.15, 1);
        } else if (moodId === 'excited') {
            brows.forEach(b => {
                b.mesh.position.y = 0.195;
                b.mesh.rotation.z = Math.PI / 2 + (b.side < 0 ? 0.16 : -0.16);
            });
            eyes.forEach(eg => eg.scale.set(1.14, 1.16, 1));
            smile.visible = false;
            openMouth.visible = true;
            openMouth.scale.set(1.35, 0.95, 1);
            blushMat.opacity = 0.65;
        } else {
            // happy
            brows.forEach(b => {
                b.mesh.position.y = 0.16;
                b.mesh.rotation.z = Math.PI / 2 + (b.side < 0 ? 0.1 : -0.1);
            });
            smile.rotation.x = Math.PI;
            smile.position.y = -0.105;
        }
    }

    const hairSlot = new THREE.Group();
    hairSlot.scale.setScalar(1.18);
    headGroup.add(hairSlot);

    const headSkinSlot = new THREE.Group();
    headGroup.add(headSkinSlot);

    const hatSlot = new THREE.Group();
    hatSlot.position.y = 0.52;
    hatSlot.scale.setScalar(1.15);
    headGroup.add(hatSlot);
    root.add(headGroup);

    // 3. بازوها
    function buildArm(xPos) {
        const pivot = new THREE.Group();
        pivot.position.set(xPos, 1.62, 0);
        const sleeve = new THREE.Mesh(new THREE.CapsuleGeometry(0.115, 0.12, 8, 14), shirtMat);
        sleeve.position.y = -0.08;
        sleeve.castShadow = true;
        const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.082, 0.34, 8, 14), skinMat);
        arm.position.y = -0.32;
        arm.castShadow = true;
        const hand = new THREE.Mesh(new THREE.SphereGeometry(0.105, 14, 14), skinMat);
        hand.position.y = -0.55;
        pivot.add(sleeve, arm, hand);
        return pivot;
    }

    const leftArmPivot = buildArm(-0.45);
    root.add(leftArmPivot);

    const rightArmPivot = buildArm(0.45);
    const rightHandSlot = new THREE.Group();
    rightHandSlot.position.set(0, -0.61, 0.1);
    rightArmPivot.add(rightHandSlot);
    root.add(rightArmPivot);

    // 4. پاها
    function buildLegWithSneaker(xOffset) {
        const legPivot = new THREE.Group();
        legPivot.position.set(xOffset, 0.84, 0);

        const leg = new THREE.Mesh(new THREE.CapsuleGeometry(0.125, 0.42, 10, 16), pantsMat);
        leg.position.y = -0.28;
        leg.castShadow = true;

        const cuff = new THREE.Mesh(new THREE.TorusGeometry(0.12, 0.032, 8, 16), pantsMat);
        cuff.rotation.x = Math.PI / 2;
        cuff.position.y = -0.52;

        const shoeBody = new THREE.Mesh(new THREE.CapsuleGeometry(0.135, 0.2, 10, 16), shoesMat);
        shoeBody.rotation.x = Math.PI / 2;
        shoeBody.position.set(0, -0.66, 0.06);
        shoeBody.castShadow = true;

        const sole = new THREE.Mesh(new THREE.CapsuleGeometry(0.145, 0.22, 8, 16), whiteTrimMat);
        sole.rotation.x = Math.PI / 2;
        sole.scale.set(1.02, 1.0, 0.42);
        sole.position.set(0, -0.76, 0.06);

        const lace = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.032, 0.14), whiteTrimMat);
        lace.position.set(0, -0.54, 0.11);

        legPivot.add(leg, cuff, shoeBody, sole, lace);
        return legPivot;
    }

    const leftLegPivot = buildLegWithSneaker(-0.175);
    const rightLegPivot = buildLegWithSneaker(0.175);
    root.add(leftLegPivot, rightLegPivot);

    let labelEl = null;
    if (!options.skipDomLabel && typeof document !== 'undefined') {
        const layer = document.getElementById('labels-layer');
        if (layer) {
            labelEl = document.createElement('div');
            labelEl.className = 'floating-label';
            labelEl.innerHTML = `<div class="chat-bubble" style="display:none;"></div><div class="player-tag">${name}</div>`;
            layer.appendChild(labelEl);
        }
    }

    function applySkinPreset(skinId, newApp) {
        bodySkinSlot.clear();
        headSkinSlot.clear();
        faceDetailsGroup.visible = true;
        chestBadge.visible = true;
        collar.visible = true;
        beltMat.color.setHex(0x1e293b);

        const addCape = (hex, collarHex = null) => {
            const capeMat = new THREE.MeshStandardMaterial({ color: hex, roughness: 0.55, side: THREE.DoubleSide });
            const cape = new THREE.Mesh(new THREE.BoxGeometry(0.84, 1.28, 0.05), capeMat);
            cape.position.set(0, -0.22, -0.32);
            cape.rotation.x = 0.14;
            cape.castShadow = true;
            bodySkinSlot.add(cape);
            if (collarHex !== null) {
                const highCollar = new THREE.Mesh(
                    new THREE.CylinderGeometry(0.36, 0.28, 0.34, 16, 1, true, Math.PI * 0.65, Math.PI * 1.7),
                    new THREE.MeshStandardMaterial({ color: collarHex, side: THREE.DoubleSide, roughness: 0.45 })
                );
                highCollar.position.set(0, 0.5, -0.06);
                bodySkinSlot.add(highCollar);
            }
        };

        const addHaori = (mat) => {
            const coat = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.5, 0.92, 20, 1, true, Math.PI * 0.28, Math.PI * 1.44), mat);
            coat.position.set(0, -0.06, -0.02);
            coat.scale.set(1.06, 1, 0.88);
            bodySkinSlot.add(coat);
        };

        if (!skinId || skinId === 'none') {
            return { hairStyle: newApp.hairStyle || 'short', hideHair: false };
        }

        chestBadge.visible = false;

        if (skinId === 'batman') {
            shirtMat.color.setHex(0x334155);
            pantsMat.color.setHex(0x0f172a);
            shoesMat.color.setHex(0x090d16);
            beltMat.color.setHex(0xfacc15);
            collar.visible = false;
            addCape(0x090d16);

            // نشان خفاش زرد-مشکی روی سینه
            const oval = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.16, 0.03, 18), new THREE.MeshStandardMaterial({ color: 0xfacc15 }));
            oval.rotation.x = Math.PI / 2;
            oval.scale.set(1.35, 1, 0.75);
            oval.position.set(0, 0.16, 0.28);
            const bat = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.08, 0.04), new THREE.MeshStandardMaterial({ color: 0x090d16 }));
            bat.position.set(0, 0.16, 0.29);
            bodySkinSlot.add(oval, bat);

            // کلاه‌خود بتمن با گوش‌های تیز و چشمان سفید درخشان
            const cowlMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.4 });
            const cowl = new THREE.Mesh(new THREE.SphereGeometry(0.485, 28, 22, 0, Math.PI * 2, 0, Math.PI * 0.62), cowlMat);
            cowl.scale.set(1.04, 1.06, 1.0);
            headSkinSlot.add(cowl);
            [-0.28, 0.28].forEach(ex => {
                const earHorn = new THREE.Mesh(new THREE.ConeGeometry(0.09, 0.42, 6), cowlMat);
                earHorn.position.set(ex, 0.56, -0.02);
                headSkinSlot.add(earHorn);
            });
            [-0.16, 0.16].forEach(ex => {
                const wEye = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.055, 0.04), new THREE.MeshBasicMaterial({ color: 0xffffff }));
                wEye.position.set(ex, 0.06, 0.475);
                wEye.rotation.z = ex < 0 ? -0.18 : 0.18;
                headSkinSlot.add(wEye);
            });
            return { hideHair: true };
        }

        if (skinId === 'superman') {
            skinMat.color.setHex(0xffdbac);
            hairMat.color.setHex(0x111827);
            shirtMat.color.setHex(0x1d4ed8);
            pantsMat.color.setHex(0x1e40af);
            shoesMat.color.setHex(0xdc2626);
            beltMat.color.setHex(0xfacc15);
            collar.visible = false;
            addCape(0xdc2626);

            const diamond = new THREE.Mesh(new THREE.OctahedronGeometry(0.16, 0), new THREE.MeshStandardMaterial({ color: 0xfacc15 }));
            diamond.scale.set(1.2, 0.95, 0.22);
            diamond.position.set(0, 0.16, 0.27);
            const sMark = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.055, 0.05), new THREE.MeshStandardMaterial({ color: 0xdc2626 }));
            sMark.position.set(0, 0.16, 0.29);
            bodySkinSlot.add(diamond, sMark);

            // طره فر پیشانی سوپرمن
            const curl = new THREE.Mesh(new THREE.TorusGeometry(0.065, 0.022, 8, 14, Math.PI * 1.4), hairMat);
            curl.position.set(0.05, 0.28, 0.44);
            headSkinSlot.add(curl);
            return { hairStyle: 'short', hideHair: false };
        }

        if (skinId === 'green_lantern') {
            skinMat.color.setHex(0xf1c27d);
            hairMat.color.setHex(0x451a03);
            shirtMat.color.setHex(0x16a34a);
            pantsMat.color.setHex(0x090d16);
            shoesMat.color.setHex(0x16a34a);
            collar.visible = false;

            const lanternMat = new THREE.MeshStandardMaterial({ color: 0x4ade80, emissive: 0x22c55e, emissiveIntensity: 0.9 });
            const chestCircle = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 0.03, 20), new THREE.MeshStandardMaterial({ color: 0xffffff }));
            chestCircle.rotation.x = Math.PI / 2;
            chestCircle.position.set(0, 0.16, 0.27);
            const ringSym = new THREE.Mesh(new THREE.TorusGeometry(0.075, 0.022, 8, 18), lanternMat);
            ringSym.position.set(0, 0.16, 0.29);
            bodySkinSlot.add(chestCircle, ringSym);

            const mask = new THREE.Mesh(new THREE.BoxGeometry(0.56, 0.18, 0.12), new THREE.MeshStandardMaterial({ color: 0x15803d, roughness: 0.35 }));
            mask.position.set(0, 0.04, 0.41);
            headSkinSlot.add(mask);
            [-0.155, 0.155].forEach(ex => {
                const gEye = new THREE.Mesh(new THREE.SphereGeometry(0.065, 10, 10), new THREE.MeshBasicMaterial({ color: 0xffffff }));
                gEye.scale.set(1.1, 0.7, 0.4);
                gEye.position.set(ex, 0.04, 0.475);
                headSkinSlot.add(gEye);
            });
            return { hairStyle: 'short', hideHair: false };
        }

        if (skinId === 'spiderman') {
            shirtMat.color.setHex(0xdc2626);
            pantsMat.color.setHex(0x1d4ed8);
            shoesMat.color.setHex(0xdc2626);
            collar.visible = false;
            faceDetailsGroup.visible = false;

            const spMask = new THREE.Mesh(new THREE.SphereGeometry(0.475, 28, 22), new THREE.MeshStandardMaterial({ color: 0xdc2626, roughness: 0.45 }));
            spMask.scale.set(1.04, 1.06, 0.99);
            headSkinSlot.add(spMask);

            [-0.16, 0.16].forEach(ex => {
                const rim = new THREE.Mesh(new THREE.SphereGeometry(0.135, 14, 12), new THREE.MeshBasicMaterial({ color: 0x090d16 }));
                rim.scale.set(1.15, 0.82, 0.35);
                rim.rotation.z = ex < 0 ? -0.28 : 0.28;
                rim.position.set(ex, 0.05, 0.435);
                const lens = new THREE.Mesh(new THREE.SphereGeometry(0.105, 14, 12), new THREE.MeshBasicMaterial({ color: 0xffffff }));
                lens.scale.set(1.12, 0.76, 0.38);
                lens.rotation.z = ex < 0 ? -0.28 : 0.28;
                lens.position.set(ex, 0.05, 0.452);
                headSkinSlot.add(rim, lens);
            });

            const spider = new THREE.Mesh(new THREE.SphereGeometry(0.065, 10, 10), new THREE.MeshBasicMaterial({ color: 0x090d16 }));
            spider.scale.set(0.8, 1.3, 0.4);
            spider.position.set(0, 0.15, 0.28);
            bodySkinSlot.add(spider);
            return { hideHair: true };
        }

        if (skinId === 'rick') {
            skinMat.color.setHex(0xe2d9d0);
            hairMat.color.setHex(0x7dd3fc);
            shirtMat.color.setHex(0x67e8f9);
            pantsMat.color.setHex(0x785c3a);
            shoesMat.color.setHex(0x1e293b);
            addHaori(new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.5, side: THREE.DoubleSide }));

            // تک‌ابروی آبی ریک
            const unibrow = new THREE.Mesh(new THREE.CapsuleGeometry(0.025, 0.36, 6, 10), hairMat);
            unibrow.rotation.z = Math.PI / 2;
            unibrow.position.set(0, 0.165, 0.44);
            headSkinSlot.add(unibrow);
            return { hairStyle: 'spiky_rick', hideHair: false };
        }

        if (skinId === 'morty') {
            skinMat.color.setHex(0xffdbac);
            hairMat.color.setHex(0x6b4423);
            shirtMat.color.setHex(0xfef08a);
            pantsMat.color.setHex(0x1e3a8a);
            shoesMat.color.setHex(0xffffff);
            return { hairStyle: 'short', hideHair: false };
        }

        if (skinId === 'dr_strange') {
            skinMat.color.setHex(0xf1c27d);
            hairMat.color.setHex(0x111827);
            shirtMat.color.setHex(0x1e3a8a);
            pantsMat.color.setHex(0x0f172a);
            shoesMat.color.setHex(0x451a03);
            beltMat.color.setHex(0x92400e);
            addCape(0xdc2626, 0xb91c1c);

            // چشم آگاموتو درخشان سبز روی سینه
            const eyeGold = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.11, 0.03, 16), new THREE.MeshStandardMaterial({ color: 0xfbbf24, metalness: 0.8 }));
            eyeGold.rotation.x = Math.PI / 2;
            eyeGold.position.set(0, 0.24, 0.28);
            const timeStone = new THREE.Mesh(new THREE.SphereGeometry(0.05, 10, 10), new THREE.MeshStandardMaterial({ color: 0x4ade80, emissive: 0x22c55e, emissiveIntensity: 1.2 }));
            timeStone.position.set(0, 0.24, 0.3);
            bodySkinSlot.add(eyeGold, timeStone);

            // شقیقه‌های سفید و ریش پروفسوری
            [-0.43, 0.43].forEach(sx => {
                const streak = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.18, 0.24), whiteTrimMat);
                streak.position.set(sx, 0.08, 0.06);
                headSkinSlot.add(streak);
            });
            const goatee = new THREE.Mesh(new THREE.TorusGeometry(0.095, 0.022, 8, 16), hairMat);
            goatee.position.set(0, -0.12, 0.425);
            headSkinSlot.add(goatee);
            return { hairStyle: 'short', hideHair: false };
        }

        if (skinId === 'tanjiro') {
            skinMat.color.setHex(0xffdbac);
            hairMat.color.setHex(0x5c1922);
            shirtMat.color.setHex(0x1f2937);
            pantsMat.color.setHex(0x111827);
            shoesMat.color.setHex(0xffffff);
            beltMat.color.setHex(0xffffff);
            addHaori(new THREE.MeshStandardMaterial({ map: createCheckerHaoriTexture(), side: THREE.DoubleSide, roughness: 0.65 }));

            // جای زخم پیشانی و گوشواره‌های هانافودا
            const scar = new THREE.Mesh(new THREE.CircleGeometry(0.08, 8), new THREE.MeshBasicMaterial({ color: 0x991b1b }));
            scar.position.set(-0.18, 0.22, 0.435);
            headSkinSlot.add(scar);
            [-0.44, 0.44].forEach(ex => {
                const card = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.18, 0.09), whiteTrimMat);
                card.position.set(ex, -0.18, 0.02);
                const sun = new THREE.Mesh(new THREE.SphereGeometry(0.03, 8, 8), new THREE.MeshBasicMaterial({ color: 0xdc2626 }));
                sun.position.set(ex * 1.05, -0.16, 0.02);
                headSkinSlot.add(card, sun);
            });
            return { hairStyle: 'spiky_anime', hideHair: false };
        }

        if (skinId === 'nezuko') {
            skinMat.color.setHex(0xffe4d6);
            hairMat.color.setHex(0x111827);
            shirtMat.color.setHex(0xf9a8d4);
            pantsMat.color.setHex(0xf472b6);
            shoesMat.color.setHex(0xfef2f2);
            addHaori(new THREE.MeshStandardMaterial({ color: 0x291d1e, side: THREE.DoubleSide, roughness: 0.7 }));

            // بامبوی سبز نزوکو روی دهان + انتهای نارنجی مو
            const bamboo = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.055, 0.34, 12), new THREE.MeshStandardMaterial({ color: 0x22c55e, roughness: 0.45 }));
            bamboo.rotation.z = Math.PI / 2;
            bamboo.position.set(0, -0.11, 0.455);
            headSkinSlot.add(bamboo);
            [-0.42, 0.42].forEach(ox => {
                const tip = new THREE.Mesh(new THREE.CapsuleGeometry(0.09, 0.22, 6, 10), new THREE.MeshStandardMaterial({ color: 0xf97316 }));
                tip.position.set(ox, -0.45, 0.05);
                headSkinSlot.add(tip);
            });
            return { hairStyle: 'long', hideHair: false };
        }

        if (skinId === 'zenitsu') {
            skinMat.color.setHex(0xffdbac);
            hairMat.color.setHex(0xfacc15);
            shirtMat.color.setHex(0x3f2b1d);
            pantsMat.color.setHex(0x291d14);
            shoesMat.color.setHex(0xffffff);
            beltMat.color.setHex(0xffffff);
            addHaori(new THREE.MeshStandardMaterial({ map: createZenitsuTexture(), side: THREE.DoubleSide, roughness: 0.6 }));
            return { hairStyle: 'spiky_anime', hideHair: false };
        }

        if (skinId === 'inosuke') {
            skinMat.color.setHex(0xf1c27d);
            shirtMat.color.setHex(0xf1c27d);
            pantsMat.color.setHex(0x1e3a8a);
            shoesMat.color.setHex(0x78350f);
            beltMat.color.setHex(0xa8a29e);
            collar.visible = false;
            faceDetailsGroup.visible = false;

            // ماسک سه‌بعدی گراز اینوسکه
            const boarMat = new THREE.MeshStandardMaterial({ color: 0x9ca3af, roughness: 0.75 });
            const boarHead = new THREE.Mesh(new THREE.SphereGeometry(0.51, 24, 20), boarMat);
            boarHead.scale.set(1.06, 1.04, 1.08);
            const snout = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.2, 0.22, 14), new THREE.MeshStandardMaterial({ color: 0xfda4af }));
            snout.rotation.x = Math.PI / 2;
            snout.position.set(0, -0.06, 0.52);
            headSkinSlot.add(boarHead, snout);

            [-0.19, 0.19].forEach(ex => {
                const bEye = new THREE.Mesh(new THREE.SphereGeometry(0.095, 12, 12), new THREE.MeshBasicMaterial({ color: 0x38bdf8 }));
                bEye.position.set(ex, 0.08, 0.46);
                const tusk = new THREE.Mesh(new THREE.ConeGeometry(0.045, 0.22, 8), whiteTrimMat);
                tusk.position.set(ex, -0.06, 0.54);
                tusk.rotation.z = ex < 0 ? 0.35 : -0.35;
                const bEar = new THREE.Mesh(new THREE.ConeGeometry(0.14, 0.32, 8), boarMat);
                bEar.position.set(ex * 1.9, 0.44, -0.05);
                bEar.rotation.z = ex < 0 ? 0.45 : -0.45;
                headSkinSlot.add(bEye, tusk, bEar);
            });
            return { hideHair: true };
        }

        return { hairStyle: newApp.hairStyle || 'short', hideHair: false };
    }

    const rig = {
        mesh: root,
        parts: { bodyGroup, headGroup, leftArmPivot, rightArmPivot, leftLegPivot, rightLegPivot, torso, hatSlot, rightHandSlot, hairSlot },
        targetPos: new THREE.Vector3(),
        emote: null,
        emoteTimer: 0,
        sitting: false,
        sitSeat: null,
        preSitPos: null,
        mood: appearance.mood || 'happy',
        labelEl,
        chatBubbleEl: labelEl ? labelEl.querySelector('.chat-bubble') : null,
        tagEl: labelEl ? labelEl.querySelector('.player-tag') : null,
        chatTimeout: null,
        setName(newName) { if (this.tagEl) this.tagEl.textContent = newName; },
        sitOn(seat) {
            if (!this.sitting) {
                this.preSitPos = this.mesh.position.clone();
            }
            this.sitting = true;
            this.sitSeat = seat;
            this.mesh.position.set(seat.x, 0, seat.z);
            this.targetPos.set(seat.x, 0, seat.z);
            this.mesh.rotation.set(0, seat.rotY || 0, 0);
        },
        standUp(checkCollisionFn = null) {
            if (!this.sitting) return;
            this.sitting = false;
            if (this.sitSeat) {
                const ry = this.sitSeat.rotY || 0;
                const sx = this.sitSeat.x, sz = this.sitSeat.z;
                const candidates = [];
                // ۱. اولویت با جهت روبه‌روی صندلی در فواصل مختلف
                [0.95, 1.35].forEach(d => {
                    candidates.push([sx + Math.sin(ry) * d, sz + Math.cos(ry) * d]);
                });
                // ۲. نقطه قبلیِ پیش از نشستن
                if (this.preSitPos) {
                    candidates.push([this.preSitPos.x, this.preSitPos.z]);
                }
                // ۳. جستجوی شعاعی در تمام زوایای اطراف صندلی برای پیدا کردن نقطه ۱۰۰٪ آزاد
                for (const rad of [1.0, 1.45, 1.9, 2.4]) {
                    for (let i = 0; i < 12; i++) {
                        const a = ry + (i / 12) * Math.PI * 2;
                        candidates.push([sx + Math.sin(a) * rad, sz + Math.cos(a) * rad]);
                    }
                }
                let chosen = candidates[0];
                if (checkCollisionFn) {
                    const free = candidates.find(([cx, cz]) => !checkCollisionFn(cx, cz));
                    if (free) chosen = free;
                }
                this.mesh.position.set(chosen[0], 0, chosen[1]);
                this.targetPos.set(chosen[0], 0, chosen[1]);
            }
            this.sitSeat = null;
            this.preSitPos = null;
            bodyGroup.rotation.set(0, 0, 0);
            headGroup.rotation.set(0, 0, 0);
            leftArmPivot.position.y = 1.62;
            rightArmPivot.position.y = 1.62;
            leftArmPivot.rotation.set(0, 0, 0);
            rightArmPivot.rotation.set(0, 0, 0);
            leftLegPivot.position.set(-0.175, 0.84, 0);
            rightLegPivot.position.set(0.175, 0.84, 0);
            leftLegPivot.rotation.set(0, 0, 0);
            rightLegPivot.rotation.set(0, 0, 0);
        },
        applyAppearance(newApp) {
            if (newApp.skinColor !== undefined) skinMat.color.setHex(newApp.skinColor);
            if (newApp.hairColor !== undefined) hairMat.color.setHex(newApp.hairColor);
            if (newApp.shirtColor !== undefined) shirtMat.color.setHex(newApp.shirtColor);
            if (newApp.pantsColor !== undefined) pantsMat.color.setHex(newApp.pantsColor);
            if (newApp.shoesColor !== undefined) shoesMat.color.setHex(newApp.shoesColor);

            this.mood = newApp.mood || 'happy';
            const skinInfo = applySkinPreset(newApp.skin || 'none', newApp);
            applyMood(this.mood);

            hairSlot.clear();
            if (!skinInfo.hideHair) {
                hairSlot.add(buildHairMesh(skinInfo.hairStyle || 'short', hairMat));
            }

            hatSlot.clear();
            if (!skinInfo.hideHair && newApp.hat === 'hat_crown') {
                const crownGroup = new THREE.Group();
                const goldMat = new THREE.MeshStandardMaterial({ color: 0xfbbf24, metalness: 0.78, roughness: 0.2 });
                const base = new THREE.Mesh(new THREE.CylinderGeometry(0.27, 0.22, 0.16, 12), goldMat);
                crownGroup.add(base);
                for (let i = 0; i < 4; i++) {
                    const a = (i / 4) * Math.PI * 2;
                    const spike = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.16, 6), goldMat);
                    spike.position.set(Math.cos(a) * 0.2, 0.14, Math.sin(a) * 0.2);
                    const gem = new THREE.Mesh(new THREE.SphereGeometry(0.04, 8, 8), new THREE.MeshStandardMaterial({ color: i % 2 === 0 ? 0xf43f5e : 0x38bdf8, emissive: i % 2 === 0 ? 0xe11d48 : 0x0284c7, emissiveIntensity: 0.5 }));
                    gem.position.set(Math.cos(a) * 0.23, 0.02, Math.sin(a) * 0.23);
                    crownGroup.add(spike, gem);
                }
                hatSlot.add(crownGroup);
            } else if (!skinInfo.hideHair && newApp.hat === 'hat_cap') {
                const capGroup = new THREE.Group();
                const dome = new THREE.Mesh(new THREE.SphereGeometry(0.4, 20, 14, 0, Math.PI * 2, 0, Math.PI / 2), new THREE.MeshStandardMaterial({ color: 0x3b82f6, roughness: 0.5 }));
                const visor = new THREE.Mesh(new THREE.CylinderGeometry(0.38, 0.38, 0.04, 18, 1, false, -Math.PI / 3, Math.PI * 0.66), new THREE.MeshStandardMaterial({ color: 0x1d4ed8, roughness: 0.5 }));
                visor.position.set(0, 0.02, 0.15);
                capGroup.add(dome, visor);
                capGroup.position.y = -0.15;
                hatSlot.add(capGroup);
            }
            rightHandSlot.clear();
            if (newApp.handProp) rightHandSlot.add(buildHandPropMesh(newApp.handProp));
            else if (newApp.skin === 'tanjiro') rightHandSlot.add(buildHandPropMesh('prop_sword'));
            else if (newApp.skin === 'dr_strange') {
                const spell = new THREE.Mesh(new THREE.RingGeometry(0.14, 0.26, 20), new THREE.MeshBasicMaterial({ color: 0xfb923c, side: THREE.DoubleSide }));
                spell.rotation.x = Math.PI / 2;
                rightHandSlot.add(spell);
            } else if (newApp.skin === 'green_lantern') {
                const glowOrb = new THREE.Mesh(new THREE.SphereGeometry(0.11, 12, 12), new THREE.MeshBasicMaterial({ color: 0x4ade80 }));
                rightHandSlot.add(glowOrb);
            }
        },
        say(text) {
            if (!text || !this.chatBubbleEl) return;
            this.chatBubbleEl.textContent = text;
            this.chatBubbleEl.style.display = 'block';
            clearTimeout(this.chatTimeout);
            this.chatTimeout = setTimeout(() => { this.chatBubbleEl.style.display = 'none'; }, 4800);
        },
        triggerEmote(emoteName) {
            this.emote = emoteName;
            this.emoteTimer = 2.5;
        }
    };

    rig.applyAppearance(appearance);
    return rig;
}

/**
 * رندر زنده تصویر پرتره سه‌بعدی کاراکتر در دایره بالا-چپ HUD
 */
let _portraitCtx = null;
export function renderCharacterPortrait(appearance) {
    if (typeof document === 'undefined') return;
    const targetCanvas = document.getElementById('avatar-portrait-canvas');
    if (!targetCanvas) return;

    if (!_portraitCtx) {
        const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true, preserveDrawingBuffer: true });
        renderer.setSize(128, 128);
        renderer.toneMapping = THREE.ACESFilmicToneMapping;
        renderer.toneMappingExposure = 1.05;

        const scene = new THREE.Scene();
        const hemi = new THREE.HemisphereLight(0xffffff, 0x475569, 1.05);
        const dir = new THREE.DirectionalLight(0xfff7ed, 1.35);
        dir.position.set(2.5, 4, 4);
        scene.add(hemi, dir);

        const camera = new THREE.PerspectiveCamera(34, 1, 0.1, 20);
        camera.position.set(0, 2.15, 2.45);
        camera.lookAt(0, 2.02, 0);

        const rig = createCharacterRig('', appearance, null, { skipDomLabel: true });
        rig.mesh.rotation.y = -0.18;
        scene.add(rig.mesh);
        _portraitCtx = { renderer, scene, camera, rig };
    } else {
        _portraitCtx.rig.applyAppearance(appearance);
    }

    _portraitCtx.renderer.render(_portraitCtx.scene, _portraitCtx.camera);
    const ctx2d = targetCanvas.getContext('2d');
    const w = targetCanvas.width, h = targetCanvas.height;
    ctx2d.clearRect(0, 0, w, h);
    const grad = ctx2d.createLinearGradient(0, 0, 0, h);
    grad.addColorStop(0, '#93c5fd');
    grad.addColorStop(1, '#2563eb');
    ctx2d.fillStyle = grad;
    ctx2d.fillRect(0, 0, w, h);
    ctx2d.drawImage(_portraitCtx.renderer.domElement, 0, 0, w, h);
}

export function updateCharacterAnimation(rig, dt, time, camera, checkCollisionFn, targetRing) {
    const pos = rig.mesh.position;
    const mood = rig.mood || 'happy';

    if (rig.sitting) {
        if (targetRing && targetRing.visible) targetRing.visible = false;
        const breath = Math.sin(time * 2.6) * 0.015;
        const seatDrop = -0.34;
        rig.parts.bodyGroup.position.y = 1.26 + seatDrop + breath;
        rig.parts.bodyGroup.rotation.x = mood === 'sad' ? 0.22 : (mood === 'angry' ? 0.12 : -0.05);
        rig.parts.headGroup.position.y = 2.15 + seatDrop + breath * 1.1;
        rig.parts.headGroup.rotation.x = mood === 'sad' ? 0.3 : 0;
        rig.parts.headGroup.rotation.z = Math.sin(time * 1.4) * 0.04;
        rig.parts.leftArmPivot.position.y = 1.62 + seatDrop;
        rig.parts.rightArmPivot.position.y = 1.62 + seatDrop;
        rig.parts.leftLegPivot.position.set(-0.175, 0.84 + seatDrop + 0.14, 0.14);
        rig.parts.rightLegPivot.position.set(0.175, 0.84 + seatDrop + 0.14, 0.14);
        rig.parts.leftLegPivot.rotation.x = -1.46;
        rig.parts.rightLegPivot.rotation.x = -1.46;
        if (!rig.emote) {
            rig.parts.leftArmPivot.rotation.x = -0.45;
            rig.parts.rightArmPivot.rotation.x = -0.45;
            rig.parts.leftArmPivot.rotation.z = 0;
            rig.parts.rightArmPivot.rotation.z = 0;
        }
    } else {
        rig.parts.leftArmPivot.position.y = 1.62;
        rig.parts.rightArmPivot.position.y = 1.62;
        rig.parts.leftLegPivot.position.set(-0.175, 0.84, 0);
        rig.parts.rightLegPivot.position.set(0.175, 0.84, 0);

        // اگر کاراکتر به هر دلیلی داخل محدوده مانع گیر افتاده بود، فوراً به نزدیک‌ترین نقطه آزاد هدایت شود
        if (checkCollisionFn && checkCollisionFn(pos.x, pos.z)) {
            let freed = false;
            for (const rad of [0.5, 1.0, 1.6, 2.3]) {
                for (let i = 0; i < 12; i++) {
                    const a = (i / 12) * Math.PI * 2;
                    const tx = pos.x + Math.cos(a) * rad;
                    const tz = pos.z + Math.sin(a) * rad;
                    if (!checkCollisionFn(tx, tz)) {
                        pos.set(tx, 0, tz);
                        freed = true;
                        break;
                    }
                }
                if (freed) break;
            }
        }

        // تاثیر مستقیم حالت روحی (Mood) روی سرعت، فرم بدن، سر و حرکت دست‌ها و پاها!
        const speedMult = mood === 'excited' ? 1.22 : (mood === 'angry' ? 1.08 : (mood === 'sad' ? 0.66 : 1.0));
        const dist = pos.distanceTo(rig.targetPos);

        if (dist > 0.12) {
            const prevX = pos.x, prevZ = pos.z;
            const dir = new THREE.Vector3().subVectors(rig.targetPos, pos).normalize();
            const speed = 5.8 * speedMult * dt;
            const nextX = pos.x + dir.x * speed;
            const nextZ = pos.z + dir.z * speed;

            if (!checkCollisionFn || !checkCollisionFn(nextX, nextZ)) {
                pos.x = nextX;
                pos.z = nextZ;
            } else if (!checkCollisionFn(nextX, pos.z)) {
                pos.x = nextX;
            } else if (!checkCollisionFn(pos.x, nextZ)) {
                pos.z = nextZ;
            } else {
                rig.targetPos.copy(pos);
                if (targetRing) targetRing.visible = false;
            }
            if (Math.hypot(pos.x - prevX, pos.z - prevZ) < 0.0015) {
                rig.targetPos.copy(pos);
                if (targetRing) targetRing.visible = false;
            }

            const targetAngle = Math.atan2(dir.x, dir.z);
            const targetQuat = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), targetAngle);
            rig.mesh.quaternion.slerp(targetQuat, 10 * dt);

            const freq = mood === 'sad' ? 7.5 : (mood === 'excited' ? 13.5 : 11.2);
            const amp = mood === 'sad' ? 0.36 : (mood === 'angry' ? 0.85 : 0.65);
            const swing = Math.sin(time * freq) * amp;

            rig.parts.leftLegPivot.rotation.x = swing;
            rig.parts.rightLegPivot.rotation.x = -swing;

            if (!rig.emote) {
                if (mood === 'excited') {
                    // دویدن شاد و ذوق‌زده با دست‌های باز و پرش‌های ریز
                    rig.parts.leftArmPivot.rotation.x = -swing * 0.9;
                    rig.parts.rightArmPivot.rotation.x = swing * 0.9;
                    rig.parts.leftArmPivot.rotation.z = 0.52;
                    rig.parts.rightArmPivot.rotation.z = -0.52;
                } else if (mood === 'angry') {
                    // گام‌های سنگین و خشن با آرنج‌های منقبض و خم شدن به جلو
                    rig.parts.leftArmPivot.rotation.x = -swing * 1.1 - 0.25;
                    rig.parts.rightArmPivot.rotation.x = swing * 1.1 - 0.25;
                    rig.parts.leftArmPivot.rotation.z = 0.34;
                    rig.parts.rightArmPivot.rotation.z = -0.34;
                } else if (mood === 'sad') {
                    // راه رفتن بی‌رمق با شانه‌های افتاده و دست‌های آویزان
                    rig.parts.leftArmPivot.rotation.x = -swing * 0.3 + 0.12;
                    rig.parts.rightArmPivot.rotation.x = swing * 0.3 + 0.12;
                    rig.parts.leftArmPivot.rotation.z = 0.05;
                    rig.parts.rightArmPivot.rotation.z = -0.05;
                } else if (mood === 'surprised') {
                    // راه رفتن دستپاچه با دست‌های بالا نزدیک صورت
                    rig.parts.leftArmPivot.rotation.x = -1.25 + swing * 0.25;
                    rig.parts.rightArmPivot.rotation.x = -1.25 - swing * 0.25;
                    rig.parts.leftArmPivot.rotation.z = 0.26;
                    rig.parts.rightArmPivot.rotation.z = -0.26;
                } else {
                    rig.parts.leftArmPivot.rotation.x = -swing * 0.8;
                    rig.parts.rightArmPivot.rotation.x = swing * 0.8;
                    rig.parts.leftArmPivot.rotation.z = 0;
                    rig.parts.rightArmPivot.rotation.z = 0;
                }
            }

            const bounce = mood === 'excited'
                ? Math.abs(Math.sin(time * freq)) * 0.16
                : (mood === 'sad' ? Math.abs(Math.sin(time * freq)) * 0.02 - 0.06 : Math.abs(Math.sin(time * freq)) * 0.055);
            rig.parts.bodyGroup.position.y = 1.26 + bounce;
            rig.parts.headGroup.position.y = 2.15 + bounce * 1.05 + (mood === 'sad' ? -0.05 : 0);
            rig.parts.bodyGroup.rotation.x = mood === 'angry' ? 0.18 : (mood === 'sad' ? 0.22 : (mood === 'surprised' ? -0.1 : 0.04));
            rig.parts.headGroup.rotation.x = mood === 'sad' ? 0.34 : (mood === 'angry' ? 0.1 : 0);
            rig.parts.headGroup.rotation.y = 0;
        } else {
            if (targetRing && targetRing.visible) targetRing.visible = false;
            rig.parts.leftLegPivot.rotation.x *= 0.8;
            rig.parts.rightLegPivot.rotation.x *= 0.8;

            if (mood === 'excited') {
                const hop = Math.abs(Math.sin(time * 6.5)) * 0.11;
                rig.parts.bodyGroup.position.y = 1.26 + hop;
                rig.parts.headGroup.position.y = 2.15 + hop * 1.15;
                rig.parts.bodyGroup.rotation.x = -0.04;
                rig.parts.headGroup.rotation.x = -0.06;
                rig.parts.headGroup.rotation.z = Math.sin(time * 4.5) * 0.09;
                rig.parts.headGroup.rotation.y = 0;
                if (!rig.emote) {
                    rig.parts.leftArmPivot.rotation.x = -0.6 + Math.sin(time * 6.5) * 0.25;
                    rig.parts.rightArmPivot.rotation.x = -0.6 - Math.sin(time * 6.5) * 0.25;
                    rig.parts.leftArmPivot.rotation.z = 0.55;
                    rig.parts.rightArmPivot.rotation.z = -0.55;
                }
            } else if (mood === 'angry') {
                const huff = Math.sin(time * 7.5) * 0.03;
                rig.parts.bodyGroup.position.y = 1.25 + huff;
                rig.parts.headGroup.position.y = 2.13 + huff;
                rig.parts.bodyGroup.rotation.x = 0.15;
                rig.parts.headGroup.rotation.x = 0.12;
                rig.parts.headGroup.rotation.y = Math.sin(time * 9) * 0.05;
                rig.parts.headGroup.rotation.z = 0;
                if (!rig.emote) {
                    rig.parts.leftArmPivot.rotation.x = -0.42;
                    rig.parts.rightArmPivot.rotation.x = -0.42;
                    rig.parts.leftArmPivot.rotation.z = 0.36;
                    rig.parts.rightArmPivot.rotation.z = -0.36;
                }
            } else if (mood === 'sad') {
                const sigh = Math.sin(time * 1.8) * 0.025;
                rig.parts.bodyGroup.position.y = 1.19 + sigh;
                rig.parts.headGroup.position.y = 2.06 + sigh;
                rig.parts.bodyGroup.rotation.x = 0.22;
                rig.parts.headGroup.rotation.x = 0.36;
                rig.parts.headGroup.rotation.z = Math.sin(time * 1.5) * 0.08;
                rig.parts.headGroup.rotation.y = 0;
                if (!rig.emote) {
                    rig.parts.leftArmPivot.rotation.x = 0.12;
                    rig.parts.rightArmPivot.rotation.x = 0.12;
                    rig.parts.leftArmPivot.rotation.z = 0.04;
                    rig.parts.rightArmPivot.rotation.z = -0.04;
                }
            } else if (mood === 'surprised') {
                const gasp = Math.sin(time * 5.5) * 0.02;
                rig.parts.bodyGroup.position.y = 1.27 + gasp;
                rig.parts.headGroup.position.y = 2.17 + gasp;
                rig.parts.bodyGroup.rotation.x = -0.12;
                rig.parts.headGroup.rotation.x = -0.05;
                rig.parts.headGroup.rotation.y = Math.sin(time * 4.2) * 0.2;
                rig.parts.headGroup.rotation.z = 0;
                if (!rig.emote) {
                    rig.parts.leftArmPivot.rotation.x = -1.35;
                    rig.parts.rightArmPivot.rotation.x = -1.35;
                    rig.parts.leftArmPivot.rotation.z = 0.25;
                    rig.parts.rightArmPivot.rotation.z = -0.25;
                }
            } else {
                const breath = Math.sin(time * 3) * 0.02;
                rig.parts.bodyGroup.position.y = 1.26 + breath;
                rig.parts.headGroup.position.y = 2.15 + breath * 1.2;
                rig.parts.bodyGroup.rotation.x *= 0.8;
                rig.parts.headGroup.rotation.x *= 0.8;
                rig.parts.headGroup.rotation.y *= 0.8;
                rig.parts.headGroup.rotation.z = Math.sin(time * 1.5) * 0.04;
                if (!rig.emote) {
                    rig.parts.leftArmPivot.rotation.x *= 0.8;
                    rig.parts.rightArmPivot.rotation.x *= 0.8;
                    rig.parts.leftArmPivot.rotation.z *= 0.8;
                    rig.parts.rightArmPivot.rotation.z *= 0.8;
                }
            }
        }
    }

    if (rig.emote && rig.emoteTimer > 0) {
        rig.emoteTimer -= dt;
        if (rig.emote === 'wave') {
            rig.parts.rightArmPivot.rotation.z = -2.6;
            rig.parts.rightArmPivot.rotation.x = Math.sin(time * 14) * 0.35;
        } else if (rig.emote === 'clap') {
            rig.parts.leftArmPivot.rotation.x = -1.2;
            rig.parts.rightArmPivot.rotation.x = -1.2;
            rig.parts.leftArmPivot.rotation.z = 0.3 + Math.abs(Math.sin(time * 16)) * 0.25;
            rig.parts.rightArmPivot.rotation.z = -0.3 - Math.abs(Math.sin(time * 16)) * 0.25;
        } else if (rig.emote === 'prop_show') {
            rig.parts.rightArmPivot.rotation.x = -2.2;
            rig.parts.rightArmPivot.rotation.z = -0.3 + Math.sin(time * 10) * 0.15;
        } else if (rig.emote === 'jump' || rig.emote === 'invite') {
            rig.mesh.position.y = Math.abs(Math.sin(time * 9)) * 0.65;
            rig.parts.leftArmPivot.rotation.z = 2.5;
            rig.parts.rightArmPivot.rotation.z = -2.5;
        }
        if (rig.emoteTimer <= 0) {
            rig.emote = null;
            rig.mesh.position.y = 0;
            rig.parts.leftArmPivot.rotation.set(0, 0, 0);
            rig.parts.rightArmPivot.rotation.set(0, 0, 0);
        }
    }

    if (rig.labelEl && camera) {
        const headWorldPos = new THREE.Vector3(pos.x, pos.y + 2.85, pos.z);
        headWorldPos.project(camera);
        if (headWorldPos.z < 1) {
            const screenX = (headWorldPos.x * 0.5 + 0.5) * window.innerWidth;
            const screenY = (-headWorldPos.y * 0.5 + 0.5) * window.innerHeight;
            rig.labelEl.style.left = `${screenX}px`;
            rig.labelEl.style.top = `${screenY}px`;
            rig.labelEl.style.display = 'block';
        } else {
            rig.labelEl.style.display = 'none';
        }
    }
}
