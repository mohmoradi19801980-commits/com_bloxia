import * as THREE from './three/three.module.js';
import { createSignTexture, buildDoorstepPlant } from './city.js';

function createParquetTexture() {
    const c = document.createElement('canvas');
    c.width = c.height = 256;
    const g = c.getContext('2d');
    g.fillStyle = '#c88a55';
    g.fillRect(0, 0, 256, 256);
    const shades = ['#d49a66', '#be7e47', '#cfa06e', '#b5743e'];
    for (let y = 0; y < 256; y += 32) {
        const shift = (y / 32) % 2 === 0 ? 0 : 64;
        for (let x = -64; x < 256; x += 128) {
            g.fillStyle = shades[Math.abs((x >> 6) + (y >> 5)) % 4];
            g.fillRect(x + shift + 2, y + 2, 124, 28);
            g.strokeStyle = 'rgba(72, 40, 16, 0.25)';
            g.lineWidth = 2;
            g.strokeRect(x + shift + 2, y + 2, 124, 28);
        }
    }
    const t = new THREE.CanvasTexture(c);
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.repeat.set(6, 5);
    if ('SRGBColorSpace' in THREE) t.colorSpace = THREE.SRGBColorSpace;
    return t;
}

function createTileTexture() {
    const c = document.createElement('canvas');
    c.width = c.height = 128;
    const g = c.getContext('2d');
    g.fillStyle = '#e5dccb';
    g.fillRect(0, 0, 128, 128);
    for (let y = 0; y < 128; y += 64) {
        for (let x = 0; x < 128; x += 64) {
            g.fillStyle = (x + y) % 128 === 0 ? '#f1e9da' : '#dfd4c0';
            g.beginPath();
            g.roundRect(x + 3, y + 3, 58, 58, 8);
            g.fill();
        }
    }
    const t = new THREE.CanvasTexture(c);
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.repeat.set(3, 4);
    if ('SRGBColorSpace' in THREE) t.colorSpace = THREE.SRGBColorSpace;
    return t;
}

export function buildRealisticFurniture(itemId, customColor) {
    const group = new THREE.Group();
    if (itemId === 'furn_sofa') {
        const mat = new THREE.MeshStandardMaterial({ color: customColor || 0xf472b6, roughness: 0.68 });
        const cushionMat = new THREE.MeshStandardMaterial({ color: 0xfde68a, roughness: 0.7 });
        const seat = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.42, 1.0), mat);
        seat.position.y = 0.34;
        seat.castShadow = true;
        const back = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.75, 0.28), mat);
        back.position.set(0, 0.78, -0.36);
        back.castShadow = true;
        [-1.18, 1.18].forEach(ax => {
            const arm = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.58, 1.0), mat);
            arm.position.set(ax, 0.48, 0);
            group.add(arm);
        });
        [-0.65, 0.65].forEach(cx => {
            const pil = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.42, 0.18), cushionMat);
            pil.position.set(cx, 0.72, -0.18);
            pil.rotation.z = cx < 0 ? 0.12 : -0.12;
            group.add(pil);
        });
        group.add(seat, back);
    } else if (itemId === 'furn_tv') {
        const stand = new THREE.Mesh(new THREE.BoxGeometry(2.5, 0.56, 0.58), new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.65 }));
        stand.position.y = 0.28;
        stand.castShadow = true;
        const frame = new THREE.Mesh(new THREE.BoxGeometry(2.25, 1.3, 0.1), new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.3 }));
        frame.position.y = 1.38;
        const screen = new THREE.Mesh(new THREE.PlaneGeometry(2.08, 1.14), new THREE.MeshBasicMaterial({ map: createSignTexture('🎮 استودیو بازی تی‌وی روم', '#0284c7', '#fde047') }));
        screen.position.set(0, 1.38, 0.055);
        group.add(stand, frame, screen);
    } else if (itemId === 'furn_table') {
        const woodMat = new THREE.MeshStandardMaterial({ color: 0xb45309, roughness: 0.65 });
        const top = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.12, 1.25), woodMat);
        top.position.y = 0.78;
        top.castShadow = true;
        [[-0.8, -0.5], [0.8, -0.5], [-0.8, 0.5], [0.8, 0.5]].forEach(([lx, lz]) => {
            const leg = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.75, 0.11), woodMat);
            leg.position.set(lx, 0.37, lz);
            group.add(leg);
        });
        group.add(top);
    } else if (itemId === 'furn_bed') {
        const frame = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.38, 2.8), new THREE.MeshStandardMaterial({ color: 0x78350f }));
        frame.position.y = 0.22;
        const matt = new THREE.Mesh(new THREE.BoxGeometry(2.05, 0.32, 2.6), new THREE.MeshStandardMaterial({ color: 0x818cf8 }));
        matt.position.y = 0.52;
        const headb = new THREE.Mesh(new THREE.BoxGeometry(2.2, 1.1, 0.22), new THREE.MeshStandardMaterial({ color: 0x5b3a29 }));
        headb.position.set(0, 0.65, -1.32);
        const pillow = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.2, 0.55), new THREE.MeshStandardMaterial({ color: 0xffffff }));
        pillow.position.set(0, 0.75, -0.9);
        group.add(frame, matt, headb, pillow);
    } else if (itemId === 'furn_arcade') {
        const cab = new THREE.Mesh(new THREE.BoxGeometry(1.3, 2.25, 1.1), new THREE.MeshStandardMaterial({ color: 0x4f46e5, roughness: 0.45 }));
        cab.position.y = 1.12;
        cab.castShadow = true;
        const scr = new THREE.Mesh(new THREE.PlaneGeometry(1.0, 0.82), new THREE.MeshBasicMaterial({ color: 0x22d3ee }));
        scr.position.set(0, 1.52, 0.56);
        group.add(cab, scr);
    } else if (itemId === 'furn_lamp') {
        const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.18, 1.6, 12), new THREE.MeshStandardMaterial({ color: 0x334155 }));
        pole.position.y = 0.8;
        const shade = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.44, 0.46, 16), new THREE.MeshStandardMaterial({ color: 0xfef08a, emissive: 0xf59e0b, emissiveIntensity: 0.7 }));
        shade.position.y = 1.68;
        group.add(pole, shade);
    } else if (itemId === 'furn_plant') {
        return buildDoorstepPlant(1.2);
    }
    return group;
}

export function buildHomeInterior(homeData, ctx) {
    // محدوده دقیق حرکت کاراکتر (اتاق اصلی + بالکن عریض سمت چپ کنار آشپزخانه)
    ctx.setBounds({ minX: -19.2, maxX: 12.1, minZ: -10.2, maxZ: 10.2 });

    // چمن و محوطه بیرونی اطراف خانه برای نمای طبیعی از بالکن و پنجره‌ها
    const outerGrass = new THREE.Mesh(new THREE.PlaneGeometry(90, 90), new THREE.MeshStandardMaterial({ color: 0x5cbd4a, roughness: 0.92 }));
    outerGrass.rotation.x = -Math.PI / 2;
    outerGrass.position.y = -0.08;
    outerGrass.receiveShadow = true;
    ctx.worldGroup.add(outerGrass);

    // ۱. کف پارکت چوبی گرم داخل خانه + کف سرامیکی آشپزخانه
    const ground = new THREE.Mesh(
        new THREE.PlaneGeometry(26, 22),
        new THREE.MeshStandardMaterial({ map: createParquetTexture(), roughness: 0.7 })
    );
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    ctx.worldGroup.add(ground);

    // صفحه شفاف وسیع برای کلیک حرکت روی کل خانه و بالکن سمت چپ
    const walkPlane = new THREE.Mesh(
        new THREE.PlaneGeometry(46, 26),
        new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, depthWrite: false })
    );
    walkPlane.rotation.x = -Math.PI / 2;
    walkPlane.position.set(-4, 0.01, 0);
    ctx.worldGroup.add(walkPlane);
    ctx.setGround(walkPlane);

    if (homeData.isMine) {
        const grid = new THREE.GridHelper(24, 24, 0x9a5822, 0xd48c4c);
        grid.position.y = 0.02;
        ctx.worldGroup.add(grid);
    }

    const wallMat = new THREE.MeshStandardMaterial({ color: 0xfff8f1, roughness: 0.78 });
    const wainscotMat = new THREE.MeshStandardMaterial({ color: 0xf3e5d0, roughness: 0.7 });
    const trimMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.55 });

    // ۲. دیوار پشتی یکپارچه با پنجره پانوراما و قفسه‌های دکوری
    const backWall = new THREE.Mesh(new THREE.BoxGeometry(26.4, 4.8, 0.45), wallMat);
    backWall.position.set(0, 2.4, -11);
    backWall.receiveShadow = true;
    const backWainscot = new THREE.Mesh(new THREE.BoxGeometry(26.2, 1.1, 0.5), wainscotMat);
    backWainscot.position.set(0, 0.55, -10.95);
    // نور مخفی نئون سقف (مشابه طرح استودیو)
    const neonPink = new THREE.Mesh(new THREE.BoxGeometry(12.5, 0.09, 0.12), new THREE.MeshStandardMaterial({ color: 0xf472b6, emissive: 0xec4899, emissiveIntensity: 0.9 }));
    neonPink.position.set(-6.2, 4.65, -10.72);
    const neonCyan = new THREE.Mesh(new THREE.BoxGeometry(12.5, 0.09, 0.12), new THREE.MeshStandardMaterial({ color: 0x38bdf8, emissive: 0x06b6d4, emissiveIntensity: 0.9 }));
    neonCyan.position.set(6.2, 4.65, -10.72);
    ctx.worldGroup.add(backWall, backWainscot, neonPink, neonCyan);

    // پنجره بزرگ آفتاب‌گیر در هال مرکزی + پرده‌ها
    const winFrame = new THREE.Mesh(new THREE.BoxGeometry(5.2, 2.5, 0.18), trimMat);
    winFrame.position.set(0, 2.65, -10.74);
    const winGlass = new THREE.Mesh(new THREE.BoxGeometry(4.8, 2.15, 0.2), new THREE.MeshStandardMaterial({ color: 0xfef3c7, emissive: 0xfde68a, emissiveIntensity: 0.7 }));
    winGlass.position.set(0, 2.65, -10.72);
    [-2.75, 2.75].forEach(cx => {
        const curtain = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.28, 2.9, 12), new THREE.MeshStandardMaterial({ color: 0xfda4af, roughness: 0.85 }));
        curtain.position.set(cx, 2.55, -10.62);
        ctx.worldGroup.add(curtain);
    });
    ctx.worldGroup.add(winFrame, winGlass);

    // دیوار راست + پنجره نورانی
    const rightWall = new THREE.Mesh(new THREE.BoxGeometry(0.45, 4.8, 22), wallMat);
    rightWall.position.set(13, 2.4, 0);
    const rightWinFrame = new THREE.Mesh(new THREE.BoxGeometry(0.18, 2.3, 4.0), trimMat);
    rightWinFrame.position.set(12.75, 2.6, -1.5);
    const rightWinGlass = new THREE.Mesh(new THREE.BoxGeometry(0.2, 1.95, 3.6), new THREE.MeshStandardMaterial({ color: 0xe0f2fe, emissive: 0x7dd3fc, emissiveIntensity: 0.55 }));
    rightWinGlass.position.set(12.73, 2.6, -1.5);
    ctx.worldGroup.add(rightWall, rightWinFrame, rightWinGlass);

    // ۳. دیوار چپ کنار آشپزخانه با در شیشه‌ای عریض به سمت بالکن و باغچه! (در بازه z = -4.2 تا z = 1.8)
    const leftNorth = new THREE.Mesh(new THREE.BoxGeometry(0.45, 4.8, 6.8), wallMat);
    leftNorth.position.set(-13, 2.4, -7.6);
    const leftSouth = new THREE.Mesh(new THREE.BoxGeometry(0.45, 4.8, 9.2), wallMat);
    leftSouth.position.set(-13, 2.4, 6.4);
    const leftHeader = new THREE.Mesh(new THREE.BoxGeometry(0.45, 1.35, 6.0), wallMat);
    leftHeader.position.set(-13, 4.12, -1.2);
    // چارچوب شیشه‌ای کشویی درِ بالکن
    [-4.15, 1.75].forEach(dz => {
        const post = new THREE.Mesh(new THREE.BoxGeometry(0.52, 3.45, 0.22), trimMat);
        post.position.set(-13, 1.72, dz);
        ctx.worldGroup.add(post);
    });
    ctx.worldGroup.add(leftNorth, leftSouth, leftHeader);

    // موانع دقیق دیوار چپ (فقط ضخامت واقعی دیوار در x = -13) و حصار شمالی/جنوبی بیرون بالکن
    ctx.obstacles.push({ minX: -13.35, maxX: -12.65, minZ: -11.2, maxZ: -4.1 });
    ctx.obstacles.push({ minX: -13.35, maxX: -12.65, minZ: 1.7, maxZ: 11.2 });
    ctx.obstacles.push({ minX: -20.5, maxX: -13.25, minZ: -11.2, maxZ: -5.45 });
    ctx.obstacles.push({ minX: -20.5, maxX: -13.25, minZ: 3.05, maxZ: 11.2 });

    // ۴. بالکن دلباز و باغچه اختصاصی سمت چپِ آشپزخانه!
    const balconyDeck = new THREE.Mesh(
        new THREE.BoxGeometry(7.0, 0.22, 9.2),
        new THREE.MeshStandardMaterial({ map: createTileTexture(), roughness: 0.78 })
    );
    balconyDeck.position.set(-16.4, 0.01, -1.2);
    balconyDeck.receiveShadow = true;
    ctx.worldGroup.add(balconyDeck);

    // نرده‌های سفید بالکن سمت چپ + گلدان‌ها
    const railMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.45 });
    const westRail = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.12, 9.2), railMat);
    westRail.position.set(-19.75, 1.08, -1.2);
    const northRail = new THREE.Mesh(new THREE.BoxGeometry(6.8, 0.12, 0.12), railMat);
    northRail.position.set(-16.4, 1.08, -5.7);
    const southRail = new THREE.Mesh(new THREE.BoxGeometry(6.8, 0.12, 0.12), railMat);
    southRail.position.set(-16.4, 1.08, 3.3);
    ctx.worldGroup.add(westRail, northRail, southRail);

    for (let i = 0; i <= 14; i++) {
        const bz = -5.7 + i * (9.0 / 14);
        const p = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, 1.05, 8), railMat);
        p.position.set(-19.75, 0.54, bz);
        ctx.worldGroup.add(p);
    }
    // میز صبحانه‌خوری جمع‌وجور در گوشه غربی بالکن (کاملاً دور از مسیر تردد و صندلی‌ها!)
    const bTable = new THREE.Group();
    bTable.position.set(-18.1, 0.1, -1.2);
    const btTop = new THREE.Mesh(new THREE.CylinderGeometry(0.62, 0.62, 0.1, 18), new THREE.MeshStandardMaterial({ color: 0xfef3c7 }));
    btTop.position.y = 0.82;
    const btLeg = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.11, 0.82, 10), trimMat);
    btLeg.position.y = 0.41;
    bTable.add(btTop, btLeg);
    ctx.worldGroup.add(bTable);
    ctx.obstacles.push({ minX: -18.6, maxX: -17.6, minZ: -1.7, maxZ: -0.7 });

    // دو صندلی قابل نشستن در فضای کاملاً باز بالکن با خروج به سمت درِ آشپزخانه (بدون هیچ گیر کردنی!)
    [[-16.2, -2.6, Math.PI / 2], [-16.2, 0.2, Math.PI / 2]].forEach(([cx, cz, ry]) => {
        const ch = new THREE.Group();
        ch.position.set(cx, 0.1, cz);
        ch.rotation.y = ry;
        const cSeat = new THREE.Mesh(new THREE.BoxGeometry(0.78, 0.1, 0.78), new THREE.MeshStandardMaterial({ color: 0xfde68a }));
        cSeat.position.y = 0.48;
        const cBack = new THREE.Mesh(new THREE.BoxGeometry(0.78, 0.55, 0.1), trimMat);
        cBack.position.set(0, 0.78, -0.34);
        ch.add(cSeat, cBack);
        const seatInfo = { x: cx, z: cz, rotY: ry, label: '🪑 نشستن روی صندلی بالکن' };
        ch.userData = { action: 'sit_seat', seat: seatInfo };
        ctx.worldGroup.add(ch);
        ctx.interactables.push(ch);
        if (ctx.seats) ctx.seats.push(seatInfo);
    });

    [-5.0, 2.6].forEach(pz => {
        const pl = buildDoorstepPlant(1.05);
        pl.position.set(-19.0, 0.12, pz);
        ctx.worldGroup.add(pl);
    });

    // باغچه سرسبز و گل‌کاری‌شده درست بیرون بالکن سمت چپ (x = -19..-27)
    const gardenSoil = new THREE.Mesh(new THREE.BoxGeometry(7.2, 0.12, 14.0), new THREE.MeshStandardMaterial({ color: 0x4ade80, roughness: 0.88 }));
    gardenSoil.position.set(-22.6, 0.0, -1.2);
    gardenSoil.receiveShadow = true;
    ctx.worldGroup.add(gardenSoil);

    // حصار سفید باغچه + درختان و گل‌های رنگارنگ
    const gFenceTop = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.1, 14.0), railMat);
    gFenceTop.position.set(-26.1, 0.72, -1.2);
    ctx.worldGroup.add(gFenceTop);
    for (let i = 0; i <= 18; i++) {
        const picket = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.85, 0.12), railMat);
        picket.position.set(-26.1, 0.42, -8.0 + i * (13.6 / 18));
        ctx.worldGroup.add(picket);
    }
    [[-21.5, -5.5], [-23.8, 0.5], [-21.5, 4.2]].forEach(([tx, tz], idx) => {
        const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.32, 2.0, 10), trimMat);
        trunk.position.set(tx, 1.0, tz);
        const foliage = new THREE.Mesh(new THREE.SphereGeometry(1.35, 14, 12), new THREE.MeshStandardMaterial({ color: idx === 1 ? 0x22c55e : 0x4ade80 }));
        foliage.position.set(tx, 2.65, tz);
        foliage.castShadow = true;
        ctx.worldGroup.add(trunk, foliage);
    });
    const flCols = [0xf43f5e, 0xfacc15, 0xf472b6, 0x38bdf8, 0xa855f7, 0xffffff];
    for (let i = 0; i < 24; i++) {
        const fl = new THREE.Mesh(new THREE.SphereGeometry(0.18, 10, 10), new THREE.MeshStandardMaterial({ color: flCols[i % 6] }));
        fl.position.set(-19.6 - (i % 4) * 1.4, 0.22, -6.8 + Math.floor(i / 4) * 2.3);
        ctx.worldGroup.add(fl);
    }

    // ۵. دیوار کوتاه جلویی و پارتیشن‌های داخلی
    const frontLeft = new THREE.Mesh(new THREE.BoxGeometry(10.2, 0.95, 0.4), trimMat);
    frontLeft.position.set(-7.9, 0.48, 10.9);
    const frontRight = new THREE.Mesh(new THREE.BoxGeometry(10.2, 0.95, 0.4), trimMat);
    frontRight.position.set(7.9, 0.48, 10.9);
    ctx.worldGroup.add(frontLeft, frontRight);

    const divMat = new THREE.MeshStandardMaterial({ color: 0xfef3c7, roughness: 0.7 });
    const divLeft = new THREE.Mesh(new THREE.BoxGeometry(0.32, 3.4, 5.8), divMat);
    divLeft.position.set(-4.6, 1.7, -8.0);
    ctx.obstacles.push({ minX: -5.0, maxX: -4.2, minZ: -11.0, maxZ: -5.0 });

    const divRight = new THREE.Mesh(new THREE.BoxGeometry(0.32, 3.4, 5.8), divMat);
    divRight.position.set(4.6, 1.7, -8.0);
    ctx.obstacles.push({ minX: 4.2, maxX: 5.0, minZ: -11.0, maxZ: -5.0 });
    ctx.worldGroup.add(divLeft, divRight);

    // ۶. آشپزخانه پرجزئیات (شمال‌غرب، درست کنار بالکن چپ!)
    const kitchenTiles = new THREE.Mesh(new THREE.PlaneGeometry(8.1, 9.5), new THREE.MeshStandardMaterial({ map: createTileTexture(), roughness: 0.65 }));
    kitchenTiles.rotation.x = -Math.PI / 2;
    kitchenTiles.position.set(-8.8, 0.015, -6.1);
    ctx.worldGroup.add(kitchenTiles);

    // یخچال مدرن نقره‌ای + کابینت + گاز و هود + شلف دیواری
    const fridge = new THREE.Mesh(new THREE.BoxGeometry(1.5, 2.75, 1.25), new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 0.45, roughness: 0.3 }));
    fridge.position.set(-11.6, 1.38, -9.8);
    fridge.castShadow = true;
    const counter = new THREE.Mesh(new THREE.BoxGeometry(5.2, 1.05, 1.2), new THREE.MeshStandardMaterial({ color: 0xfffbeb, roughness: 0.5 }));
    counter.position.set(-8.0, 0.52, -9.9);
    counter.castShadow = true;
    const counterTop = new THREE.Mesh(new THREE.BoxGeometry(5.35, 0.1, 1.3), trimMat);
    counterTop.position.set(-8.0, 1.08, -9.9);
    const stove = new THREE.Mesh(new THREE.BoxGeometry(1.3, 0.08, 0.9), new THREE.MeshStandardMaterial({ color: 0x1e293b }));
    stove.position.set(-7.2, 1.15, -9.9);
    const hood = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.75, 0.65, 4), new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.5 }));
    hood.rotation.y = Math.PI / 4;
    hood.position.set(-7.2, 2.85, -10.1);
    const shelf = new THREE.Mesh(new THREE.BoxGeometry(2.8, 0.12, 0.45), trimMat);
    shelf.position.set(-9.6, 2.55, -10.55);

    const kitchenSign = new THREE.Mesh(new THREE.BoxGeometry(3.6, 0.72, 0.15), new THREE.MeshBasicMaterial({ map: createSignTexture('🍳 آشپزخانه و بالکن باغچه', '#0f172a', '#4ade80') }));
    kitchenSign.position.set(-8.8, 3.85, -10.7);
    ctx.worldGroup.add(fridge, counter, counterTop, stove, hood, shelf, kitchenSign);
    ctx.obstacles.push({ minX: -12.5, maxX: -5.2, minZ: -10.8, maxZ: -9.1 });

    // ۷. هال مرکزی دنج با کتابخانه و فرش
    const hallRug = new THREE.Mesh(new THREE.CircleGeometry(3.4, 36), new THREE.MeshStandardMaterial({ color: 0xfda4af, roughness: 0.9 }));
    hallRug.rotation.x = -Math.PI / 2;
    hallRug.position.set(0, 0.025, -3.8);
    const rugBorder = new THREE.Mesh(new THREE.RingGeometry(3.35, 3.6, 36), new THREE.MeshStandardMaterial({ color: 0xfff1f2 }));
    rugBorder.rotation.x = -Math.PI / 2;
    rugBorder.position.set(0, 0.026, -3.8);
    const bookcase = new THREE.Mesh(new THREE.BoxGeometry(1.7, 2.6, 0.65), trimMat);
    bookcase.position.set(-3.3, 1.3, -10.35);
    ctx.obstacles.push({ minX: -4.2, maxX: -2.4, minZ: -10.8, maxZ: -9.8 });
    const plantHall = buildDoorstepPlant(1.15);
    plantHall.position.set(3.4, 0, -10.1);
    const tvRoomSign = new THREE.Mesh(new THREE.BoxGeometry(3.6, 0.7, 0.15), new THREE.MeshBasicMaterial({ map: createSignTexture('🛋️ هال و نشیمن', '#0f172a', '#facc15') }));
    tvRoomSign.position.set(0, 4.15, -10.7);
    ctx.worldGroup.add(hallRug, rugBorder, bookcase, plantHall, tvRoomSign);

    // ۸. اتاق بازی و کمد لباس (شمال‌شرق)
    const playRug = new THREE.Mesh(new THREE.PlaneGeometry(6.4, 5.2), new THREE.MeshStandardMaterial({ color: 0x818cf8, roughness: 0.88 }));
    playRug.rotation.x = -Math.PI / 2;
    playRug.position.set(8.6, 0.025, -6.2);
    const playRoomSign = new THREE.Mesh(new THREE.BoxGeometry(3.6, 0.7, 0.15), new THREE.MeshBasicMaterial({ map: createSignTexture('🎮 اتاق بازی', '#065f46', '#34d399') }));
    playRoomSign.position.set(8.6, 3.85, -10.7);
    ctx.worldGroup.add(playRug, playRoomSign);

    const wardrobe = new THREE.Group();
    wardrobe.position.set(11.1, 0, -9.5);
    const wBody = new THREE.Mesh(new THREE.BoxGeometry(2.1, 2.9, 1.05), trimMat);
    wBody.position.y = 1.45;
    wBody.castShadow = true;
    const wDoorLine = new THREE.Mesh(new THREE.BoxGeometry(0.05, 2.6, 1.08), new THREE.MeshStandardMaterial({ color: 0x451a03 }));
    wDoorLine.position.y = 1.45;
    const wSign = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.65, 0.15), new THREE.MeshBasicMaterial({ map: createSignTexture('👗 کمد لباس', '#4f46e5', '#fff') }));
    wSign.position.set(0, 3.25, 0.1);
    wardrobe.add(wBody, wDoorLine, wSign);
    ctx.worldGroup.add(wardrobe);
    ctx.obstacles.push({ minX: 9.9, maxX: 12.3, minZ: -10.4, maxZ: -8.7 });

    if (homeData.isMine) {
        wardrobe.userData = { action: 'wardrobe' };
        ctx.interactables.push(wardrobe);
    }

    ctx.addPortal(0, 9.2, 'plaza', '🏙️ خروج به میدان شهر', 0x10b981);
}
