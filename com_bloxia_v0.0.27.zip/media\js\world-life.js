import * as THREE from './three/three.module.js';

const SHARED_GEO = {
    box: new THREE.BoxGeometry(1, 1, 1),
    cyl: new THREE.CylinderGeometry(1, 1, 1, 16),
    sphere: new THREE.SphereGeometry(1, 14, 12),
    cone: new THREE.ConeGeometry(1, 1, 10),
    torus: new THREE.TorusGeometry(1, 0.14, 8, 20)
};

function lerpAngle(a, b, t) {
    let diff = ((b - a + Math.PI) % (Math.PI * 2)) - Math.PI;
    if (diff < -Math.PI) diff += Math.PI * 2;
    return a + diff * Math.min(1, t);
}

function buildWheel(radius, width, rimColor = 0xe2e8f0) {
    const g = new THREE.Group();
    const tire = new THREE.Mesh(SHARED_GEO.cyl, new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.85 }));
    tire.scale.set(radius, width, radius);
    tire.rotation.z = Math.PI / 2;
    tire.castShadow = true;
    const rim = new THREE.Mesh(SHARED_GEO.cyl, new THREE.MeshStandardMaterial({ color: rimColor, metalness: 0.5 }));
    rim.scale.set(radius * 0.55, width * 1.06, radius * 0.55);
    rim.rotation.z = Math.PI / 2;
    g.add(tire, rim);
    return g;
}

export function buildCarMesh(bodyColor = 0xef4444, isTaxi = false) {
    const g = new THREE.Group();
    const bodyMat = new THREE.MeshStandardMaterial({ color: bodyColor, roughness: 0.35, metalness: 0.15 });
    const glassMat = new THREE.MeshStandardMaterial({ color: 0x93c5fd, roughness: 0.15, metalness: 0.25 });
    const darkMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.7 });

    const chassis = new THREE.Mesh(SHARED_GEO.box, bodyMat);
    chassis.scale.set(1.9, 0.65, 3.8);
    chassis.position.y = 0.62;
    chassis.castShadow = true;

    const cabin = new THREE.Mesh(SHARED_GEO.box, bodyMat);
    cabin.scale.set(1.62, 0.62, 2.0);
    cabin.position.set(0, 1.2, -0.15);
    cabin.castShadow = true;

    const winFront = new THREE.Mesh(SHARED_GEO.box, glassMat);
    winFront.scale.set(1.48, 0.48, 2.06);
    winFront.position.set(0, 1.2, -0.15);
    const winSide = new THREE.Mesh(SHARED_GEO.box, glassMat);
    winSide.scale.set(1.66, 0.46, 1.65);
    winSide.position.set(0, 1.2, -0.15);

    const bumperF = new THREE.Mesh(SHARED_GEO.box, darkMat);
    bumperF.scale.set(1.96, 0.2, 0.22);
    bumperF.position.set(0, 0.36, 1.9);
    const bumperB = bumperF.clone();
    bumperB.position.z = -1.9;

    const headMat = new THREE.MeshBasicMaterial({ color: 0xfef08a });
    const tailMat = new THREE.MeshBasicMaterial({ color: 0xef4444 });
    [-0.65, 0.65].forEach(lx => {
        const hl = new THREE.Mesh(SHARED_GEO.sphere, headMat);
        hl.scale.set(0.16, 0.14, 0.08);
        hl.position.set(lx, 0.66, 1.91);
        const tl = new THREE.Mesh(SHARED_GEO.box, tailMat);
        tl.scale.set(0.32, 0.14, 0.08);
        tl.position.set(lx, 0.68, -1.91);
        g.add(hl, tl);
    });

    if (isTaxi) {
        const sign = new THREE.Mesh(SHARED_GEO.box, new THREE.MeshStandardMaterial({ color: 0xfef08a, emissive: 0xfacc15, emissiveIntensity: 0.6 }));
        sign.scale.set(0.65, 0.22, 0.28);
        sign.position.set(0, 1.62, -0.1);
        g.add(sign);
    }

    const wheels = [];
    [[-0.95, 1.15], [0.95, 1.15], [-0.95, -1.15], [0.95, -1.15]].forEach(([wx, wz]) => {
        const w = buildWheel(0.38, 0.24);
        w.position.set(wx, 0.38, wz);
        wheels.push(w);
        g.add(w);
    });

    g.add(chassis, cabin, winFront, winSide, bumperF, bumperB);
    return { mesh: g, wheels };
}

export function buildMotorcycleMesh(color = 0x2563eb, helmetColor = 0xf43f5e) {
    const g = new THREE.Group();
    const bodyMat = new THREE.MeshStandardMaterial({ color, roughness: 0.35, metalness: 0.2 });
    const metalMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.65, roughness: 0.3 });

    const body = new THREE.Mesh(SHARED_GEO.box, bodyMat);
    body.scale.set(0.46, 0.45, 1.55);
    body.position.set(0, 0.62, 0);
    body.castShadow = true;

    const handlebar = new THREE.Mesh(SHARED_GEO.cyl, metalMat);
    handlebar.scale.set(0.04, 0.82, 0.04);
    handlebar.rotation.z = Math.PI / 2;
    handlebar.position.set(0, 0.98, 0.52);

    const hl = new THREE.Mesh(SHARED_GEO.sphere, new THREE.MeshBasicMaterial({ color: 0xfef08a }));
    hl.scale.set(0.14, 0.14, 0.1);
    hl.position.set(0, 0.85, 0.82);

    const riderTorso = new THREE.Mesh(SHARED_GEO.cyl, new THREE.MeshStandardMaterial({ color: 0x1e293b }));
    riderTorso.scale.set(0.24, 0.58, 0.2);
    riderTorso.position.set(0, 1.12, -0.08);
    riderTorso.rotation.x = 0.28;
    const helmet = new THREE.Mesh(SHARED_GEO.sphere, new THREE.MeshStandardMaterial({ color: helmetColor, roughness: 0.25 }));
    helmet.scale.set(0.24, 0.25, 0.26);
    helmet.position.set(0, 1.52, 0.05);

    const wF = buildWheel(0.36, 0.16);
    wF.position.set(0, 0.36, 0.72);
    const wB = buildWheel(0.36, 0.18);
    wB.position.set(0, 0.36, -0.72);

    g.add(body, handlebar, hl, riderTorso, helmet, wF, wB);
    return { mesh: g, wheels: [wF, wB] };
}

export function buildBicycleMesh(frameColor = 0x10b981, shirtColor = 0xf97316) {
    const g = new THREE.Group();
    const frameMat = new THREE.MeshStandardMaterial({ color: frameColor, roughness: 0.4 });
    const tireMat = new THREE.MeshStandardMaterial({ color: 0x1e293b });

    const wF = new THREE.Mesh(SHARED_GEO.torus, tireMat);
    wF.scale.set(0.34, 0.34, 0.34);
    wF.rotation.y = Math.PI / 2;
    wF.position.set(0, 0.36, 0.62);

    const wB = wF.clone();
    wB.position.z = -0.62;

    const bar = new THREE.Mesh(SHARED_GEO.cyl, frameMat);
    bar.scale.set(0.035, 1.15, 0.035);
    bar.rotation.x = Math.PI / 2.2;
    bar.position.set(0, 0.58, 0);

    const handle = new THREE.Mesh(SHARED_GEO.cyl, new THREE.MeshStandardMaterial({ color: 0xe2e8f0 }));
    handle.scale.set(0.03, 0.65, 0.03);
    handle.rotation.z = Math.PI / 2;
    handle.position.set(0, 0.95, 0.5);

    const rider = new THREE.Mesh(SHARED_GEO.cyl, new THREE.MeshStandardMaterial({ color: shirtColor }));
    rider.scale.set(0.21, 0.55, 0.18);
    rider.position.set(0, 1.08, -0.12);
    rider.rotation.x = 0.22;
    const head = new THREE.Mesh(SHARED_GEO.sphere, new THREE.MeshStandardMaterial({ color: 0xffdbac }));
    head.scale.set(0.2, 0.2, 0.2);
    head.position.set(0, 1.48, -0.02);
    const cap = new THREE.Mesh(SHARED_GEO.sphere, frameMat);
    cap.scale.set(0.22, 0.14, 0.22);
    cap.position.set(0, 1.58, -0.02);

    g.add(wF, wB, bar, handle, rider, head, cap);
    return { mesh: g, wheels: [] };
}

function buildDogMesh(color = 0xd97706, earColor = 0x92400e) {
    const g = new THREE.Group();
    const fur = new THREE.MeshStandardMaterial({ color, roughness: 0.78 });
    const earMat = new THREE.MeshStandardMaterial({ color: earColor, roughness: 0.78 });
    const dark = new THREE.MeshBasicMaterial({ color: 0x0f172a });

    const body = new THREE.Mesh(SHARED_GEO.box, fur);
    body.scale.set(0.42, 0.38, 0.76);
    body.position.set(0, 0.46, 0);
    body.castShadow = true;

    const headPivot = new THREE.Group();
    headPivot.position.set(0, 0.68, 0.42);

    const head = new THREE.Mesh(SHARED_GEO.box, fur);
    head.scale.set(0.36, 0.34, 0.36);
    head.castShadow = true;

    const snout = new THREE.Mesh(SHARED_GEO.box, new THREE.MeshStandardMaterial({ color: 0xfef3c7 }));
    snout.scale.set(0.2, 0.16, 0.2);
    snout.position.set(0, -0.06, 0.2);
    const nose = new THREE.Mesh(SHARED_GEO.sphere, dark);
    nose.scale.setScalar(0.05);
    nose.position.set(0, -0.01, 0.3);

    const tongue = new THREE.Mesh(SHARED_GEO.box, new THREE.MeshBasicMaterial({ color: 0xfb7185 }));
    tongue.scale.set(0.08, 0.03, 0.1);
    tongue.position.set(0, -0.14, 0.24);
    tongue.rotation.x = 0.35;

    [-0.19, 0.19].forEach(ex => {
        const ear = new THREE.Mesh(SHARED_GEO.box, earMat);
        ear.scale.set(0.09, 0.22, 0.14);
        ear.position.set(ex, 0.02, -0.02);
        headPivot.add(ear);
    });
    [-0.09, 0.09].forEach(ex => {
        const eye = new THREE.Mesh(SHARED_GEO.sphere, dark);
        eye.scale.setScalar(0.036);
        eye.position.set(ex, 0.05, 0.18);
        headPivot.add(eye);
    });
    headPivot.add(head, snout, nose, tongue);

    const collar = new THREE.Mesh(SHARED_GEO.box, new THREE.MeshStandardMaterial({ color: 0xef4444 }));
    collar.scale.set(0.38, 0.08, 0.38);
    collar.position.set(0, 0.54, 0.34);

    const tail = new THREE.Mesh(SHARED_GEO.cyl, earMat);
    tail.scale.set(0.045, 0.32, 0.045);
    tail.position.set(0, 0.62, -0.42);
    tail.rotation.x = -0.6;

    const legs = [];
    [[-0.14, 0.24], [0.14, 0.24], [-0.14, -0.24], [0.14, -0.24]].forEach(([lx, lz]) => {
        const leg = new THREE.Mesh(SHARED_GEO.cyl, fur);
        leg.scale.set(0.06, 0.3, 0.06);
        leg.position.set(lx, 0.16, lz);
        legs.push(leg);
        g.add(leg);
    });

    g.add(body, headPivot, collar, tail);
    return { mesh: g, head: headPivot, tail, legs };
}

function buildCatMesh(color = 0xf97316) {
    const g = new THREE.Group();
    const fur = new THREE.MeshStandardMaterial({ color, roughness: 0.76 });
    const eyeMat = new THREE.MeshBasicMaterial({ color: 0x22c55e });

    const body = new THREE.Mesh(SHARED_GEO.sphere, fur);
    body.scale.set(0.22, 0.2, 0.4);
    body.position.set(0, 0.34, 0);
    body.castShadow = true;

    const headPivot = new THREE.Group();
    headPivot.position.set(0, 0.5, 0.32);

    const head = new THREE.Mesh(SHARED_GEO.sphere, fur);
    head.scale.set(0.2, 0.19, 0.19);
    head.castShadow = true;

    [-0.11, 0.11].forEach(ex => {
        const ear = new THREE.Mesh(SHARED_GEO.cone, fur);
        ear.scale.set(0.075, 0.16, 0.075);
        ear.position.set(ex, 0.18, 0);
        const eye = new THREE.Mesh(SHARED_GEO.sphere, eyeMat);
        eye.scale.setScalar(0.032);
        eye.position.set(ex * 0.68, 0.03, 0.16);
        headPivot.add(ear, eye);
    });
    const nose = new THREE.Mesh(SHARED_GEO.sphere, new THREE.MeshBasicMaterial({ color: 0xf472b6 }));
    nose.scale.setScalar(0.025);
    nose.position.set(0, -0.01, 0.185);
    headPivot.add(head, nose);

    const tail = new THREE.Mesh(SHARED_GEO.cyl, fur);
    tail.scale.set(0.036, 0.42, 0.036);
    tail.position.set(0, 0.52, -0.36);
    tail.rotation.x = -0.35;

    const legs = [];
    [[-0.1, 0.18], [0.1, 0.18], [-0.1, -0.18], [0.1, -0.18]].forEach(([lx, lz]) => {
        const leg = new THREE.Mesh(SHARED_GEO.cyl, fur);
        leg.scale.set(0.045, 0.24, 0.045);
        leg.position.set(lx, 0.12, lz);
        legs.push(leg);
        g.add(leg);
    });

    g.add(body, headPivot, tail);
    return { mesh: g, head: headPivot, tail, legs };
}

function buildBirdMesh(color = 0x38bdf8, wingColor = 0xe0f2fe) {
    const g = new THREE.Group();
    const bodyMat = new THREE.MeshStandardMaterial({ color, roughness: 0.55 });
    const wingMat = new THREE.MeshStandardMaterial({ color: wingColor, roughness: 0.55 });
    const beakMat = new THREE.MeshStandardMaterial({ color: 0xfacc15 });
    const eyeMat = new THREE.MeshBasicMaterial({ color: 0x0f172a });

    const body = new THREE.Mesh(SHARED_GEO.sphere, bodyMat);
    body.scale.set(0.2, 0.17, 0.32);
    body.castShadow = true;

    const head = new THREE.Mesh(SHARED_GEO.sphere, bodyMat);
    head.scale.set(0.14, 0.14, 0.14);
    head.position.set(0, 0.12, 0.22);

    [-0.08, 0.08].forEach(ex => {
        const eye = new THREE.Mesh(SHARED_GEO.sphere, eyeMat);
        eye.scale.setScalar(0.022);
        eye.position.set(ex, 0.14, 0.31);
        g.add(eye);
    });

    const beak = new THREE.Mesh(SHARED_GEO.cone, beakMat);
    beak.scale.set(0.055, 0.14, 0.055);
    beak.rotation.x = Math.PI / 2;
    beak.position.set(0, 0.11, 0.38);

    const tail = new THREE.Mesh(SHARED_GEO.box, wingMat);
    tail.scale.set(0.16, 0.03, 0.22);
    tail.position.set(0, 0.04, -0.32);
    tail.rotation.x = 0.2;

    const wingL = new THREE.Mesh(SHARED_GEO.box, wingMat);
    wingL.scale.set(0.42, 0.035, 0.2);
    wingL.position.set(-0.24, 0.05, 0);
    const wingR = wingL.clone();
    wingR.position.x = 0.24;

    g.add(body, head, beak, tail, wingL, wingR);
    return { mesh: g, wingL, wingR };
}

function createBubbleEl() {
    if (typeof document === 'undefined') return null;
    const layer = document.getElementById('labels-layer');
    if (!layer) return null;
    const el = document.createElement('div');
    el.className = 'animal-bubble';
    layer.appendChild(el);
    return el;
}

export class CityLifeManager {
    constructor(app) {
        this.app = app;
        this.group = new THREE.Group();
        this.app.scene.add(this.group);
        this.vehicles = [];
        this.animals = [];
        this.skyBirds = [];
        this.groundBirds = [];
    }

    clear() {
        this.animals.forEach(a => { if (a.bubbleEl) a.bubbleEl.remove(); });
        this.groundBirds.forEach(b => { if (b.bubbleEl) b.bubbleEl.remove(); });
        this.group.clear();
        this.vehicles = [];
        this.animals = [];
        this.skyBirds = [];
        this.groundBirds = [];
    }

    spawnForPlaza() {
        this.clear();

        // ۱. وسایل نقلیه بلوار حلقه‌ای میدان مرکزی
        const ringVehicles = [
            { builder: () => buildCarMesh(0xef4444, false), radius: 20.3, angle: 0.2, speed: 0.34, dir: 1 },
            { builder: () => buildCarMesh(0xfacc15, true),  radius: 20.3, angle: 2.3, speed: 0.34, dir: 1 },
            { builder: () => buildCarMesh(0x3b82f6, false), radius: 20.3, angle: 4.4, speed: 0.34, dir: 1 },
            { builder: () => buildMotorcycleMesh(0x8b5cf6, 0x22d3ee), radius: 22.9, angle: 1.1, speed: 0.44, dir: -1 },
            { builder: () => buildBicycleMesh(0x10b981, 0xf97316),    radius: 23.4, angle: 3.8, speed: 0.24, dir: -1 }
        ];
        ringVehicles.forEach(cfg => {
            const v = cfg.builder();
            this.group.add(v.mesh);
            this.vehicles.push({ ...v, mode: 'ring', ...cfg });
        });

        // ۲. مسیرهای حلقه‌ای پیوسته وسایل نقلیه در تمام خیابان‌های اطراف شهر (شمال، جنوب، شرق و غرب!)
        const grandLoop = [[-54.5, -36.6], [96.6, -36.6], [96.6, 38.6], [-54.5, 38.6]];
        const perimeterLoop = [[99.4, -39.4], [-89.4, -39.4], [-89.4, 69.4], [99.4, 69.4]];
        const westNeighborhoodLoop = [[-86.6, -1.4], [-57.4, -1.4], [-57.4, 38.6], [-86.6, 38.6]];
        const southBaharGolestanLoop = [[1.4, 41.4], [54.6, 41.4], [54.6, 66.6], [1.4, 66.6]];

        const loopSpecs = [
            { builder: () => buildCarMesh(0x14b8a6, false), waypoints: grandLoop, startSeg: 0, progress: 0.15, speed: 10.5 },
            { builder: () => buildCarMesh(0xa855f7, false), waypoints: grandLoop, startSeg: 2, progress: 0.35, speed: 10.5 },
            { builder: () => buildMotorcycleMesh(0xf97316, 0xffffff), waypoints: grandLoop, startSeg: 1, progress: 0.5, speed: 12.5 },

            { builder: () => buildCarMesh(0xfacc15, true),  waypoints: perimeterLoop, startSeg: 0, progress: 0.25, speed: 11.2 },
            { builder: () => buildCarMesh(0x2563eb, false), waypoints: perimeterLoop, startSeg: 2, progress: 0.4, speed: 11.2 },
            { builder: () => buildMotorcycleMesh(0xef4444, 0xfef08a), waypoints: perimeterLoop, startSeg: 3, progress: 0.2, speed: 13.0 },

            { builder: () => buildCarMesh(0xf43f5e, false), waypoints: westNeighborhoodLoop, startSeg: 0, progress: 0.3, speed: 8.8 },
            { builder: () => buildBicycleMesh(0x22c55e, 0xfacc15), waypoints: westNeighborhoodLoop, startSeg: 2, progress: 0.5, speed: 5.6 },

            { builder: () => buildCarMesh(0x0ea5e9, false), waypoints: southBaharGolestanLoop, startSeg: 0, progress: 0.2, speed: 9.2 },
            { builder: () => buildMotorcycleMesh(0x10b981, 0x38bdf8), waypoints: southBaharGolestanLoop, startSeg: 1, progress: 0.6, speed: 11.0 },
            { builder: () => buildBicycleMesh(0xec4899, 0x38bdf8), waypoints: southBaharGolestanLoop, startSeg: 2, progress: 0.4, speed: 5.4 }
        ];

        loopSpecs.forEach(spec => {
            const v = spec.builder();
            const pts = spec.waypoints;
            const seg = spec.startSeg % pts.length;
            const pA = pts[seg];
            const pB = pts[(seg + 1) % pts.length];
            const sx = pA[0] + (pB[0] - pA[0]) * spec.progress;
            const sz = pA[1] + (pB[1] - pA[1]) * spec.progress;
            const rotY = Math.atan2(pB[0] - pA[0], pB[1] - pA[1]);
            v.mesh.position.set(sx, 0.05, sz);
            v.mesh.rotation.y = rotY;
            this.group.add(v.mesh);
            this.vehicles.push({
                ...v,
                mode: 'loop',
                waypoints: pts,
                segIdx: seg,
                segDist: Math.hypot(pB[0] - pA[0], pB[1] - pA[1]) * spec.progress,
                speed: spec.speed,
                rotY
            });
        });

        // ۳. سگ‌ها و گربه‌های واکنش‌گرا در میدان، خیابان مسکونی و پارک بزرگ
        const petDefs = [
            { kind: 'dog', temperament: 'friendly', label: '🐶 هاپ هاپ! ❤️', build: () => buildDogMesh(0xd97706, 0x92400e), cx: 6.2, cz: 9.2, r: 5.0, speed: 2.4 },
            { kind: 'dog', temperament: 'friendly', label: '🐶 بیا بازی! 🐾', build: () => buildDogMesh(0xf8fafc, 0x1e293b), cx: -13, cz: 35.8, r: 5.5, speed: 2.3 },
            { kind: 'dog', temperament: 'friendly', label: '🐶 هاپ! خوش اومدی ✨', build: () => buildDogMesh(0x94a3b8, 0x1e293b), cx: 61, cz: 4, r: 7.0, speed: 2.6 },
            { kind: 'dog', temperament: 'friendly', label: '🐶 دوست خوبم! ❤️', build: () => buildDogMesh(0xfbbf24, 0x78350f), cx: -48, cz: 4, r: 5.5, speed: 2.3 },

            { kind: 'cat', temperament: 'friendly', label: '🐱 میو~ پُرپُر 💕', build: () => buildCatMesh(0xf97316), cx: -6.2, cz: 8.8, r: 4.5, speed: 1.6 },
            { kind: 'cat', temperament: 'friendly', label: '🐱 میو! نازم کن ✨', build: () => buildCatMesh(0xfef3c7), cx: -24, cz: 10.5, r: 4.2, speed: 1.5 },
            { kind: 'cat', temperament: 'playful',  label: '🙀 میو! به من نرسیدی!', build: () => buildCatMesh(0x1e293b), cx: 14, cz: 35.8, r: 4.8, speed: 2.1 },
            { kind: 'cat', temperament: 'friendly', label: '🐱 پُرپُر~ 🐾', build: () => buildCatMesh(0xfda4af), cx: 70, cz: 13, r: 4.8, speed: 1.6 }
        ];

        petDefs.forEach((pd, i) => {
            const p = pd.build();
            p.mesh.position.set(pd.cx, 0, pd.cz);
            const animalObj = {
                ...p,
                kind: pd.kind,
                temperament: pd.temperament,
                greetText: pd.label,
                cx: pd.cx, cz: pd.cz, r: pd.r, speed: pd.speed,
                tx: pd.cx + 1.5, tz: pd.cz + 1.0,
                pause: i * 0.5,
                petBoostTimer: 0,
                bubbleEl: createBubbleEl()
            };
            p.mesh.userData = { action: 'pet_animal', animalRef: animalObj };
            this.group.add(p.mesh);
            this.app.interactables.push(p.mesh);
            this.animals.push(animalObj);
        });

        // ۴. پرنده‌های خوش‌فرم در آسمان پارک، شهربازی و بلوار غربی (خارج از مرکز دوربین برای دید تمیز!)
        const skyFlocks = [
            { cx: 68, cz: -2, r: 14, h: 12.5, col: 0x38bdf8, wing: 0xe0f2fe },
            { cx: 68, cz: -2, r: 18, h: 14.0, col: 0xfef08a, wing: 0xffffff },
            { cx: 68, cz: -2, r: 11, h: 11.5, col: 0x34d399, wing: 0xd1fae5 },
            { cx: 0,  cz: -60, r: 15, h: 14.5, col: 0xf472b6, wing: 0xfce7f3 },
            { cx: 0,  cz: -60, r: 19, h: 16.0, col: 0x60a5fa, wing: 0xdbeafe },
            { cx: -64, cz: 10, r: 15, h: 13.0, col: 0xf8fafc, wing: 0xe2e8f0 }
        ];
        skyFlocks.forEach((sf, i) => {
            const b = buildBirdMesh(sf.col, sf.wing);
            this.group.add(b.mesh);
            this.skyBirds.push({
                ...b,
                cx: sf.cx, cz: sf.cz,
                radius: sf.r,
                height: sf.h,
                angle: (i / skyFlocks.length) * Math.PI * 2,
                speed: 0.52 + (i % 3) * 0.1
            });
        });

        // ۵. پرنده‌های روی زمین که با نزدیک شدن کاراکترها پر می‌کشند و جابه‌جا می‌شوند
        const groundSpots = [
            [-5.4, 5.2], [5.6, -5.2], [-15.5, 2.5], [15.5, -2.5],
            [-6, 36.0], [60, 2.5], [63, 4.2], [67, -4.5]
        ];
        groundSpots.forEach(([gx, gz], idx) => {
            const b = buildBirdMesh(idx % 2 === 0 ? 0x60a5fa : 0xfacc15, 0xffffff);
            b.mesh.position.set(gx, 0.18, gz);
            this.group.add(b.mesh);
            this.groundBirds.push({
                ...b,
                homeX: gx, homeZ: gz,
                perchX: gx, perchZ: gz,
                targetPerchX: gx, targetPerchZ: gz,
                hopPhase: idx * 1.3,
                flyHeight: 0,
                scaredTimer: 0,
                bubbleEl: createBubbleEl()
            });
        });
    }

    petAnimal(animal) {
        if (!animal) return;
        animal.petBoostTimer = 3.6;
    }

    isPedestrianNear(x, z, radius = 3.8) {
        if (this.app.myRig) {
            const p = this.app.myRig.mesh.position;
            if (Math.hypot(p.x - x, p.z - z) < radius) return true;
        }
        for (const n of this.app.npcList) {
            const np = n.rig.mesh.position;
            if (Math.hypot(np.x - x, np.z - z) < radius * 0.85) return true;
        }
        return false;
    }

    findNearestCharacter(x, z, maxDist) {
        let best = null;
        let bestDist = maxDist;
        if (this.app.myRig) {
            const p = this.app.myRig.mesh.position;
            const d = Math.hypot(p.x - x, p.z - z);
            if (d < bestDist) {
                bestDist = d;
                best = { x: p.x, z: p.z, isPlayer: true, dist: d };
            }
        }
        for (const n of this.app.npcList) {
            const np = n.rig.mesh.position;
            const d = Math.hypot(np.x - x, np.z - z);
            // اولویت اندکی بیشتر با بازیکن اصلی است تا واکنش حیوانات به کاربر ملموس‌تر باشد
            const effectiveD = best?.isPlayer ? d + 1.2 : d;
            if (effectiveD < bestDist) {
                bestDist = d;
                best = { x: np.x, z: np.z, isPlayer: false, dist: d };
            }
        }
        return best;
    }

    projectBubble(el, worldX, worldY, worldZ, text, camera) {
        if (!el) return;
        if (!text || !camera) {
            el.style.display = 'none';
            return;
        }
        const v = new THREE.Vector3(worldX, worldY, worldZ);
        v.project(camera);
        if (v.z < 1) {
            el.textContent = text;
            el.style.left = `${(v.x * 0.5 + 0.5) * window.innerWidth}px`;
            el.style.top = `${(-v.y * 0.5 + 0.5) * window.innerHeight}px`;
            el.style.display = 'block';
        } else {
            el.style.display = 'none';
        }
    }

    update(dt, time, camera = null) {
        if (this.app.currentZone !== 'plaza') return;

        // ۱. حرکت خودروها، موتورها و دوچرخه‌ها در میدان و تمام خیابان‌های اطراف + ترمز هوشمند جلوی عابران
        this.vehicles.forEach(v => {
            if (v.mode === 'ring') {
                const lookAheadAngle = v.angle + v.dir * 0.18;
                const checkX = Math.cos(lookAheadAngle) * v.radius;
                const checkZ = Math.sin(lookAheadAngle) * v.radius;
                if (this.isPedestrianNear(checkX, checkZ, 3.6)) return;

                v.angle += v.dir * v.speed * dt;
                const nx = Math.cos(v.angle) * v.radius;
                const nz = Math.sin(v.angle) * v.radius;
                v.mesh.position.set(nx, 0.05, nz);
                v.mesh.rotation.y = Math.atan2(-Math.sin(v.angle) * v.dir, Math.cos(v.angle) * v.dir);
                v.wheels.forEach(w => { w.rotation.x += dt * 7.5; });
            } else if (v.mode === 'loop') {
                const pts = v.waypoints;
                const pA = pts[v.segIdx];
                const pB = pts[(v.segIdx + 1) % pts.length];
                const dx = pB[0] - pA[0];
                const dz = pB[1] - pA[1];
                const segLen = Math.hypot(dx, dz) || 1;
                const ux = dx / segLen;
                const uz = dz / segLen;

                const checkX = v.mesh.position.x + ux * 3.8;
                const checkZ = v.mesh.position.z + uz * 3.8;
                if (this.isPedestrianNear(checkX, checkZ, 3.6)) return;

                v.segDist += v.speed * dt;
                while (v.segDist >= segLen) {
                    v.segDist -= segLen;
                    v.segIdx = (v.segIdx + 1) % pts.length;
                    const nA = pts[v.segIdx];
                    const nB = pts[(v.segIdx + 1) % pts.length];
                    const nLen = Math.hypot(nB[0] - nA[0], nB[1] - nA[1]) || 1;
                    if (v.segDist < nLen) break;
                }
                const curA = pts[v.segIdx];
                const curB = pts[(v.segIdx + 1) % pts.length];
                const cdx = curB[0] - curA[0];
                const cdz = curB[1] - curA[1];
                const curLen = Math.hypot(cdx, cdz) || 1;
                const tSeg = v.segDist / curLen;
                const nx = curA[0] + cdx * tSeg;
                const nz = curA[1] + cdz * tSeg;
                const targetRotY = Math.atan2(cdx, cdz);
                v.rotY = lerpAngle(v.rotY, targetRotY, dt * 8.5);
                v.mesh.position.set(nx, 0.05, nz);
                v.mesh.rotation.y = v.rotY;
                v.wheels.forEach(w => { w.rotation.x += dt * 8.0; });
            }
        });

        // ۲. واکنش زنده سگ‌ها و گربه‌ها به حضور بازیکن و شهروندان (NPC)
        this.animals.forEach((a, idx) => {
            if (a.petBoostTimer > 0) a.petBoostTimer -= dt;
            const nearChar = this.findNearestCharacter(a.mesh.position.x, a.mesh.position.z, a.kind === 'dog' ? 8.2 : 7.0);
            let bubbleText = null;
            let moveSpeed = a.speed;
            let tailSpeed = 10;
            let tailAmp = 0.42;
            let hopY = 0;

            if (a.petBoostTimer > 0) {
                bubbleText = a.kind === 'dog' ? '🐶💕 آخیش! چقدر کیف داد!' : '🐱💖 پُرپُر~ دوستت دارم!';
                hopY = Math.abs(Math.sin(time * 12 + idx)) * 0.24;
                tailSpeed = 28;
                tailAmp = 0.85;
            } else if (nearChar) {
                if (a.kind === 'dog') {
                    // سگ با دیدن کاراکتر با ذوق به سمت او می‌دود، دمش را تند تکان می‌دهد و بالا و پایین می‌پرد!
                    const cdx = nearChar.x - a.mesh.position.x;
                    const cdz = nearChar.z - a.mesh.position.z;
                    if (nearChar.dist > 2.1) {
                        const stopDist = nearChar.dist - 1.85;
                        const ang = Math.atan2(cdz, cdx);
                        const candX = a.mesh.position.x + Math.cos(ang) * Math.min(stopDist, 3.5);
                        const candZ = a.mesh.position.z + Math.sin(ang) * Math.min(stopDist, 3.5);
                        if (Math.hypot(candX - a.cx, candZ - a.cz) <= a.r + 3.5 && !this.app.checkCollision(candX, candZ)) {
                            a.tx = candX;
                            a.tz = candZ;
                        }
                        moveSpeed = a.speed * 1.45;
                    } else {
                        a.tx = a.mesh.position.x;
                        a.tz = a.mesh.position.z;
                        a.mesh.rotation.y = lerpAngle(a.mesh.rotation.y, Math.atan2(cdx, cdz), dt * 9);
                        hopY = Math.abs(Math.sin(time * 10.5 + idx)) * 0.2;
                    }
                    a.head.rotation.z = Math.sin(time * 7.5 + idx) * 0.24;
                    tailSpeed = 26;
                    tailAmp = 0.82;
                    if (nearChar.dist < 5.5) bubbleText = a.greetText;
                } else if (a.temperament === 'playful') {
                    // گربه بازیگوش با نزدیک شدن کاراکتر یک پرش بامزه می‌زند و چند قدم آن‌طرف‌تر می‌دود!
                    const awayX = a.mesh.position.x - nearChar.x;
                    const awayZ = a.mesh.position.z - nearChar.z;
                    const awayLen = Math.hypot(awayX, awayZ) || 1;
                    if (nearChar.dist < 3.4) {
                        const candX = a.cx + (awayX / awayLen) * Math.min(a.r, 4.2);
                        const candZ = a.cz + (awayZ / awayLen) * Math.min(a.r, 4.2);
                        if (!this.app.checkCollision(candX, candZ)) {
                            a.tx = candX;
                            a.tz = candZ;
                        }
                        moveSpeed = a.speed * 1.65;
                        hopY = Math.abs(Math.sin(time * 13)) * 0.14;
                    }
                    bubbleText = nearChar.dist < 4.8 ? a.greetText : null;
                    tailSpeed = 18;
                    tailAmp = 0.65;
                } else {
                    // گربه‌های مهربان جلو می‌آیند، دم خود را سیخ و لرزان می‌گیرند و پُرپُر می‌کنند!
                    const cdx = nearChar.x - a.mesh.position.x;
                    const cdz = nearChar.z - a.mesh.position.z;
                    if (nearChar.dist > 1.9) {
                        const ang = Math.atan2(cdz, cdx);
                        const candX = a.mesh.position.x + Math.cos(ang) * 1.5;
                        const candZ = a.mesh.position.z + Math.sin(ang) * 1.5;
                        if (Math.hypot(candX - a.cx, candZ - a.cz) <= a.r + 2.5 && !this.app.checkCollision(candX, candZ)) {
                            a.tx = candX;
                            a.tz = candZ;
                        }
                    } else {
                        a.tx = a.mesh.position.x;
                        a.tz = a.mesh.position.z;
                        a.mesh.rotation.y = lerpAngle(a.mesh.rotation.y, Math.atan2(cdx, cdz), dt * 8);
                        hopY = Math.abs(Math.sin(time * 6.5 + idx)) * 0.08;
                    }
                    a.head.rotation.z = Math.sin(time * 5 + idx) * 0.18;
                    tailSpeed = 16;
                    tailAmp = 0.55;
                    if (nearChar.dist < 5.0) bubbleText = a.greetText;
                }
            } else {
                a.head.rotation.z *= 0.85;
            }

            const dx = a.tx - a.mesh.position.x;
            const dz = a.tz - a.mesh.position.z;
            const dist = Math.hypot(dx, dz);
            if (dist < 0.25) {
                if (!nearChar) {
                    a.pause -= dt;
                    if (a.pause <= 0) {
                        a.pause = 1.4 + Math.random() * 2.4;
                        const ang = Math.random() * Math.PI * 2;
                        const rad = Math.random() * a.r;
                        const nx = a.cx + Math.cos(ang) * rad;
                        const nz = a.cz + Math.sin(ang) * rad;
                        if (!this.app.checkCollision(nx, nz)) {
                            a.tx = nx;
                            a.tz = nz;
                        }
                    }
                }
                a.legs.forEach(l => { l.rotation.x *= 0.8; });
                a.mesh.position.y = hopY;
            } else {
                const step = Math.min(dist, moveSpeed * dt);
                const nx = a.mesh.position.x + (dx / dist) * step;
                const nz = a.mesh.position.z + (dz / dist) * step;
                if (!this.app.checkCollision(nx, nz)) {
                    a.mesh.position.set(nx, hopY, nz);
                } else {
                    a.pause = 0;
                    a.tx = a.mesh.position.x;
                    a.tz = a.mesh.position.z;
                }
                a.mesh.rotation.y = lerpAngle(a.mesh.rotation.y, Math.atan2(dx, dz), dt * 10);
                const swing = Math.sin(time * (moveSpeed > a.speed ? 19 : 14) + idx) * 0.6;
                a.legs[0].rotation.x = swing;
                a.legs[1].rotation.x = -swing;
                a.legs[2].rotation.x = -swing;
                a.legs[3].rotation.x = swing;
            }
            a.tail.rotation.z = Math.sin(time * tailSpeed + idx) * tailAmp;
            this.projectBubble(a.bubbleEl, a.mesh.position.x, a.mesh.position.y + 1.15, a.mesh.position.z, bubbleText, camera);
        });

        // ۳. پرنده‌های در حال پرواز در آسمان
        this.skyBirds.forEach((b, i) => {
            b.angle += b.speed * dt;
            const bx = b.cx + Math.cos(b.angle) * b.radius;
            const bz = b.cz + Math.sin(b.angle) * b.radius;
            const by = b.height + Math.sin(time * 2.2 + i) * 0.45;
            b.mesh.position.set(bx, by, bz);
            b.mesh.rotation.y = Math.atan2(-Math.sin(b.angle), Math.cos(b.angle));
            const flap = Math.sin(time * 15 + i) * 0.65;
            b.wingL.rotation.z = flap;
            b.wingR.rotation.z = -flap;
        });

        // ۴. پرنده‌های روی زمین: با نزدیک شدن هر کاراکتر پر می‌کشند، جیک‌جیک می‌کنند و به نقطه امن پرواز می‌کنند!
        this.groundBirds.forEach((b, i) => {
            const nearChar = this.findNearestCharacter(b.mesh.position.x, b.mesh.position.z, 5.2);
            if (nearChar) {
                if (b.scaredTimer <= 0.1) {
                    const awayAng = Math.atan2(b.mesh.position.z - nearChar.z, b.mesh.position.x - nearChar.x) + (Math.random() - 0.5) * 0.7;
                    const candX = b.homeX + Math.cos(awayAng) * 5.2;
                    const candZ = b.homeZ + Math.sin(awayAng) * 5.2;
                    if (!this.app.checkCollision(candX, candZ)) {
                        b.targetPerchX = candX;
                        b.targetPerchZ = candZ;
                    }
                }
                b.scaredTimer = 2.2;
                b.flyHeight = Math.min(3.8, b.flyHeight + dt * 6.5);
            } else {
                b.scaredTimer = Math.max(0, b.scaredTimer - dt);
                if (b.scaredTimer <= 0) {
                    b.flyHeight = Math.max(0, b.flyHeight - dt * 2.4);
                    // بازگشت تدریجی به محدوده اولیه وقتی محیط خلوت شد
                    b.targetPerchX += (b.homeX - b.targetPerchX) * dt * 0.25;
                    b.targetPerchZ += (b.homeZ - b.targetPerchZ) * dt * 0.25;
                }
            }

            const pdx = b.targetPerchX - b.perchX;
            const pdz = b.targetPerchZ - b.perchZ;
            b.perchX += pdx * Math.min(1, dt * 2.8);
            b.perchZ += pdz * Math.min(1, dt * 2.8);

            const hop = b.flyHeight > 0.12 ? b.flyHeight : Math.abs(Math.sin(time * 4.8 + b.hopPhase)) * 0.14;
            const wanderX = b.flyHeight > 0.2 ? 0 : Math.sin(time * 0.9 + i) * 0.55;
            const wanderZ = b.flyHeight > 0.2 ? 0 : Math.cos(time * 0.9 + i) * 0.55;

            b.mesh.position.set(b.perchX + wanderX, 0.18 + hop, b.perchZ + wanderZ);
            if (Math.hypot(pdx, pdz) > 0.15) {
                b.mesh.rotation.y = Math.atan2(pdx, pdz);
            } else {
                b.mesh.rotation.y = time * 0.9 + i + Math.PI / 2;
            }
            const flap = b.flyHeight > 0.12 ? Math.sin(time * 26 + i) * 0.8 : 0.08;
            b.wingL.rotation.z = flap;
            b.wingR.rotation.z = -flap;

            const birdBubble = b.scaredTimer > 1.1 ? '🐦 جیک‌جیک!' : null;
            this.projectBubble(b.bubbleEl, b.mesh.position.x, b.mesh.position.y + 0.65, b.mesh.position.z, birdBubble, camera);
        });
    }
}
