<?php
defined('_JEXEC') or die;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Session\Session;
$mediaBase = Uri::root() . 'media/com_bloxia/';
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>Bloxia</title>
    <link rel="stylesheet" href="<?php echo $mediaBase; ?>css/game-hud.css">
</head>
<body>
    <div id="canvas-container"></div>
    <div id="labels-layer"></div>
    <div id="fade-overlay">در حال ورود...</div>

    <!-- بالا-چپ: کارت پروفایل شیشه‌ای دقیقاً مشابه طرح مرجع -->
    <div class="hud-top-left">
        <div class="profile-card" id="profile-card-box" title="مشاهده و ویرایش کاراکتر">
            <div class="avatar-circle">
                <canvas id="avatar-portrait-canvas" width="128" height="128" style="width:100%;height:100%;display:block;"></canvas>
            </div>
            <div class="profile-meta">
                <strong id="player-name-display">کاراکتر من</strong>
                <div class="profile-sub">
                    <span>Level 12</span>
                    <span class="dot">•</span>
                    <span id="zone-title-display">🏙️ میدان اصلی شهر</span>
                </div>
                <div class="xp-row">
                    <span class="xp-lbl">XP</span>
                    <div class="xp-track">
                        <div class="xp-fill" style="width: 75%;"><span>75%</span></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- بالا-راست: کپسول الماس BitBlox + سبد خرید -->
    <div class="hud-top-right">
        <div class="coc-resource-bar">
            <div class="res-icon gem-bg">💎</div>
            <span class="res-label">BitBlox:</span>
            <span class="res-value" id="bitblox-display">500</span>
        </div>
        <button class="cart-circle-btn" id="btn-open-cart" title="سبد خرید">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>
            <span class="coc-notif" id="cart-count">0</span>
        </button>
    </div>

    <!-- بالا-راست (زیر BitBlox): مینی‌مپ راداری دایره‌ای شیشه‌ای -->
    <div id="minimap-container">
        <canvas id="minimap-canvas" width="210" height="210"></canvas>
    </div>

    <!-- پایین-راست: داک عمودی ۴ دکمه‌ای مشابه طرح مرجع + منوهای بازشونده سریع -->
    <div class="hud-dock-right">
        <!-- منوی بازشونده تعامل و دوستان -->
        <div class="dock-flyout" id="flyout-social">
            <button class="flyout-btn" id="btn-open-chatroom">💬 چت‌روم</button>
            <button class="flyout-btn" id="btn-pvp-challenge">⚔️ چالش بازی</button>
            <button class="flyout-btn" id="btn-neighbors">🏘️ همسایه‌ها</button>
        </div>

        <!-- منوی بازشونده کوله/کاراکتر/چیدمان -->
        <div class="dock-flyout" id="flyout-bag">
            <button class="flyout-btn" id="btn-open-cas">👤 ظاهر کاراکتر</button>
            <button class="flyout-btn" id="btn-go-my-home">🏠 خانه من</button>
            <button class="flyout-btn" id="btn-go-plaza" style="display:none;">🏙️ میدان شهر</button>
            <button class="flyout-btn" id="btn-open-wardrobe" style="display:none;">👗 کمد لباس</button>
            <button class="flyout-btn" id="btn-toggle-inventory" style="display:none;">🛋️ چیدمان خانه</button>
        </div>

        <!-- منوی بازشونده تنظیمات جو و آب‌وهوا -->
        <div class="dock-flyout" id="flyout-settings">
            <button class="flyout-btn" id="btn-cycle-time">☀️ تغییر زمان</button>
            <button class="flyout-btn" id="btn-cycle-weather">🌤️ تغییر آب‌وهوا</button>
        </div>

        <button class="dock-sq-btn blue" id="btn-dock-social" title="دوستان، چت و بازی">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="currentColor"><path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5s-3 1.34-3 3 1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"/></svg>
        </button>
        <button class="dock-sq-btn orange" id="btn-dock-bag" title="کاراکتر، خانه و کمد">
            <svg width="25" height="25" viewBox="0 0 24 24" fill="currentColor"><path d="M17 6h-2V5a3 3 0 0 0-6 0v1H7a3 3 0 0 0-3 3v10a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3V9a3 3 0 0 0-3-3zm-7-1a1 1 0 0 1 2 0v1h-2V5zm6 11H8v-2h8v2z"/></svg>
        </button>
        <button class="dock-sq-btn green" id="btn-city-directory" title="مکان‌های شهر">
            <svg width="25" height="25" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5A2.5 2.5 0 1 1 12 6.5a2.5 2.5 0 0 1 0 5z"/></svg>
        </button>
        <button class="dock-sq-btn slate" id="btn-dock-settings" title="تنظیمات محیط و آب‌وهوا">
            <svg width="25" height="25" viewBox="0 0 24 24" fill="currentColor"><path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58a.49.49 0 0 0 .12-.61l-1.92-3.32a.49.49 0 0 0-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54a.48.48 0 0 0-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96a.49.49 0 0 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.07.62-.07.94s.02.64.07.94l-2.03 1.58a.49.49 0 0 0-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6A3.6 3.6 0 1 1 12 8.4a3.6 3.6 0 0 1 0 7.2z"/></svg>
        </button>
    </div>

    <!-- پایین-وسط: انتخاب سریع حالت چهره (خوشحال، عصبانی، ناراحت و...) + داک ایموت -->
    <div class="hud-mood-strip" id="hud-mood-strip" title="تغییر حالت چهره کاراکتر">
        <button class="mood-pill-btn active" data-mood="happy" title="خوشحال">😊</button>
        <button class="mood-pill-btn" data-mood="excited" title="ذوق‌زده">🤩</button>
        <button class="mood-pill-btn" data-mood="angry" title="عصبانی">😠</button>
        <button class="mood-pill-btn" data-mood="sad" title="ناراحت">😢</button>
        <button class="mood-pill-btn" data-mood="surprised" title="متعجب">😮</button>
    </div>

    <div class="hud-bottom-center">
        <button class="coc-emote-btn" data-emote="wave" data-text="سلام به همگی! 👋">👋</button>
        <button class="coc-emote-btn" data-emote="jump" data-text="ایول! بزن بریم 🕺">🕺</button>
        <button class="coc-emote-btn" data-emote="clap" data-text="خیلی باحال بود! 😂">😂</button>
        <button class="coc-emote-btn" data-emote="invite" data-text="دوستتون دارم! ❤️">❤️</button>
        <button class="coc-emote-btn" data-emote="prop_show" data-text="عالیه! ✨">✨</button>
    </div>

    <!-- دکمه ورود هنگام نزدیک شدن به در ساختمان -->
    <button id="portal-prompt">🚪 ورود</button>

    <!-- بنر حالت چیدمان مبلمان در خانه -->
    <div id="home-edit-banner">
        <span>🛋️ روی کف اتاق کلیک کن</span>
        <button class="coc-mini-btn" id="btn-rotate-furniture">🔄</button>
        <button class="coc-mini-btn danger" id="btn-cancel-place">✖</button>
    </div>

    <!-- کارت تعامل سریع هنگام کلیک روی بازیکن دیگر -->
    <div id="player-interact-card" class="coc-modal">
        <div class="modal-header">
            <h3 id="interact-player-name">بازیکن</h3>
            <button class="close-btn" id="btn-close-interact">✖</button>
        </div>
        <div class="direct-actions-grid">
            <button class="coc-action-btn cyan" id="btn-direct-chat">💬 چت امن</button>
            <button class="coc-action-btn pink" id="btn-direct-pvp">⚔️ دعوت به بازی</button>
            <button class="coc-action-btn amber" id="btn-direct-home">🏠 بازدید از خانه</button>
        </div>
    </div>

    <!-- پنجره مودال کناری (مشابه طرح Studio Shop) -->
    <div class="coc-modal main-panel" id="side-panel">
        <div class="modal-header">
            <h3 id="panel-title">پنل</h3>
            <button class="close-btn" id="btn-close-panel">✖</button>
        </div>
        <div id="panel-body"></div>
        <div class="cart-box" id="cart-section" style="display:none;">
            <div class="cart-summary">
                <span>🛒 سبد خرید</span>
                <span>جمع: <strong id="cart-total">0</strong> 💎</span>
            </div>
            <div class="cart-items-list" id="cart-items-list"></div>
            <button class="coc-action-btn green" id="btn-checkout-cart" style="width:100%;">💳 پرداخت با BitBlox</button>
        </div>
    </div>

    <script>
        window.BLOXIA_CSRF_TOKEN = '<?php echo Session::getFormToken(); ?>';
        window.BLOXIA_BASE_URL = '<?php echo Uri::root(); ?>';
    </script>
    <script type="module" src="<?php echo $mediaBase; ?>js/main.js"></script>
</body>
</html>
