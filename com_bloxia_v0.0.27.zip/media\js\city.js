import * as THREE from './three/three.module.js';
import { CATALOG, GAMENET_GAMES } from './bridge.js';

/* ============================================================================
   ابزارهای پایه
   ============================================================================ */
const setSRGB = (tex) => { if ('SRGBColorSpace' in THREE) tex.colorSpace = THREE.SRGBColorSpace; return tex; };

export function createSignTexture(text, bgColor = '#0f172a', borderColor = '#facc15', subText = '', wide = false) {
    const W = wide ? 2048 : 1024;
    const canvas = document.createElement('canvas');
    canvas.width = W;
    canvas.height = 256;
    const ctx = canvas.getContext('2d');

    const grad = ctx.createLinearGradient(0, 0, 0, 256);
    grad.addColorStop(0, bgColor);
    grad.addColorStop(1, '#090d16');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.roundRect(10, 10, W - 20, 236, 36);
    ctx.fill();

    ctx.strokeStyle = borderColor;
    ctx.lineWidth = 14;
    ctx.beginPath();
    ctx.roundRect(10, 10, W - 20, 236, 36);
    ctx.stroke();

    ctx.shadowColor = 'rgba(0, 0, 0, 0.85)';
    ctx.shadowBlur = 10;
    ctx.shadowOffsetY = 4;
    ctx.fillStyle = '#ffffff';
    const fs = subText ? 48 : (wide ? 112 : 60);
    ctx.font = `900 ${fs}px "Vazirmatn", Tahoma`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, W / 2, subText ? 95 : 132);

    if (subText) {
        ctx.fillStyle = '#fde047';
        ctx.font = '700 32px "Vazirmatn", Tahoma';
        ctx.fillText(subText, W / 2, 175);
    }

    const tex = new THREE.CanvasTexture(canvas);
    tex.anisotropy = 8;
    return setSRGB(tex);
}

function createClockTexture() {
    const c = document.createElement('canvas');
    c.width = c.height = 256;
    const g = c.getContext('2d');
    g.fillStyle = '#fff8e7';
    g.beginPath(); g.arc(128, 128, 120, 0, Math.PI * 2); g.fill();
    g.strokeStyle = '#7a3b2e'; g.lineWidth = 14; g.stroke();
    g.strokeStyle = '#3b2a22'; g.lineWidth = 8;
    for (let i = 0; i < 12; i++) {
        const a = (i / 12) * Math.PI * 2;
        g.beginPath();
        g.moveTo(128 + Math.sin(a) * 96, 128 - Math.cos(a) * 96);
        g.lineTo(128 + Math.sin(a) * 110, 128 - Math.cos(a) * 110);
        g.stroke();
    }
    g.lineWidth = 12;
    g.beginPath(); g.moveTo(128, 128); g.lineTo(128, 64); g.stroke();
    g.lineWidth = 8;
    g.beginPath(); g.moveTo(128, 128); g.lineTo(168, 150); g.stroke();
    return setSRGB(new THREE.CanvasTexture(c));
}

function cobbleTex(rx, ry) {
    if (!cobbleTex.canvas) {
        const c = document.createElement('canvas');
        c.width = c.height = 256;
        const g = c.getContext('2d');
        g.fillStyle = '#b8a48a';
        g.fillRect(0, 0, 256, 256);
        const cols = ['#eadcc8', '#dccab0', '#e4d4bd', '#cfbb9f'];
        for (let y = 0; y < 256; y += 32) {
            const off = (y / 32) % 2 ? 16 : 0;
            for (let x = -32; x < 256; x += 32) {
                g.fillStyle = cols[Math.abs((x >> 5) * 7 + (y >> 5) * 13) % 4];
                g.beginPath();
                g.roundRect(x + off + 2, y + 2, 28, 28, 8);
                g.fill();
            }
        }
        cobbleTex.canvas = c;
    }
    const t = setSRGB(new THREE.CanvasTexture(cobbleTex.canvas));
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.repeat.set(rx, ry);
    return t;
}

function grassTex(rep) {
    const c = document.createElement('canvas');
    c.width = c.height = 256;
    const g = c.getContext('2d');
    g.fillStyle = '#66bb4a';
    g.fillRect(0, 0, 256, 256);
    for (let i = 0; i < 160; i++) {
        g.fillStyle = i % 2 === 0 ? 'rgba(82,168,58,0.45)' : 'rgba(150,224,110,0.35)';
        g.beginPath();
        g.arc((i * 73) % 256, (i * 137) % 256, 7 + (i % 5), 0, Math.PI * 2);
        g.fill();
    }
    const t = setSRGB(new THREE.CanvasTexture(c));
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.repeat.set(rep, rep);
    return t;
}

let _seed = 11;
const rnd = () => (_seed = (_seed * 16807) % 2147483647) / 2147483647;

const matCache = new Map();
const m = (color, o = {}) => {
    const k = `${color}|${o.emissive || 0}|${o.ei || 0}|${o.r ?? 0.6}|${o.metal || 0}`;
    if (!matCache.has(k)) {
        matCache.set(k, new THREE.MeshStandardMaterial({
            color, roughness: o.r ?? 0.6, metalness: o.metal || 0,
            emissive: o.emissive || 0x000000, emissiveIntensity: o.ei || 0
        }));
    }
    return matCache.get(k);
};

const G = {
    box: new THREE.BoxGeometry(1, 1, 1),
    cyl: new THREE.CylinderGeometry(1, 1, 1, 14),
    ball: new THREE.SphereGeometry(1, 14, 10),
    cone4: new THREE.ConeGeometry(0.7071, 1, 4)
};

function mk(parent, geo, mat, x, y, z, sx, sy, sz, rot = {}) {
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(x, y, z);
    mesh.scale.set(sx, sy, sz);
    if (rot.x) mesh.rotation.x = rot.x;
    if (rot.y) mesh.rotation.y = rot.y;
    if (rot.z) mesh.rotation.z = rot.z;
    mesh.castShadow = rot.cast !== false;
    mesh.receiveShadow = true;
    parent.add(mesh);
    return mesh;
}
const box = (p, mat, w, h, d, x, y, z, rot) => mk(p, G.box, mat, x, y, z, w, h, d, rot);
const cyl = (p, mat, r, h, x, y, z, rot) => mk(p, G.cyl, mat, x, y, z, r, h, r, rot);
const ball = (p, mat, r, x, y, z, sy = 1) => mk(p, G.ball, mat, x, y, z, r, r * sy, r);

function addObbWorld(ctx, cx, cz, rot, hw, hd) {
    ctx.obstacles.push({ cx, cz, rot, hw, hd });
}
function addObbLocal(ctx, gx, gz, rot, lx, lz, hw, hd) {
    const v = new THREE.Vector3(lx, 0, lz).applyAxisAngle(new THREE.Vector3(0, 1, 0), rot);
    addObbWorld(ctx, gx + v.x, gz + v.z, rot, hw, hd);
}
function addRoundObstacle(ctx, x, z, r) {
    ctx.obstacles.push({ minX: x - r, maxX: x + r, minZ: z - r, maxZ: z + r });
}

/* ============================================================================
   گلدان، درخت، چراغ، نیمکت
   ============================================================================ */
export function buildDoorstepPlant(scale = 1) {
    const group = new THREE.Group();
    const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.36 * scale, 0.26 * scale, 0.48 * scale, 16), new THREE.MeshStandardMaterial({ color: 0xea580c }));
    pot.position.y = 0.24 * scale;
    const bush = new THREE.Mesh(new THREE.SphereGeometry(0.45 * scale, 14, 12), new THREE.MeshStandardMaterial({ color: 0x22c55e }));
    bush.position.y = 0.66 * scale;
    const flowerColors = [0xf43f5e, 0xfacc15, 0xf472b6, 0x38bdf8];
    for (let i = 0; i < 5; i++) {
        const fl = new THREE.Mesh(new THREE.SphereGeometry(0.1 * scale), new THREE.MeshStandardMaterial({ color: flowerColors[i % 4] }));
        const angle = (i / 5) * Math.PI * 2;
        fl.position.set(Math.cos(angle) * 0.35 * scale, 0.74 * scale, Math.sin(angle) * 0.35 * scale);
        group.add(fl);
    }
    group.add(pot, bush);
    return group;
}

function addTree(ctx, x, z, s = 1) {
    const t = new THREE.Group();
    t.position.set(x, 0, z);
    cyl(t, m(0x7a4a2a, { r: 0.9 }), 0.32 * s, 2.4 * s, 0, 1.2 * s, 0);
    const l1 = m(0x3fae4f, { r: 0.75 }), l2 = m(0x5cc45a, { r: 0.75 }), l3 = m(0x2f9444, { r: 0.75 });
    ball(t, l1, 1.7 * s, 0, 3.3 * s, 0);
    ball(t, l2, 1.2 * s, 0.9 * s, 2.9 * s, 0.4 * s);
    ball(t, l3, 1.2 * s, -0.85 * s, 3.0 * s, -0.4 * s);
    ball(t, l2, 1.0 * s, 0.1 * s, 4.2 * s, 0.2 * s);
    ctx.worldGroup.add(t);
    addRoundObstacle(ctx, x, z, 0.7 * s);
}

function addBush(ctx, x, z, s = 1) {
    const b = new THREE.Group();
    b.position.set(x, 0, z);
    ball(b, m(0x2f9e44, { r: 0.8 }), 0.7 * s, 0, 0.5 * s, 0, 0.8);
    ball(b, m(0x4cb85a, { r: 0.8 }), 0.5 * s, 0.5 * s, 0.4 * s, 0.2 * s, 0.8);
    ctx.worldGroup.add(b);
}

function getLightPoolTexture() {
    if (!getLightPoolTexture.tex) {
        const c = document.createElement('canvas');
        c.width = c.height = 128;
        const g = c.getContext('2d');
        const grad = g.createRadialGradient(64, 64, 4, 64, 64, 62);
        grad.addColorStop(0, 'rgba(255, 224, 130, 0.78)');
        grad.addColorStop(0.45, 'rgba(255, 196, 92, 0.32)');
        grad.addColorStop(1, 'rgba(255, 180, 70, 0)');
        g.fillStyle = grad;
        g.fillRect(0, 0, 128, 128);
        getLightPoolTexture.tex = setSRGB(new THREE.CanvasTexture(c));
    }
    return getLightPoolTexture.tex;
}

function addLamp(ctx, x, z, withPointLight = true) {
    const lamp = new THREE.Group();
    lamp.position.set(x, 0, z);
    const iron = m(0x273244, { metal: 0.55, r: 0.45 });
    cyl(lamp, iron, 0.24, 0.34, 0, 0.17, 0);
    cyl(lamp, iron, 0.08, 4.4, 0, 2.25, 0);
    box(lamp, iron, 1.15, 0.09, 0.09, 0, 4.45, 0);

    const bulbMat = new THREE.MeshStandardMaterial({
        color: 0xfff4c2,
        emissive: 0xffc857,
        emissiveIntensity: 0.75,
        roughness: 0.2
    });
    [-0.54, 0.54].forEach(ox => {
        // کلاهک فانوس + حباب نورانی گرم
        cone(lamp, iron, 0.28, 0.18, 4.42).position.x = ox;
        const b = new THREE.Mesh(new THREE.SphereGeometry(0.24, 14, 12), bulbMat);
        b.position.set(ox, 4.22, 0);
        lamp.add(b);
    });
    ctx.streetLampBulbs.push(bulbMat);

    // هاله نور گرم روی زمین زیر چراغ (برای نورپردازی طبیعی خیابان و میدان)
    const poolMat = new THREE.MeshBasicMaterial({
        map: getLightPoolTexture(),
        transparent: true,
        opacity: 0.22,
        depthWrite: false,
        blending: THREE.AdditiveBlending
    });
    const pool = new THREE.Mesh(new THREE.PlaneGeometry(8.5, 8.5), poolMat);
    pool.rotation.x = -Math.PI / 2;
    pool.position.y = 0.095;
    lamp.add(pool);
    if (ctx.streetLampPools) ctx.streetLampPools.push(poolMat);

    if (withPointLight) {
        const light = new THREE.PointLight(0xffcf75, 0.85, 24, 1.5);
        light.position.set(0, 4.1, 0);
        ctx.streetLampLights.push(light);
        lamp.add(light);
    }

    ctx.worldGroup.add(lamp);
    addRoundObstacle(ctx, x, z, 0.38);
}

function addBench(ctx, x, z, faceX, faceZ) {
    const b = new THREE.Group();
    b.position.set(x, 0, z);
    const rotY = Math.atan2(faceX - x, faceZ - z);
    b.rotation.y = rotY;
    const wood = m(0xa8693a, { r: 0.75 }), iron = m(0x374151, { metal: 0.45 });
    box(b, wood, 2.3, 0.12, 0.7, 0, 0.55, 0);
    box(b, wood, 2.3, 0.6, 0.1, 0, 0.95, -0.32, { x: -0.12 });
    [-1, 1].forEach(s => { box(b, iron, 0.1, 0.55, 0.6, s * 1.05, 0.28, 0); });

    // امکان نشستن کاراکترها و بازیکن روی نیمکت (کلیک مستقیم روی نیمکت)
    const seatInfo = { x, z, rotY, label: '🪑 نشستن روی نیمکت' };
    b.userData = { action: 'sit_seat', seat: seatInfo };
    ctx.worldGroup.add(b);
    ctx.interactables.push(b);
    if (ctx.seats) ctx.seats.push(seatInfo);
}

function addPath(ctx, x1, z1, x2, z2, width, yy = 0.03) {
    const dx = x2 - x1, dz = z2 - z1, len = Math.hypot(dx, dz);
    if (len < 0.5) return;
    const g = new THREE.Group();
    g.position.set((x1 + x2) / 2, yy, (z1 + z2) / 2);
    g.rotation.y = Math.atan2(-dz, dx);
    const plane = new THREE.Mesh(
        new THREE.PlaneGeometry(len, width),
        new THREE.MeshStandardMaterial({ map: cobbleTex(len / 3, width / 3), roughness: 0.85 })
    );
    plane.rotation.x = -Math.PI / 2;
    plane.receiveShadow = true;
    g.add(plane);
    // حاشیه دو طرف مسیر
    [-1, 1].forEach(s => {
        const edge = new THREE.Mesh(new THREE.BoxGeometry(len, 0.08, 0.18), m(0xf1e6d2));
        edge.position.set(0, 0.03, s * (width / 2 + 0.06));
        g.add(edge);
    });
    ctx.worldGroup.add(g);
}

/* ============================================================================
   ساخت فروشگاه / ساختمان با بالکن، باغچه و جزئیات
   ============================================================================ */
function buildShop(ctx, o) {
    const {
        x, z, w = 10, d = 6.6, h = 7.6, kind, label, zone, prompt, padColor, mapColor,
        wall, trim = 0xf5ead7, dark = 0x2b3452, roof, accent,
        roofStyle = 'flat', balcony = true, signBg = '#1e293b', signBorder = '#facc15'
    } = o;
    const rot = o.rotY ?? Math.atan2(-x, -z);
    const g = new THREE.Group();
    g.position.set(x, 0, z);
    g.rotation.y = rot;
    const gf = 3.3;
    const wallM = m(wall), trimM = m(trim), darkM = m(dark), roofM = m(roof), whiteM = m(0xffffff);
    const glassM = m(0x9fd8ff, { emissive: 0xffe9a8, ei: 0.3, r: 0.15 });
    const doorGlass = m(0x6bb7e8, { emissive: 0x3b82f6, ei: 0.22, r: 0.15 });

    // بدنه، پایه و قرنیز
    box(g, trimM, w + 0.4, 0.4, d + 0.4, 0, 0.2, 0);
    box(g, wallM, w, h, d, 0, h / 2, 0);
    box(g, trimM, w + 0.25, 0.24, d + 0.25, 0, gf + 0.1, 0);
    [-1, 1].forEach(s => box(g, trimM, 0.35, h, 0.35, s * (w / 2 + 0.02), h / 2, d / 2 + 0.02));

    // در ورودی
    box(g, darkM, 2.3, 3.2, 0.3, 0, 1.6, d / 2);
    box(g, doorGlass, 1.85, 2.8, 0.34, 0, 1.45, d / 2 + 0.02);
    box(g, trimM, 0.07, 2.8, 0.36, 0, 1.45, d / 2 + 0.04);
    ball(g, m(0xfbbf24, { metal: 0.6 }), 0.07, 0.3, 1.4, d / 2 + 0.25);

    // ویترین‌های طبقه همکف
    const sx = w / 2 - 2.25;
    [-1, 1].forEach(s => {
        const wx = s * sx;
        box(g, trimM, 3.0, 2.3, 0.28, wx, 1.95, d / 2 + 0.02);
        box(g, glassM, 2.6, 1.9, 0.3, wx, 1.95, d / 2 + 0.04);
        box(g, trimM, 0.08, 1.9, 0.32, wx, 1.95, d / 2 + 0.06);
        box(g, trimM, 3.2, 0.16, 0.55, wx, 0.82, d / 2 + 0.22);
    });

    // سایبان راه‌راه
    const n = Math.max(6, Math.round(w / 0.85)), sw = w / n;
    for (let i = 0; i < n; i++) {
        mk(g, G.box, m(i % 2 ? 0xffffff : accent), -w / 2 + sw * (i + 0.5), 3.42, d / 2 + 0.72, sw * 0.99, 0.12, 1.55, { x: 0.36 });
    }

    // تابلو
    if (kind !== 'cinema') {
        box(g, darkM, w * 0.78, 1.0, 0.28, 0, 4.15, d / 2 + 0.12);
        const sg = new THREE.Mesh(
            new THREE.PlaneGeometry(w * 0.74, w * 0.74 / 8),
            new THREE.MeshBasicMaterial({ map: createSignTexture(label, signBg, signBorder, '', true) })
        );
        sg.position.set(0, 4.15, d / 2 + 0.27);
        g.add(sg);
    } else {
        // مارکیز سینما با لامپ‌های چشمک‌زن
        box(g, m(0xb91c1c), 6.6, 1.35, 0.9, 0, 4.2, d / 2 + 0.55);
        const sg = new THREE.Mesh(
            new THREE.PlaneGeometry(6.2, 0.95),
            new THREE.MeshBasicMaterial({ map: createSignTexture(label, '#7f1d1d', '#fde047', '', true) })
        );
        sg.position.set(0, 4.2, d / 2 + 1.02);
        g.add(sg);
        const bulb = m(0xfff3b0, { emissive: 0xffe066, ei: 1.0 });
        for (let i = 0; i < 17; i++) {
            ball(g, bulb, 0.075, -3.2 + i * 0.4, 4.92, d / 2 + 1.0);
            ball(g, bulb, 0.075, -3.2 + i * 0.4, 3.48, d / 2 + 1.0);
        }
    }

    // طبقه بالا: پنجره‌ها، کرکره‌ها و جعبه گل
    const wy = 6.15;
    const winXs = balcony ? [-w / 2 + 1.9, w / 2 - 1.9] : [-w / 2 + 1.9, 0, w / 2 - 1.9];
    winXs.forEach(wx => {
        box(g, trimM, 2.1, 2.15, 0.26, wx, wy, d / 2 + 0.02);
        box(g, glassM, 1.75, 1.8, 0.28, wx, wy, d / 2 + 0.04);
        box(g, trimM, 0.08, 1.8, 0.3, wx, wy, d / 2 + 0.06);
        box(g, trimM, 1.75, 0.08, 0.3, wx, wy, d / 2 + 0.06);
        [-1, 1].forEach(s => box(g, m(accent, { r: 0.7 }), 0.5, 1.95, 0.12, wx + s * 1.3, wy, d / 2 + 0.08));
        box(g, m(0x7a4a2a), 2.0, 0.34, 0.5, wx, wy - 1.35, d / 2 + 0.3);
        for (let i = 0; i < 7; i++) {
            const col = [0xf43f5e, 0xfacc15, 0xf472b6, 0xffffff][i % 4];
            ball(g, m(col), 0.14, wx - 0.85 + i * 0.28, wy - 1.1, d / 2 + 0.3);
        }
    });

    // بالکن
    if (balcony) {
        box(g, trimM, 1.8, 2.7, 0.26, 0, 6.1, d / 2 + 0.02);
        box(g, doorGlass, 1.45, 2.4, 0.28, 0, 6.05, d / 2 + 0.04);
        box(g, trimM, 0.07, 2.4, 0.3, 0, 6.05, d / 2 + 0.06);
        const by = 4.85, bz = d / 2 + 0.7;
        box(g, trimM, 4.0, 0.24, 1.4, 0, by, bz);
        box(g, darkM, 3.6, 0.16, 1.2, 0, by - 0.2, bz);
        [-1.4, 1.4].forEach(bxp => box(g, darkM, 0.16, 0.6, 0.9, bxp, by - 0.45, d / 2 + 0.45, { z: 0 }));
        const railY = 5.85;
        box(g, trimM, 4.0, 0.1, 0.1, 0, railY, d / 2 + 1.36);
        for (let i = 0; i < 9; i++) cyl(g, trimM, 0.04, 0.9, -1.8 + i * 0.45, 5.35, d / 2 + 1.36);
        [-1, 1].forEach(s => {
            box(g, trimM, 0.1, 0.1, 1.4, s * 1.95, railY, bz);
            for (let i = 0; i < 3; i++) cyl(g, trimM, 0.04, 0.9, s * 1.95, 5.35, d / 2 + 0.2 + i * 0.5);
        });
        [-1, 1].forEach(s => {
            const pl = buildDoorstepPlant(0.55);
            pl.position.set(s * 1.45, by + 0.12, d / 2 + 1.0);
            g.add(pl);
        });
        // چراغ ریسه‌ای بالکن
        const fairy = m(0xfff3b0, { emissive: 0xffe066, ei: 0.9 });
        for (let i = 0; i < 9; i++) ball(g, fairy, 0.06, -1.8 + i * 0.45, 5.75 - Math.abs(Math.sin(i * 0.7)) * 0.1, d / 2 + 1.42);
    }

    // سقف
    if (roofStyle === 'hip') {
        const rg = new THREE.Group();
        rg.position.set(0, h, 0);
        rg.scale.set(w + 1.2, 2.5, d + 1.2);
        const pyr = new THREE.Mesh(G.cone4, roofM);
        pyr.rotation.y = Math.PI / 4;
        pyr.position.y = 0.5;
        pyr.castShadow = true;
        rg.add(pyr);
        g.add(rg);
        box(g, trimM, w + 1.0, 0.25, d + 1.0, 0, h + 0.1, 0);
        box(g, m(0x9a4a35), 0.9, 1.7, 0.9, w * 0.28, h + 1.5, -d * 0.15);
    } else {
        box(g, roofM, w + 0.6, 0.55, d + 0.6, 0, h + 0.27, 0);
        box(g, trimM, w + 0.75, 0.16, d + 0.75, 0, h + 0.62, 0);
        box(g, m(0xd7dde6), 1.4, 0.8, 1.2, -w * 0.3, h + 1.0, -d * 0.2);
    }

    // جزئیات اختصاصی هر ساختمان
    if (kind === 'cinema') {
        const bucket = m(0xdc2626), corn = m(0xfef08a);
        cyl(g, bucket, 0.8, 1.5, -w * 0.32, h + 1.5, 0.2);
        for (let i = 0; i < 9; i++) ball(g, corn, 0.42, -w * 0.32 + Math.cos(i) * 0.5, h + 2.5 + (i % 3) * 0.25, 0.2 + Math.sin(i) * 0.45);
        const reel = m(0x94a3b8, { metal: 0.6 });
        [0, 1].forEach(i => cyl(g, reel, 0.8, 0.28, w * 0.3 + i * 0.4, h + 1.4 + i * 1.3, 0.2, { x: Math.PI / 2 }));
        box(g, m(0xdc2626), 2.2, 0.05, 3.6, 0, 0.07, d / 2 + 1.9); // فرش قرمز
        [-1, 1].forEach(s => {
            box(g, darkM, 1.3, 1.9, 0.12, s * 2.4, 2.2, d / 2 + 0.2);
            box(g, m(s < 0 ? 0xf97316 : 0x38bdf8, { emissive: 0xffffff, ei: 0.1 }), 1.1, 1.7, 0.14, s * 2.4, 2.2, d / 2 + 0.23);
        });
    } else if (kind === 'gamenet') {
        const neonC = m(0x22d3ee, { emissive: 0x22d3ee, ei: 1.0 }), neonP = m(0xf472b6, { emissive: 0xf472b6, ei: 1.0 });
        box(g, m(0x1a1a35), 3.6, 1.7, 0.5, 0, h + 1.5, 0);
        box(g, neonC, 3.2, 0.12, 0.54, 0, h + 0.8, 0);
        box(g, neonP, 3.2, 0.12, 0.54, 0, h + 2.2, 0);
        box(g, neonC, 1.6, 0.5, 0.56, 0, h + 1.5, 0);
        cyl(g, neonP, 0.28, 0.58, -1.2, h + 1.5, 0, { x: Math.PI / 2 });
        cyl(g, neonP, 0.28, 0.58, 1.2, h + 1.5, 0, { x: Math.PI / 2 });
        [-1, 1].forEach(s => {
            box(g, m(0x312e81), 1.0, 2.2, 0.9, s * 3.4, 1.1, d / 2 + 0.9);
            box(g, m(0xf472b6, { emissive: 0xf472b6, ei: 0.8 }), 0.8, 0.8, 0.05, s * 3.4, 1.6, d / 2 + 1.37);
        });
    } else if (kind === 'school') {
        // برج ساعت
        const tx = w / 2 + 1.9, tz = -0.4;
        const brick = m(0xb5533c), band = m(0xf3e2c0);
        box(g, brick, 3.6, 13.0, 3.6, tx, 6.5, tz);
        [4.0, 8.2].forEach(yy => box(g, band, 3.9, 0.35, 3.9, tx, yy, tz));
        box(g, band, 4.0, 0.4, 4.0, tx, 12.8, tz);
        const clockTex = createClockTexture();
        [[0, 1.82, 0], [1.82, 0, Math.PI / 2]].forEach(([ox, oz, ry]) => {
            const face = new THREE.Mesh(new THREE.CircleGeometry(1.15, 28), new THREE.MeshBasicMaterial({ map: clockTex }));
            face.position.set(tx + ox, 10.4, tz + (ry === 0 ? oz : 0));
            face.rotation.y = ry;
            if (ry !== 0) face.position.set(tx + 1.82, 10.4, tz);
            g.add(face);
        });
        const rg = new THREE.Group();
        rg.position.set(tx, 13.0, tz);
        rg.scale.set(4.4, 4.0, 4.4);
        const spire = new THREE.Mesh(G.cone4, m(0x3a4a6b));
        spire.rotation.y = Math.PI / 4; spire.position.y = 0.5; spire.castShadow = true;
        rg.add(spire); g.add(rg);
        [2.2, 6.0].forEach(yy => box(g, m(0xffe9a8, { emissive: 0xffe9a8, ei: 0.4 }), 0.9, 1.2, 0.1, tx, yy + 0.5, tz + 1.82));
        addObbLocal(ctx, x, z, rot, tx, tz, 2.4, 2.4);
        // ستون‌ها و پرچم
        [-1, 1].forEach(s => cyl(g, band, 0.25, 3.3, s * 1.9, 1.65, d / 2 + 1.2));
        cyl(g, m(0xe5e7eb), 0.06, 5.2, -w / 2 - 1.2, 2.6, d / 2 + 2.2);
        box(g, m(0xef4444), 1.2, 0.7, 0.05, -w / 2 - 0.6, 4.7, d / 2 + 2.2);
    } else if (kind === 'cafe') {
        const cup = m(0xf8fafc), coffee = m(0x5b3a29);
        cyl(g, cup, 0.9, 1.3, -w * 0.28, h + 1.6, 0.2);
        cyl(g, coffee, 0.78, 0.05, -w * 0.28, h + 2.27, 0.2);
        cyl(g, cup, 0.1, 0.6, -w * 0.28 + 1.0, h + 1.6, 0.2, { x: Math.PI / 2 });
        [-1, 1].forEach(s => {
            const tb = new THREE.Group();
            tb.position.set(s * (w / 2 + 2.0), 0, d / 2 + 1.6);
            cyl(tb, m(0x7a4a2a), 0.7, 0.1, 0, 0.95, 0);
            cyl(tb, m(0x374151), 0.07, 0.95, 0, 0.48, 0);
            cyl(tb, m(0xe5e7eb), 0.05, 2.0, 0, 1.8, 0);
            const um = new THREE.Group(); um.position.y = 2.7; um.scale.set(2.6, 0.9, 2.6);
            const cone = new THREE.Mesh(G.cone4, m(s < 0 ? 0xef4444 : 0xf8fafc)); cone.rotation.y = Math.PI / 4; um.add(cone);
            tb.add(um);
            [-0.9, 0.9].forEach(cx => box(tb, m(0xa8693a), 0.45, 0.45, 0.45, cx, 0.4, 0));
            g.add(tb);
        });
    } else if (kind === 'hair_salon') {
        const pole = new THREE.Group();
        pole.position.set(-3.0, 0, d / 2 + 0.7);
        cyl(pole, m(0xffffff), 0.26, 2.6, 0, 1.4, 0);
        for (let i = 0; i < 5; i++) cyl(pole, m(i % 2 ? 0x3b82f6 : 0xef4444), 0.275, 0.26, 0, 0.5 + i * 0.5, 0);
        ball(pole, m(0xfbbf24, { metal: 0.6 }), 0.34, 0, 2.85, 0);
        g.add(pole);
        [-1, 1].forEach(s => box(g, m(0xe5e7eb, { metal: 0.8 }), 0.18, 1.6, 0.12, s * 0.5, h + 1.4, 0, { z: s * 0.5 }));
    } else if (kind === 'accessories') {
        box(g, m(0x38bdf8, { emissive: 0x0ea5e9, ei: 0.7 }), 0.32, 2.6, 0.2, 0, h + 1.8, 0, { z: -0.4 });
        box(g, m(0xfbbf24, { metal: 0.7 }), 1.2, 0.2, 0.2, 0.55, h + 0.95, 0, { z: -0.4 });
    } else if (kind === 'clothes') {
        [-1, 1].forEach(s => {
            const mn = new THREE.Group();
            mn.position.set(s * 2.9, 0, d / 2 + 1.7);
            cyl(mn, m(0x4b5563), 0.07, 1.6, 0, 0.8, 0);
            cone(mn, m(s < 0 ? 0xf472b6 : 0x8b5cf6), 0.55, 1.1, 1.65);
            ball(mn, m(0xf1c9a5), 0.22, 0, 2.5, 0);
            g.add(mn);
        });
    } else if (kind === 'furniture') {
        [-1, 1].forEach(s => {
            const f = new THREE.Group();
            f.position.set(s * 2.9, 0, d / 2 + 1.8);
            f.rotation.y = s * -0.35;
            if (s < 0) {
                box(f, m(0xf59e0b), 1.3, 0.5, 1.0, 0, 0.45, 0);
                box(f, m(0xf59e0b), 1.3, 0.9, 0.25, 0, 0.9, -0.42);
            } else {
                cyl(f, m(0x374151), 0.05, 2.0, 0, 1.0, 0);
                cyl(f, m(0xfef08a, { emissive: 0xf59e0b, ei: 0.6 }), 0.4, 0.5, 0, 2.1, 0);
            }
            g.add(f);
        });
    }

    // مسیر ورودی + باغچه‌های دو طرف با حصار، گل و بوته
    const z0 = d / 2 + 0.5, zEnd = d / 2 + 3.4, dz = zEnd - z0;
    const bedIn = 1.55, bedOut = w / 2 + 0.7, wb = bedOut - bedIn;
    const grassM = m(0x58b848, { r: 0.9 }), soilM = m(0x6b4a2e), fenceM = m(0xffffff, { r: 0.5 });
    [-1, 1].forEach((s, bi) => {
        const xc = s * (bedIn + wb / 2), zc = (z0 + zEnd) / 2;
        box(g, soilM, wb + 0.2, 0.08, dz + 0.2, xc, 0.06, zc);
        box(g, grassM, wb, 0.14, dz, xc, 0.1, zc);
        // حصار چوبی سفید
        const fz = zEnd, ox = s * bedOut;
        box(g, fenceM, wb, 0.07, 0.07, xc, 0.55, fz);
        box(g, fenceM, wb, 0.07, 0.07, xc, 0.32, fz);
        box(g, fenceM, 0.07, 0.07, dz, ox, 0.55, zc);
        box(g, fenceM, 0.07, 0.07, dz, ox, 0.32, zc);
        const np = Math.floor(wb / 0.45);
        for (let i = 0; i <= np; i++) box(g, fenceM, 0.09, 0.7, 0.09, xc - wb / 2 + (wb / np) * i, 0.45, fz);
        const ns = Math.floor(dz / 0.45);
        for (let i = 0; i <= ns; i++) box(g, fenceM, 0.09, 0.7, 0.09, ox, 0.45, z0 + (dz / ns) * i);
        // گل‌ها
        for (let i = 0; i < 12; i++) {
            const col = [0xf43f5e, 0xfacc15, 0xf472b6, 0xffffff, 0xfb923c, 0xa78bfa][Math.floor(rnd() * 6)];
            ball(g, m(col, { r: 0.5 }), 0.13, xc + (rnd() - 0.5) * (wb - 0.5), 0.3, zc + (rnd() - 0.5) * (dz - 0.5));
        }
        // بوته و درختچه
        ball(g, m(0x2f9e44, { r: 0.8 }), 0.5, xc + s * (wb / 2 - 0.55), 0.55, z0 + 0.7, 0.85);
        cyl(g, m(0x7a4a2a), 0.1, 1.1, xc - s * (wb / 2 - 0.6), 0.6, zEnd - 0.7);
        ball(g, m(0x3fae4f, { r: 0.75 }), 0.55, xc - s * (wb / 2 - 0.6), 1.45, zEnd - 0.7);
    });
    // مسیر داخل باغچه (سنگفرش) تا پیاده‌رو
    const cobbleM = new THREE.MeshStandardMaterial({ map: cobbleTex(1, 1), roughness: 0.85 });
    const cp = new THREE.Mesh(new THREE.PlaneGeometry(2.8, dz + 0.4), cobbleM);
    cp.rotation.x = -Math.PI / 2;
    cp.position.set(0, 0.07, (z0 + zEnd) / 2);
    g.add(cp);

    // نماد بزرگ و چرخان روی سقف هر ساختمان تا از بالا کاملاً مشخص باشد
    const roofIcon = buildRooftopLandmark(kind, accent);
    if (roofIcon) {
        const baseY = roofStyle === 'hip' ? h + 3.4 : h + 2.4;
        roofIcon.position.set(0, baseY, 0);
        g.add(roofIcon);
        ctx.animatedLandmarks.push({ mesh: roofIcon, type: 'spinAndBob', speed: 1.3, baseY });
    }

    ctx.worldGroup.add(g);

    // برخورد چرخیده (OBB) فقط برای بدنه ساختمان؛ مسیر و باغچه آزاد است
    addObbWorld(ctx, x, z, rot, w / 2 + 0.55, d / 2 + 0.5);

    // خروجی/ورودی و آیکن رادار
    const iconMap = {
        cinema: '🎬', gamenet: '🕹️', clothes: '👗', furniture: '🛋️',
        school: '🎓', cafe: '☕', hair_salon: '💇', accessories: '⚔️', house: '🏠'
    };
    const f = new THREE.Vector3(Math.sin(rot), 0, Math.cos(rot));
    const px = x + f.x * (d / 2 + 2.3), pz = z + f.z * (d / 2 + 2.3);
    ctx.addPortal(px, pz, zone, prompt, padColor);
    ctx.minimapBuildings.push({ x, z, w: 3, d: 3, label: label || '', icon: o.mapIcon || iconMap[kind] || '🏢', color: mapColor });

    // مسیر سنگفرش تا پیاده‌رو یا میدان
    const sx0 = x + f.x * (d / 2 + 3.2), sz0 = z + f.z * (d / 2 + 3.2);
    if (o.streetConnect) {
        addPath(ctx, sx0, sz0, sx0 + f.x * o.streetConnect, sz0 + f.z * o.streetConnect, 3.0);
    } else {
        const dist = Math.hypot(sx0, sz0);
        if (dist > 25) {
            const k = 24.8 / dist;
            addPath(ctx, sx0, sz0, sx0 * k, sz0 * k, 3.2);
        }
    }
}

function buildRooftopLandmark(kind, accent) {
    const g = new THREE.Group();
    const ringMat = new THREE.MeshStandardMaterial({ color: accent || 0x38bdf8, emissive: accent || 0x38bdf8, emissiveIntensity: 0.75 });
    const ring = new THREE.Mesh(new THREE.TorusGeometry(1.15, 0.08, 10, 28), ringMat);
    ring.rotation.x = Math.PI / 2;
    ring.position.y = -0.55;
    g.add(ring);

    if (kind === 'cinema') {
        // کلاکت بزرگ سینما
        box(g, m(0x0f172a), 2.1, 1.35, 0.22, 0, 0.1, 0);
        box(g, m(0xfef08a, { emissive: 0xfacc15, ei: 0.5 }), 2.1, 0.34, 0.24, 0, 0.95, 0, { z: 0.22 });
    } else if (kind === 'gamenet') {
        // دسته بازی نئونی بزرگ
        box(g, m(0x22d3ee, { emissive: 0x06b6d4, ei: 0.85 }), 2.2, 1.05, 0.35, 0, 0.2, 0);
        [-0.85, 0.85].forEach(gx => cyl(g, m(0xa855f7, { emissive: 0x9333ea, ei: 0.7 }), 0.45, 0.9, gx, -0.2, 0, { z: gx < 0 ? 0.35 : -0.35 }));
    } else if (kind === 'clothes') {
        // پیراهن بزرگ صورتی درخشان
        cone(g, m(0xf472b6, { emissive: 0xec4899, ei: 0.4 }), 1.15, 1.9, 0.2);
        box(g, m(0xf9a8d4), 1.7, 0.5, 0.45, 0, 0.85, 0);
    } else if (kind === 'furniture') {
        // مبل بزرگ طلایی/نارنجی روی سقف
        box(g, m(0xf59e0b, { emissive: 0xd97706, ei: 0.35 }), 2.2, 0.55, 1.0, 0, -0.05, 0);
        box(g, m(0xfbbf24), 2.2, 0.95, 0.3, 0, 0.5, -0.35);
    } else if (kind === 'school') {
        // کلاه فارغ‌التحصیلی بزرگ
        cyl(g, m(0x1e3a8a), 0.75, 0.65, 0, 0.0, 0);
        box(g, m(0x1e293b), 2.3, 0.14, 2.3, 0, 0.42, 0, { y: Math.PI / 4 });
        cyl(g, m(0xfacc15, { emissive: 0xf59e0b, ei: 0.6 }), 0.08, 0.9, 0.95, 0.05, 0.95);
    } else if (kind === 'cafe') {
        // فنجان قهوه بزرگ و بخار
        cyl(g, m(0xffffff), 0.95, 1.35, 0, 0.15, 0);
        cyl(g, m(0x78350f), 0.84, 0.08, 0, 0.84, 0);
        const handle = new THREE.Mesh(new THREE.TorusGeometry(0.42, 0.1, 8, 16), m(0xffffff));
        handle.position.set(0.98, 0.18, 0);
        g.add(handle);
    } else if (kind === 'hair_salon') {
        // قیچی نقره‌ای بزرگ ضربدری
        [-1, 1].forEach(s => {
            box(g, m(0xf8fafc, { metal: 0.85, r: 0.2 }), 0.22, 2.2, 0.12, 0, 0.3, 0, { z: s * 0.52 });
            const loop = new THREE.Mesh(new THREE.TorusGeometry(0.32, 0.08, 8, 16), m(0xf43f5e, { emissive: 0xe11d48, ei: 0.5 }));
            loop.position.set(s * 0.52, -0.65, 0);
            g.add(loop);
        });
    } else if (kind === 'accessories') {
        // دو شمشیر درخشان ضربدری + سپر طلایی
        [-1, 1].forEach(s => box(g, m(0x38bdf8, { emissive: 0x0ea5e9, ei: 0.8 }), 0.22, 2.4, 0.1, 0, 0.3, 0, { z: s * 0.6 }));
        cyl(g, m(0xfbbf24, { metal: 0.75 }), 0.65, 0.2, 0, 0.25, 0.12, { x: Math.PI / 2 });
    } else if (kind === 'house') {
        // نماد خانه/قلب درخشان کوچک‌تر روی سقف خانه‌ها
        ring.scale.setScalar(0.65);
        const gem = new THREE.Mesh(new THREE.OctahedronGeometry(0.55, 0), ringMat);
        gem.position.y = 0.15;
        g.add(gem);
    }
    return g;
}

function cone(parent, mat, r, h, y) {
    const mesh = new THREE.Mesh(new THREE.ConeGeometry(r, h, 14), mat);
    mesh.position.y = y;
    mesh.castShadow = true;
    parent.add(mesh);
    return mesh;
}

/* ============================================================================
   محوطه باز شهربازی (بدون ساختمان بسته — شامل چرخ‌وفلک، کاروسل اسبی و غرفه‌ها)
   ============================================================================ */
function buildOpenAmusementPark(ctx) {
    const cx = 0, cz = -62;

    // کف رنگارنگ محوطه شهربازی
    const floor = new THREE.Mesh(new THREE.CircleGeometry(21, 64), m(0xfef3c7, { r: 0.82 }));
    floor.rotation.x = -Math.PI / 2;
    floor.position.set(cx, 0.04, cz);
    floor.receiveShadow = true;
    const border = new THREE.Mesh(new THREE.RingGeometry(20.6, 21.6, 64), m(0xf97316, { emissive: 0xea580c, ei: 0.35 }));
    border.rotation.x = -Math.PI / 2;
    border.position.set(cx, 0.06, cz);
    ctx.worldGroup.add(floor, border);

    // سردر قوس‌دار ورودی شهربازی
    const arch = new THREE.Group();
    arch.position.set(cx, 0, -43.5);
    [-4.6, 4.6].forEach(px => {
        cyl(arch, m(0xef4444), 0.38, 6.4, px, 3.2, 0);
        ball(arch, m(0xfacc15, { emissive: 0xf59e0b, ei: 0.8 }), 0.55, px, 6.6, 0);
    });
    box(arch, m(0x7c2d12), 10.6, 1.5, 0.45, 0, 5.8, 0);
    const sign = new THREE.Mesh(
        new THREE.PlaneGeometry(9.8, 1.25),
        new THREE.MeshBasicMaterial({ map: createSignTexture('🎡 شهربازی بزرگ بلکسیا', '#9a3412', '#fde047', '', true) })
    );
    sign.position.set(0, 5.8, 0.25);
    const signBack = sign.clone();
    signBack.rotation.y = Math.PI;
    signBack.position.z = -0.25;
    arch.add(sign, signBack);
    ctx.worldGroup.add(arch);
    addRoundObstacle(ctx, cx - 4.6, -43.5, 0.55);
    addRoundObstacle(ctx, cx + 4.6, -43.5, 0.55);

    // ۱. چرخ‌وفلک بزرگ در انتهای محوطه
    buildFerrisWheel(ctx, cx, -73);

    // ۲. چرخ‌وفلک اسبی گردان (Carousel) در سمت چپ محوطه شهربازی
    const carGroup = new THREE.Group();
    carGroup.position.set(cx - 12.5, 0, -59);
    cyl(carGroup, m(0xfda4af), 5.2, 0.45, 0, 0.22, 0);
    cyl(carGroup, m(0xfef08a), 0.45, 5.2, 0, 2.6, 0);
    const roofCone = cone(carGroup, m(0xec4899), 5.6, 2.4, 5.8);
    roofCone.castShadow = true;
    ball(carGroup, m(0xfacc15, { emissive: 0xf59e0b, ei: 0.8 }), 0.55, 0, 7.2, 0);

    const spinDeck = new THREE.Group();
    const horseCols = [0xffffff, 0x38bdf8, 0xfde047, 0xa855f7, 0x4ade80, 0xf97316];
    for (let i = 0; i < 6; i++) {
        const a = (i / 6) * Math.PI * 2;
        const hx = Math.cos(a) * 3.6, hz = Math.sin(a) * 3.6;
        cyl(spinDeck, m(0xfbbf24, { metal: 0.7 }), 0.06, 4.8, hx, 2.6, hz);
        box(spinDeck, m(horseCols[i]), 0.55, 0.55, 1.15, hx, 1.45 + (i % 2) * 0.25, hz, { y: -a });
    }
    carGroup.add(spinDeck);
    ctx.worldGroup.add(carGroup);
    ctx.animatedLandmarks.push({ mesh: spinDeck, type: 'spinAndBob', speed: 1.1, baseY: 0 });
    addRoundObstacle(ctx, cx - 12.5, -59, 5.0);

    // ۳. غرفه جایزه و پشمک در سمت راست شهربازی
    const booth = new THREE.Group();
    booth.position.set(cx + 12.5, 0, -59);
    box(booth, m(0x38bdf8), 4.6, 1.3, 2.6, 0, 0.65, 0);
    [-2.0, 2.0].forEach(px => cyl(booth, m(0xffffff), 0.1, 3.2, px, 1.6, 1.0));
    cone(booth, m(0xf43f5e), 3.4, 1.6, 3.8);
    booth.userData = { action: 'park_game', gameId: 'carnival_wheel' };
    ctx.worldGroup.add(booth);
    ctx.interactables.push(booth);
    addObbWorld(ctx, cx + 12.5, -59, 0, 2.4, 1.4);

    // نیمکت‌های استراحت و پورتال بازی شهربازی
    addBench(ctx, -6.5, -50, 0, -60);
    addBench(ctx, 6.5, -50, 0, -60);
    ctx.addPortal(0, -55, 'amusement_park', '🎡 بازی و دریافت جایزه شهربازی', 0xf97316);
    ctx.minimapBuildings.push({ x: cx, z: cz, w: 6, d: 6, label: 'شهربازی', icon: '🎡', color: '#f97316' });
}

/* ============================================================================
   پارک بزرگ تفریحی و ورزشی شهر (شامل برکه، نیمکت‌ها و ۵ ایستگاه بازی مختلف!)
   ============================================================================ */
function buildCityNaturePark(ctx) {
    const px = 68, pz = -2;

    // چمنزار شاداب و مسیر پیاده‌روی پارک
    const meadow = new THREE.Mesh(new THREE.CircleGeometry(24, 64), m(0x4ade80, { r: 0.9 }));
    meadow.rotation.x = -Math.PI / 2;
    meadow.position.set(px, 0.035, pz);
    meadow.receiveShadow = true;
    const loopWalk = new THREE.Mesh(new THREE.RingGeometry(13.5, 16.5, 64), new THREE.MeshStandardMaterial({ map: cobbleTex(10, 10), roughness: 0.82 }));
    loopWalk.rotation.x = -Math.PI / 2;
    loopWalk.position.set(px, 0.05, pz);
    loopWalk.receiveShadow = true;
    ctx.worldGroup.add(meadow, loopWalk);

    // سردر چوبی ورودی پارک در انتهای بلوار شرقی
    const arch = new THREE.Group();
    arch.position.set(47.5, 0, 0);
    arch.rotation.y = -Math.PI / 2;
    [-3.8, 3.8].forEach(ox => cyl(arch, m(0x78350f), 0.34, 5.6, ox, 2.8, 0));
    box(arch, m(0x14532d), 9.0, 1.35, 0.4, 0, 5.2, 0);
    const pSign = new THREE.Mesh(
        new THREE.PlaneGeometry(8.4, 1.15),
        new THREE.MeshBasicMaterial({ map: createSignTexture('🌳 پارک بزرگ و ۵ بازی تفریحی', '#14532d', '#86efac', '', true) })
    );
    pSign.position.set(0, 5.2, 0.22);
    const pSignB = pSign.clone(); pSignB.rotation.y = Math.PI; pSignB.position.z = -0.22;
    arch.add(pSign, pSignB);
    ctx.worldGroup.add(arch);
    addRoundObstacle(ctx, 47.5, -3.8, 0.5);
    addRoundObstacle(ctx, 47.5, 3.8, 0.5);

    const addStationSign = (grp, text, borderCol, y = 3.2) => {
        const sg = new THREE.Mesh(
            new THREE.BoxGeometry(3.4, 0.85, 0.16),
            new THREE.MeshBasicMaterial({ map: createSignTexture(text, '#0f172a', borderCol) })
        );
        sg.position.y = y;
        grp.add(sg);
    };

    // بازی ۱: برکه زلال + اسکله ماهیگیری (🎣 ماهیگیری)
    const pond = new THREE.Group();
    pond.position.set(px, 0, pz);
    const water = new THREE.Mesh(new THREE.CircleGeometry(6.2, 40), new THREE.MeshStandardMaterial({ color: 0x0ea5e9, emissive: 0x0284c7, emissiveIntensity: 0.45, roughness: 0.15 }));
    water.rotation.x = -Math.PI / 2;
    water.position.y = 0.06;
    const dock = box(pond, m(0x92400e), 2.4, 0.25, 3.6, -5.2, 0.2, 0, { y: Math.PI / 2 });
    addStationSign(pond, '🎣 ۱. ماهیگیری در برکه', '#38bdf8', 2.6);
    pond.add(water);
    pond.userData = { action: 'park_game', gameId: 'fishing' };
    dock.userData = { action: 'park_game', gameId: 'fishing' };
    ctx.worldGroup.add(pond);
    ctx.interactables.push(pond, dock);
    addRoundObstacle(ctx, px, pz, 5.6);

    // بازی ۲: زمین بسکتبال و حلقه (🏀 پرتاب بسکتبال)
    const bball = new THREE.Group();
    bball.position.set(px - 10, 0, pz - 15.5);
    const court = new THREE.Mesh(new THREE.PlaneGeometry(8.5, 6.5), m(0xea580c, { r: 0.75 }));
    court.rotation.x = -Math.PI / 2; court.position.y = 0.06;
    bball.add(court);
    cyl(bball, m(0x334155), 0.14, 4.2, 0, 2.1, -2.8);
    box(bball, m(0xffffff), 2.1, 1.35, 0.12, 0, 3.9, -2.6);
    const rim = new THREE.Mesh(new THREE.TorusGeometry(0.42, 0.05, 8, 20), m(0xef4444));
    rim.rotation.x = Math.PI / 2; rim.position.set(0, 3.45, -2.1);
    bball.add(rim);
    addStationSign(bball, '🏀 ۲. پرتاب بسکتبال', '#fb923c', 5.0);
    bball.userData = { action: 'park_game', gameId: 'basketball' };
    ctx.worldGroup.add(bball);
    ctx.interactables.push(bball);

    // بازی ۳: مینی‌فوتبال و ضربه پنالتی (🥅 پنالتی فوتبال)
    const soccer = new THREE.Group();
    soccer.position.set(px + 10, 0, pz - 15.5);
    const pitch = new THREE.Mesh(new THREE.PlaneGeometry(9.0, 6.5), m(0x16a34a, { r: 0.8 }));
    pitch.rotation.x = -Math.PI / 2; pitch.position.y = 0.06;
    soccer.add(pitch);
    [-1.9, 1.9].forEach(gx => cyl(soccer, m(0xffffff), 0.1, 2.4, gx, 1.2, -2.6));
    box(soccer, m(0xffffff), 3.9, 0.12, 0.12, 0, 2.4, -2.6);
    ball(soccer, m(0xffffff), 0.28, 0, 0.34, 0.8);
    addStationSign(soccer, '🥅 ۳. پنالتی فوتبال', '#4ade80', 3.4);
    soccer.userData = { action: 'park_game', gameId: 'soccer' };
    ctx.worldGroup.add(soccer);
    ctx.interactables.push(soccer);

    // بازی ۴: سکوی سیبل تیراندازی و دارت (🎯 تیراندازی به هدف)
    const archery = new THREE.Group();
    archery.position.set(px + 14.5, 0, pz + 7);
    archery.rotation.y = -Math.PI / 2;
    [-2.0, 2.0].forEach(tx => {
        cyl(archery, m(0x78350f), 0.1, 2.1, tx, 1.05, 0);
        const t1 = cyl(archery, m(0xffffff), 0.95, 0.14, tx, 1.85, 0.1, { x: Math.PI / 2 });
        const t2 = cyl(archery, m(0xef4444), 0.62, 0.16, tx, 1.85, 0.12, { x: Math.PI / 2 });
        const t3 = cyl(archery, m(0xfacc15), 0.28, 0.18, tx, 1.85, 0.14, { x: Math.PI / 2 });
        t1.userData = t2.userData = t3.userData = { action: 'park_game', gameId: 'archery' };
    });
    addStationSign(archery, '🎯 ۴. سیبل تیراندازی', '#facc15', 3.4);
    archery.userData = { action: 'park_game', gameId: 'archery' };
    ctx.worldGroup.add(archery);
    ctx.interactables.push(archery);

    // بازی ۵: آلاچیق و باغ پروانه‌ها (🦋 شکار پروانه و حافظه)
    const gazebo = new THREE.Group();
    gazebo.position.set(px - 6, 0, pz + 16);
    cyl(gazebo, m(0xfef3c7), 3.2, 0.3, 0, 0.15, 0);
    for (let i = 0; i < 6; i++) {
        const a = (i / 6) * Math.PI * 2;
        cyl(gazebo, m(0xffffff), 0.12, 3.0, Math.cos(a) * 2.7, 1.6, Math.sin(a) * 2.7);
    }
    cone(gazebo, m(0xa855f7), 3.6, 1.8, 3.9);
    addStationSign(gazebo, '🦋 ۵. چالش باغ پروانه‌ها', '#c084fc', 5.2);
    gazebo.userData = { action: 'park_game', gameId: 'butterfly' };
    ctx.worldGroup.add(gazebo);
    ctx.interactables.push(gazebo);

    // نیمکت‌های قابل نشستن پارک و درختان اطراف
    addBench(ctx, px - 9, pz + 4, px, pz);
    addBench(ctx, px + 8, pz - 4, px, pz);
    addBench(ctx, px + 4, pz + 14, px, pz);
    [[px - 18, pz - 9], [px + 19, pz - 8], [px + 18, pz + 17], [px - 16, pz + 16]].forEach(([tx, tz]) => addTree(ctx, tx, tz, 1.05));

    ctx.minimapBuildings.push({ x: px, z: pz, w: 6, d: 6, label: 'پارک شهر', icon: '🌳', color: '#22c55e' });
}

/* ============================================================================
   چرخ و فلک شهربازی
   ============================================================================ */
function buildFerrisWheel(ctx, x, z) {
    const g = new THREE.Group();
    g.position.set(x, 0, z);
    const R = 7.5, hubY = 9;
    const frame = m(0xf3f4f6, { metal: 0.3 });
    // پایه‌ها
    [-1, 1].forEach(s => {
        const leg = box(g, m(0x64748b, { metal: 0.4 }), 0.5, 11, 0.5, s * 2.2, 4.4, 0, { z: -s * 0.28 });
        leg.castShadow = true;
    });
    const wheel = new THREE.Group();
    wheel.position.y = hubY;
    const rim = new THREE.Mesh(new THREE.TorusGeometry(R, 0.22, 8, 48), frame);
    rim.castShadow = true;
    wheel.add(rim);
    const rim2 = new THREE.Mesh(new THREE.TorusGeometry(R * 0.55, 0.12, 8, 36), m(0xfbbf24));
    wheel.add(rim2);
    const kids = [];
    const cols = [0xef4444, 0xf59e0b, 0x22c55e, 0x3b82f6, 0xa855f7, 0xec4899];
    for (let i = 0; i < 12; i++) {
        const a = (i / 12) * Math.PI * 2;
        const spoke = box(wheel, frame, 0.12, R * 2, 0.12, 0, 0, 0, { z: a });
        spoke.scale.set(0.12, R * 2, 0.12);
        spoke.rotation.z = a;
        const gon = new THREE.Group();
        gon.position.set(Math.sin(a) * R, -Math.cos(a) * R, 0);
        box(gon, m(cols[i % 6]), 1.1, 0.85, 0.9, 0, -0.7, 0);
        box(gon, m(0xffffff), 1.2, 0.1, 1.0, 0, -0.2, 0);
        wheel.add(gon);
        kids.push(gon);
    }
    ball(wheel, m(0xfbbf24, { emissive: 0xf59e0b, ei: 0.5 }), 0.7, 0, 0, 0);
    g.add(wheel);
    ctx.worldGroup.add(g);
    ctx.animatedLandmarks.push({ type: 'ferris', mesh: wheel, kids, speed: 0.22 });
    addObbWorld(ctx, x, z, 0, 3.4, 1.0);
}

function addAsphaltStreet(ctx, x1, z1, x2, z2, roadW = 6.2) {
    const dx = x2 - x1, dz = z2 - z1, len = Math.hypot(dx, dz);
    if (len < 1) return;
    const g = new THREE.Group();
    g.position.set((x1 + x2) / 2, 0.025, (z1 + z2) / 2);
    g.rotation.y = Math.atan2(-dz, dx);

    // پیاده‌رو سنگفرش دو طرف خیابان
    const sw = new THREE.Mesh(
        new THREE.PlaneGeometry(len, roadW + 4.4),
        new THREE.MeshStandardMaterial({ map: cobbleTex(len / 3.5, 3), roughness: 0.85 })
    );
    sw.rotation.x = -Math.PI / 2;
    sw.receiveShadow = true;
    g.add(sw);

    // آسفالت خیابان
    const road = new THREE.Mesh(
        new THREE.PlaneGeometry(len, roadW),
        new THREE.MeshStandardMaterial({ color: 0x3b4454, roughness: 0.88 })
    );
    road.rotation.x = -Math.PI / 2;
    road.position.y = 0.012;
    road.receiveShadow = true;
    g.add(road);

    // جدول کنار خیابان
    [-1, 1].forEach(s => {
        const curb = new THREE.Mesh(new THREE.BoxGeometry(len, 0.12, 0.24), m(0xe7d8c5));
        curb.position.set(0, 0.06, s * (roadW / 2 + 0.12));
        g.add(curb);
    });

    // خط‌کشی منقطع وسط خیابان
    const dashes = Math.floor(len / 3.4);
    const dashMat = m(0xfef9c3, { r: 0.6 });
    for (let i = 0; i < dashes; i++) {
        const lx = -len / 2 + 1.8 + i * 3.4;
        const dash = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 0.18), dashMat);
        dash.rotation.x = -Math.PI / 2;
        dash.position.set(lx, 0.024, 0);
        g.add(dash);
    }

    ctx.worldGroup.add(g);
}

function addCrosswalk(ctx, x, z, rotY = 0, width = 5.6) {
    const g = new THREE.Group();
    g.position.set(x, 0.052, z);
    g.rotation.y = rotY;
    for (let i = -3; i <= 3; i++) {
        const stripe = new THREE.Mesh(new THREE.PlaneGeometry(2.2, 0.42), m(0xf8fafc));
        stripe.rotation.x = -Math.PI / 2;
        stripe.position.set(0, 0, i * (width / 7.5));
        g.add(stripe);
    }
    ctx.worldGroup.add(g);
}

/* ============================================================================
   میدان بزرگ شهر + شبکه خیابان‌های اطراف و محله مسکونی
   ============================================================================ */
export function buildCityPlaza(ctx, residentialPlots) {
    ctx.setBounds({ minX: -112, maxX: 114, minZ: -92, maxZ: 92 });
    _seed = 11;

    // زمین چمن وسیع شهر گسترش‌یافته با شبکه بزرگ خیابان‌های اطراف
    const ground = new THREE.Mesh(
        new THREE.PlaneGeometry(350, 350),
        new THREE.MeshStandardMaterial({ map: grassTex(54), roughness: 0.92 })
    );
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    ctx.worldGroup.add(ground);
    ctx.setGround(ground);

    // ۱. میدان مرکزی بزرگ و دلباز (شعاع ۱۸.۵ متر برای تردد کاملاً راحت)
    const disc = new THREE.Mesh(new THREE.CircleGeometry(18.5, 80), new THREE.MeshStandardMaterial({ map: cobbleTex(12, 12), roughness: 0.8 }));
    disc.rotation.x = -Math.PI / 2; disc.position.y = 0.06; disc.receiveShadow = true;
    const innerCurb = new THREE.Mesh(new THREE.RingGeometry(18.3, 18.9, 80), m(0xf1e6d2));
    innerCurb.rotation.x = -Math.PI / 2; innerCurb.position.y = 0.09; innerCurb.receiveShadow = true;

    // بلوار حلقه‌ای دور میدان + پیاده‌رو بیرونی
    const ringRoad = new THREE.Mesh(new THREE.RingGeometry(18.9, 24.4, 80), m(0x3b4454, { r: 0.88 }));
    ringRoad.rotation.x = -Math.PI / 2; ringRoad.position.y = 0.045; ringRoad.receiveShadow = true;
    const outerSidewalk = new THREE.Mesh(new THREE.RingGeometry(24.4, 27.6, 80), new THREE.MeshStandardMaterial({ map: cobbleTex(16, 16), roughness: 0.82 }));
    outerSidewalk.rotation.x = -Math.PI / 2; outerSidewalk.position.y = 0.058; outerSidewalk.receiveShadow = true;
    const outerCurb = new THREE.Mesh(new THREE.RingGeometry(24.2, 24.65, 80), m(0xf1e6d2));
    outerCurb.rotation.x = -Math.PI / 2; outerCurb.position.y = 0.088;
    ctx.worldGroup.add(disc, innerCurb, ringRoad, outerSidewalk, outerCurb);

    // خط‌کشی وسط بلوار حلقه‌ای
    for (let i = 0; i < 36; i++) {
        const a = (i / 36) * Math.PI * 2;
        const arcDash = new THREE.Mesh(new THREE.RingGeometry(21.55, 21.75, 6, 1, a, 0.09), m(0xfef9c3));
        arcDash.rotation.x = -Math.PI / 2;
        arcDash.position.y = 0.055;
        ctx.worldGroup.add(arcDash);
    }

    // ۲. شبکه گسترده خیابان‌های اطراف شهر (حلقه‌های شمالی، جنوبی، شرقی، غربی و محله‌های مسکونی)
    addAsphaltStreet(ctx, 0, 24.5, 0, 70, 6.2);       // بلوار محوری جنوبی
    addAsphaltStreet(ctx, 0, -24.5, 0, -42.5, 6.2);   // بلوار محوری شمالی (ورودی شهربازی)
    addAsphaltStreet(ctx, 24.5, 0, 46.5, 0, 6.2);     // بلوار محوری شرقی (ورودی پارک بزرگ)
    addAsphaltStreet(ctx, -24.5, 0, -90, 0, 6.2);     // بلوار محوری غربی تا انتهای غرب شهر

    // بلوارهای سراسری شرق به غرب
    addAsphaltStreet(ctx, -90, -38, 100, -38, 6.0);   // بلوار شمالی شهر (کاج)
    addAsphaltStreet(ctx, -90, 40, 100, 40, 6.0);     // بلوار مسکونی بهار (جنوب میانی)
    addAsphaltStreet(ctx, -90, 68, 100, 68, 6.0);     // بلوار جنوبی گلستان (کمربندی جنوب)

    // بلوارهای سراسری شمال به جنوب در غرب و شرق شهر
    addAsphaltStreet(ctx, -56, -40, -56, 70, 5.8);    // بلوار غربی میانی
    addAsphaltStreet(ctx, -88, -40, -88, 70, 5.8);    // بلوار کمربندی غربی
    addAsphaltStreet(ctx, 56, 38, 56, 70, 5.6);       // خیابان رابط شرقی محله بهار-گلستان
    addAsphaltStreet(ctx, 98, -40, 98, 70, 6.0);      // بلوار کمربندی شرقی (کنار پارک بزرگ)

    // خطوط عابر پیاده در چهارراه‌های میدان و خیابان‌های اطراف
    addCrosswalk(ctx, 0, 21.6, Math.PI / 2);
    addCrosswalk(ctx, 0, -21.6, Math.PI / 2);
    addCrosswalk(ctx, 21.6, 0, 0);
    addCrosswalk(ctx, -21.6, 0, 0);
    addCrosswalk(ctx, 0, -38, 0);
    addCrosswalk(ctx, 0, 40, 0);
    addCrosswalk(ctx, -56, 0, Math.PI / 2);
    addCrosswalk(ctx, -56, 40, 0);
    addCrosswalk(ctx, -88, 0, Math.PI / 2);
    addCrosswalk(ctx, 56, 40, 0);
    addCrosswalk(ctx, 98, 0, Math.PI / 2);

    // ۳. جزیره‌های چمن‌کاری میدان با فاصله باز برای تردد راحت (مسیرهای ۶ متری بین جزیره‌ها!)
    for (let q = 0; q < 4; q++) {
        const ts = q * Math.PI / 2 + 0.22, tl = Math.PI / 2 - 0.44;
        const edge = new THREE.Mesh(new THREE.RingGeometry(7.6, 13.8, 32, 1, ts - 0.04, tl + 0.08), m(0xf1e6d2));
        edge.rotation.x = -Math.PI / 2; edge.position.y = 0.1;
        const isl = new THREE.Mesh(new THREE.RingGeometry(7.9, 13.5, 32, 1, ts, tl), m(0x5cbd4a, { r: 0.9 }));
        isl.rotation.x = -Math.PI / 2; isl.position.y = 0.13; isl.receiveShadow = true;
        ctx.worldGroup.add(edge, isl);
        const mid = q * Math.PI / 2 + Math.PI / 4;
        addTree(ctx, Math.cos(mid) * 10.6, -Math.sin(mid) * 10.6, 0.92);
        addBush(ctx, Math.cos(mid + 0.34) * 12.1, -Math.sin(mid + 0.34) * 12.1, 0.9);
        addBush(ctx, Math.cos(mid - 0.34) * 9.1, -Math.sin(mid - 0.34) * 9.1, 0.85);
        addBench(ctx, Math.cos(mid) * 15.3, -Math.sin(mid) * 15.3, 0, 0);
    }

    // ۴. آبنمای کریستالی مرکز (بدون ذرات ریز شناور که مثل نقطه وسط تصویر دیده می‌شدند)
    const fg = new THREE.Group();
    const stone = m(0xc4b5fd, { r: 0.45 });
    cyl(fg, m(0x94a3b8, { r: 0.5 }), 3.8, 0.45, 0, 0.22, 0);
    cyl(fg, stone, 3.5, 0.75, 0, 0.5, 0);
    const water = cyl(fg, new THREE.MeshStandardMaterial({ color: 0x0284c7, emissive: 0x06b6d4, emissiveIntensity: 0.95, roughness: 0.12 }), 3.05, 0.14, 0, 0.88, 0);
    water.castShadow = false;
    cyl(fg, m(0xa5b4fc, { r: 0.4 }), 1.3, 1.45, 0, 1.45, 0);
    cyl(fg, new THREE.MeshStandardMaterial({ color: 0x38bdf8, emissive: 0x22d3ee, emissiveIntensity: 0.75 }), 1.85, 0.24, 0, 2.2, 0);
    const crystalMat = new THREE.MeshStandardMaterial({ color: 0x06b6d4, emissive: 0x0891b2, emissiveIntensity: 1.1, roughness: 0.12, metalness: 0.3 });
    const main = new THREE.Mesh(new THREE.OctahedronGeometry(1.15, 0), crystalMat);
    main.scale.set(0.85, 1.75, 0.85); main.position.y = 4.25; main.castShadow = true;
    fg.add(main);
    ctx.animatedLandmarks.push({ mesh: main, type: 'spinAndBob', speed: 1.4, baseY: 4.25 });
    const glow = new THREE.PointLight(0x38bdf8, 2.4, 20);
    glow.position.y = 3.6;
    fg.add(glow);
    ctx.worldGroup.add(fg);
    ctx.obstacles.push({ minX: -3.9, maxX: 3.9, minZ: -3.9, maxZ: 3.9 });

    // ۵. چراغ‌های خیابانی در میدان و بلوارهای گسترش‌یافته اطراف شهر
    for (let i = 0; i < 8; i++) {
        const a = (i / 8) * Math.PI * 2 + Math.PI / 8;
        addLamp(ctx, Math.cos(a) * 17.6, Math.sin(a) * 17.6, true);
    }
    [
        [-36, 4.8, true], [36, 4.8, true], [-36, -4.8, false], [36, -4.8, false],
        [-72, 4.8, true], [-72, -4.8, false],
        [-28, 34.4, true], [-8, 34.4, true], [8, 34.4, true], [28, 34.4, true], [74, 34.4, true],
        [-28, 62.4, true], [28, 62.4, true], [-72, 62.4, false], [74, 62.4, false],
        [-50.8, 16, true], [-82.8, 16, true], [-82.8, -16, false],
        [92.8, -16, true], [92.8, 16, true],
        [-32, -32.8, true], [32, -32.8, true], [68, -32.8, false]
    ].forEach(([lx, lz, hasPt]) => addLamp(ctx, lx, lz, hasPt));

    // ۶. ساختمان‌های اصلی شهر (با نمادهای بزرگ روی سقف؛ شهربازی به صورت محوطه باز ساخته می‌شود نه خانه!)
    const S = [
        { kind: 'cinema', x: -29.5, z: -13.5, w: 11, label: 'سینما', zone: 'cinema', prompt: '🎬 ورود به سینما', padColor: 0x7c3aed, mapColor: '#8b5cf6', wall: 0xe9a679, trim: 0xf7e7cf, dark: 0x2b3452, roof: 0x3f4a6b, accent: 0xef4444, balcony: false, signBg: '#7f1d1d', signBorder: '#fde047' },
        { kind: 'gamenet', x: -15.5, z: -28.5, w: 10, label: 'GAME NET', zone: 'gamenet', prompt: '🕹️ ورود به گیم‌نت', padColor: 0x059669, mapColor: '#10b981', wall: 0x2f2d5e, trim: 0x8b8fd6, dark: 0x14142e, roof: 0x1a1a35, accent: 0x22d3ee, balcony: false, signBg: '#312e81', signBorder: '#22d3ee' },
        { kind: 'clothes', x: 15.5, z: -28.5, w: 10, label: 'بوتیک لباس', zone: 'shop_clothes', prompt: '👗 ورود به فروشگاه لباس', padColor: 0xdb2777, mapColor: '#ec4899', wall: 0xcf9fb0, trim: 0xfbeef2, dark: 0x6b3a4b, roof: 0x8d5a6b, accent: 0xf472b6, roofStyle: 'hip', signBg: '#831843', signBorder: '#f9a8d4' },
        { kind: 'furniture', x: 29.5, z: -13.5, w: 10, label: 'مبلمان', zone: 'shop_furniture', prompt: '🛋️ ورود به فروشگاه مبلمان', padColor: 0xd97706, mapColor: '#f59e0b', wall: 0xf1dcae, trim: 0xfff6e0, dark: 0x3a4a6b, roof: 0x3a4a6b, accent: 0xf97316, roofStyle: 'hip', signBg: '#78350f', signBorder: '#fbbf24' },
        { kind: 'school', x: 30.5, z: 13.5, w: 9.8, label: 'مدرسه', zone: 'school_hall', prompt: '🎓 ورود به مدرسه', padColor: 0x2563eb, mapColor: '#3b82f6', wall: 0xb5533c, trim: 0xf3e2c0, dark: 0x5b2a20, roof: 0x7a3b2e, accent: 0x2563eb, signBg: '#1e3a8a', signBorder: '#facc15' },
        { kind: 'cafe', x: -30.5, z: 13.5, w: 9.8, label: 'کافه', zone: 'cafe', prompt: '☕ ورود به کافه', padColor: 0xb45309, mapColor: '#d97706', wall: 0x93625a, trim: 0xf6e6d4, dark: 0x4b2e2a, roof: 0x5b3a3a, accent: 0xdc2626, roofStyle: 'hip', signBg: '#451a03', signBorder: '#fbbf24' },
        { kind: 'hair_salon', x: -42, z: -9.5, w: 9, rotY: 0, streetConnect: 4.0, label: 'آرایشگاه', zone: 'hair_salon', prompt: '💇 ورود به آرایشگاه', padColor: 0xe11d48, mapColor: '#f43f5e', wall: 0xffd1dc, trim: 0xffffff, dark: 0x9d174d, roof: 0xd9467a, accent: 0xe11d48, roofStyle: 'hip', signBg: '#9d174d', signBorder: '#fbcfe8' },
        { kind: 'accessories', x: 42, z: -9.5, w: 9, rotY: 0, streetConnect: 4.0, label: 'لوازم جانبی', zone: 'shop_accessories', prompt: '⚔️ ورود به فروشگاه لوازم', padColor: 0x0284c7, mapColor: '#0ea5e9', wall: 0xcfe8ff, trim: 0xffffff, dark: 0x1e3a8a, roof: 0x3a6ea5, accent: 0x2563eb, signBg: '#1e3a8a', signBorder: '#7dd3fc' }
    ];
    S.forEach(o => buildShop(ctx, o));

    // محوطه باز شهربازی در شمال + پارک بزرگ تفریحی با ۵ بازی در شرق!
    buildOpenAmusementPark(ctx);
    buildCityNaturePark(ctx);

    // ۷. خانه‌ها و ویلاهای کاراکترها در شبکه خیابان‌های اطراف شهر (بهار، گلستان، غربی و شمالی)
    const myId = ctx.playerState?.userId || 1;
    const neighborHouses = [
        { x: -16, z: 50, rotY: Math.PI, label: '🏠 خانه من', zone: `home_${myId}`, prompt: '🏠 ورود به خانه من', padColor: 0x10b981, mapColor: '#22c55e', wall: 0xfde68a, roof: 0xdc2626, accent: 0x10b981, signBg: '#065f46', signBorder: '#6ee7b7' },
        { x: 16, z: 50, rotY: Math.PI, label: '🏡 خانه سارا', zone: 'home_202', prompt: '🏡 بازدید از خانه سارا', padColor: 0xec4899, mapColor: '#f472b6', wall: 0xfbcfe8, roof: 0xdb2777, accent: 0xf472b6, signBg: '#831843', signBorder: '#f9a8d4' },
        { x: -36, z: 50, rotY: Math.PI, label: '🏡 خانه آرش', zone: 'home_203', prompt: '🏡 بازدید از خانه آرش', padColor: 0x3b82f6, mapColor: '#60a5fa', wall: 0xbae6fd, roof: 0x1d4ed8, accent: 0x38bdf8, signBg: '#1e3a8a', signBorder: '#93c5fd' },
        { x: 36, z: 50, rotY: Math.PI, label: '🏡 خانه پریسا', zone: 'home_205', prompt: '🏡 بازدید از خانه پریسا', padColor: 0xa855f7, mapColor: '#c084fc', wall: 0xe9d5ff, roof: 0x7e22ce, accent: 0xa855f7, signBg: '#581c87', signBorder: '#d8b4fe' },
        { x: -66, z: 20, rotY: Math.PI / 2, label: '🏡 خانه نیما', zone: 'home_204', prompt: '🏡 بازدید از خانه نیما', padColor: 0x14b8a6, mapColor: '#2dd4bf', wall: 0xccfbf1, roof: 0x0f766e, accent: 0x14b8a6, signBg: '#134e4a', signBorder: '#5eead4' },
        { x: -66, z: -18, rotY: Math.PI / 2, label: '🏡 ویلای قهرمانان', zone: 'home_206', prompt: '🏡 بازدید از ویلا', padColor: 0xf59e0b, mapColor: '#fbbf24', wall: 0xffedd5, roof: 0xb45309, accent: 0xf59e0b, signBg: '#78350f', signBorder: '#fde047' },
        { x: -24, z: 78, rotY: Math.PI, label: '🏡 ویلای گلستان', zone: 'home_202', prompt: '🏡 بازدید از ویلای گلستان', padColor: 0x06b6d4, mapColor: '#22d3ee', wall: 0xe0f2fe, roof: 0x0284c7, accent: 0x38bdf8, signBg: '#0c4a6e', signBorder: '#7dd3fc' },
        { x: 24, z: 78, rotY: Math.PI, label: '🏡 خانه آفتاب', zone: 'home_203', prompt: '🏡 بازدید از خانه آفتاب', padColor: 0xf97316, mapColor: '#fb923c', wall: 0xfef3c7, roof: 0xea580c, accent: 0xf59e0b, signBg: '#7c2d12', signBorder: '#fdba74' },
        { x: 76, z: 78, rotY: Math.PI, label: '🏡 کلبه باغ شرقی', zone: 'home_205', prompt: '🏡 بازدید از کلبه شرقی', padColor: 0x22c55e, mapColor: '#4ade80', wall: 0xdcfce7, roof: 0x15803d, accent: 0x22c55e, signBg: '#14532d', signBorder: '#86efac' },
        { x: -98, z: 18, rotY: Math.PI / 2, label: '🏡 ویلای غروب', zone: 'home_204', prompt: '🏡 بازدید از ویلای غروب', padColor: 0xe11d48, mapColor: '#fb7185', wall: 0xffe4e6, roof: 0xbe123c, accent: 0xf43f5e, signBg: '#881337', signBorder: '#fda4af' },
        { x: -98, z: -18, rotY: Math.PI / 2, label: '🏡 عمارت ستاره', zone: 'home_206', prompt: '🏡 بازدید از عمارت ستاره', padColor: 0x6366f1, mapColor: '#818cf8', wall: 0xe0e7ff, roof: 0x4338ca, accent: 0x6366f1, signBg: '#312e81', signBorder: '#a5b4fc' },
        { x: 52, z: -48, rotY: 0, label: '🏡 ویلای نسیم', zone: 'home_202', prompt: '🏡 بازدید از ویلای نسیم', padColor: 0x14b8a6, mapColor: '#2dd4bf', wall: 0xf0fdfa, roof: 0x0d9488, accent: 0x14b8a6, signBg: '#134e4a', signBorder: '#5eead4' }
    ];
    neighborHouses.forEach(h => {
        buildShop(ctx, {
            kind: 'house', x: h.x, z: h.z, w: 8.8, d: 6.2, h: 6.8, rotY: h.rotY, streetConnect: 3.8,
            label: h.label, zone: h.zone, prompt: h.prompt,
            padColor: h.padColor, mapColor: h.mapColor,
            wall: h.wall, trim: 0xffffff, dark: 0x334155, roof: h.roof, accent: h.accent,
            roofStyle: 'hip', balcony: true, signBg: h.signBg, signBorder: h.signBorder
        });
    });

    const extraPlots = [{ x: -72, z: 50, rotY: Math.PI }, { x: 76, z: 50, rotY: Math.PI }];
    residentialPlots.forEach((plot, idx) => {
        if (idx >= extraPlots.length) return;
        const pos = extraPlots[idx];
        buildShop(ctx, {
            kind: 'house', x: pos.x, z: pos.z, w: 8.6, d: 6.0, h: 6.6, rotY: pos.rotY, streetConnect: 3.8,
            label: `🏠 خانه ${plot.ownerName}`, zone: `home_${plot.ownerId}`, prompt: `🚪 ورود به خانه ${plot.ownerName}`,
            padColor: 0x10b981, mapColor: '#38bdf8',
            wall: plot.color || 0xbae6fd, trim: 0xffffff, dark: 0x1e3a8a, roof: plot.roofColor || 0x2563eb, accent: 0x38bdf8,
            roofStyle: 'hip', balcony: true
        });
    });

    // ۸. گراف مسیریابی ۱۰۰٪ بدون مانع روی پیاده‌روهای میدان و خیابان‌های اطراف
    ctx.navNodes = [
        // حلقه داخلی هشت‌ضلعی دور آبنما (شعاع ۶ متر — کاملاً آزاد بین آبنما ۳.۹ و چمن ۷.۹)
        { id: 'c_n',  x: 0,    z: -6.0, links: ['c_ne', 'c_nw', 'ax_n'], tag: 'fountain' },
        { id: 'c_ne', x: 4.3,  z: -4.3, links: ['c_n', 'c_e'],           tag: 'fountain' },
        { id: 'c_e',  x: 6.0,  z: 0,    links: ['c_ne', 'c_se', 'ax_e'], tag: 'fountain' },
        { id: 'c_se', x: 4.3,  z: 4.3,  links: ['c_e', 'c_s'],           tag: 'fountain' },
        { id: 'c_s',  x: 0,    z: 6.0,  links: ['c_se', 'c_sw', 'ax_s'], tag: 'fountain' },
        { id: 'c_sw', x: -4.3, z: 4.3,  links: ['c_s', 'c_w'],           tag: 'fountain' },
        { id: 'c_w',  x: -6.0, z: 0,    links: ['c_sw', 'c_nw', 'ax_w'], tag: 'fountain' },
        { id: 'c_nw', x: -4.3, z: -4.3, links: ['c_w', 'c_n'],           tag: 'fountain' },

        // ۴ گذرگاه محوری عریض ۶ متری بین جزیره‌های چمن
        { id: 'ax_n', x: 0,     z: -15.2, links: ['c_n', 'sw_n'], tag: 'plaza' },
        { id: 'ax_e', x: 15.2,  z: 0,     links: ['c_e', 'sw_e'], tag: 'plaza' },
        { id: 'ax_s', x: 0,     z: 15.2,  links: ['c_s', 'sw_s'], tag: 'plaza' },
        { id: 'ax_w', x: -15.2, z: 0,     links: ['c_w', 'sw_w'], tag: 'plaza' },

        // حلقه پیاده‌رو بیرونی (شعاع ۲۵.۸ متر — کاملاً آزاد از چراغ‌ها و نیمکت‌ها و دیوار ساختمان‌ها!)
        { id: 'sw_n',  x: 0,     z: -25.8, links: ['ax_n', 'sw_ne', 'sw_nw', 'am_ent'], tag: 'park' },
        { id: 'sw_ne', x: 18.2,  z: -18.2, links: ['sw_n', 'sw_e'],  tag: 'clothes' },
        { id: 'sw_e',  x: 25.8,  z: 0,     links: ['ax_e', 'sw_ne', 'sw_se', 'pk_ent'], tag: 'furniture' },
        { id: 'sw_se', x: 18.2,  z: 18.2,  links: ['sw_e', 'sw_s'],  tag: 'school' },
        { id: 'sw_s',  x: 0,     z: 25.8,  links: ['ax_s', 'sw_se', 'sw_sw', 'res_c'],  tag: 'plaza' },
        { id: 'sw_sw', x: -18.2, z: 18.2,  links: ['sw_s', 'sw_w'],  tag: 'cafe' },
        { id: 'sw_w',  x: -25.8, z: 0,     links: ['ax_w', 'sw_sw', 'sw_nw', 'wst_1'], tag: 'cinema' },
        { id: 'sw_nw', x: -18.2, z: -18.2, links: ['sw_w', 'sw_n'],  tag: 'gamenet' },

        // مسیر شهربازی، پارک شرقی و پیاده‌رو خیابان‌های اطراف
        { id: 'am_ent', x: 0,     z: -48.0, links: ['sw_n'], tag: 'park' },
        { id: 'pk_ent', x: 53.0,  z: -2.0,  links: ['sw_e', 'pk_n', 'pk_s'], tag: 'nature_park' },
        { id: 'pk_n',   x: 68.0,  z: -16.5, links: ['pk_ent'], tag: 'nature_park' },
        { id: 'pk_s',   x: 68.0,  z: 12.5,  links: ['pk_ent'], tag: 'nature_park' },
        { id: 'wst_1',  x: -52.0, z: 3.6,   links: ['sw_w', 'wst_2', 'res_w3'], tag: 'street' },
        { id: 'wst_2',  x: -84.0, z: 3.6,   links: ['wst_1'], tag: 'street' },
        { id: 'res_c',  x: 3.8,   z: 36.2,  links: ['sw_s', 'res_w1', 'res_e1', 'gol_c'], tag: 'street' },
        { id: 'res_w1', x: -16.0, z: 36.2,  links: ['res_c', 'res_w2'], tag: 'home' },
        { id: 'res_w2', x: -36.0, z: 36.2,  links: ['res_w1', 'res_w3'], tag: 'home' },
        { id: 'res_w3', x: -52.0, z: 36.2,  links: ['res_w2', 'wst_1'], tag: 'street' },
        { id: 'res_e1', x: 16.0,  z: 36.2,  links: ['res_c', 'res_e2'], tag: 'home' },
        { id: 'res_e2', x: 36.0,  z: 36.2,  links: ['res_e1', 'res_e3'], tag: 'home' },
        { id: 'res_e3', x: 64.0,  z: 36.2,  links: ['res_e2'], tag: 'street' },
        { id: 'gol_c',  x: 3.8,   z: 64.2,  links: ['res_c', 'gol_w', 'gol_e'], tag: 'street' },
        { id: 'gol_w',  x: -24.0, z: 64.2,  links: ['gol_c'], tag: 'home' },
        { id: 'gol_e',  x: 24.0,  z: 64.2,  links: ['gol_c'], tag: 'home' }
    ];

    // ۹. درختان بلوارهای جدید و کمربند سبز دور شهر (کاملاً خارج از سطح آسفالت خیابان‌ها)
    [
        [-22, 34.5], [-46, 34.5], [22, 34.5], [46, 34.5], [84, 34.5],
        [-26, 48], [26, 48], [-48, 8], [-48, -22],
        [-64, 62.5], [-10, 62.5], [10, 62.5], [44, 62.5], [86, 62.5],
        [-40, -32.5], [38, -32.5], [76, -32.5], [-74, -32.5]
    ].forEach(([tx, tz]) => addTree(ctx, tx, tz, 0.95));
    for (let i = 0; i < 34; i++) {
        const a = (i / 34) * Math.PI * 2;
        const r = 104 + rnd() * 8;
        const tx = Math.cos(a) * r * 1.06, tz = Math.sin(a) * r * 0.88;
        if (Math.abs(tx) < 103 && Math.abs(tz) < 84) continue;
        addTree(ctx, tx, tz, 1.0 + rnd() * 0.45);
    }
}

/* ============================================================================
   فضای داخلی ساختمان‌ها
   ============================================================================ */
export function buildCityInterior(zoneId, ctx) {
    const bgMap = { hair_salon: 0xffe4e6, cinema: 0x1e293b, gamenet: 0x064e3b, amusement_park: 0xffedd5, shop_clothes: 0xfce7f3, shop_furniture: 0xffedd5, shop_accessories: 0xe0f2fe, school_hall: 0xeff6ff, cafe: 0xf3e3d3 };
    const base = bgMap[zoneId] || 0xf1f5f9;
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(26, 24), new THREE.MeshStandardMaterial({ color: base }));
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    ctx.worldGroup.add(ground);
    ctx.setGround(ground);

    const wallMat = new THREE.MeshStandardMaterial({ color: 0xfef9c3 });
    const back = new THREE.Mesh(new THREE.BoxGeometry(26, 6, 0.4), wallMat); back.position.set(0, 3, -12);
    const left = new THREE.Mesh(new THREE.BoxGeometry(0.4, 6, 24), wallMat); left.position.set(-13, 3, 0);
    const right = new THREE.Mesh(new THREE.BoxGeometry(0.4, 6, 24), wallMat); right.position.set(13, 3, 0);
    ctx.worldGroup.add(back, left, right);
    ctx.setBounds({ minX: -12.2, maxX: 12.2, minZ: -11.2, maxZ: 11.6 });

    if (zoneId.startsWith('shop_')) {
        (CATALOG[zoneId] || []).forEach((item, idx) => {
            const xPos = -8 + idx * 3.2;
            const stand = new THREE.Mesh(new THREE.CylinderGeometry(1.0, 1.1, 0.5, 20), new THREE.MeshStandardMaterial({ color: 0x475569 }));
            stand.position.set(xPos, 0.25, -4);
            const bxm = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.9, 0.9), new THREE.MeshStandardMaterial({ color: item.color }));
            bxm.position.set(xPos, 1.1, -4);
            ctx.worldGroup.add(stand, bxm);
            ctx.interactables.push(stand, bxm);
        });
    } else if (zoneId === 'gamenet') {
        GAMENET_GAMES.forEach((g, idx) => {
            const xPos = -5 + idx * 5;
            const cab = new THREE.Mesh(new THREE.BoxGeometry(1.8, 3.2, 1.5), new THREE.MeshStandardMaterial({ color: 0x10b981 }));
            cab.position.set(xPos, 1.6, -5);
            ctx.worldGroup.add(cab);
            ctx.interactables.push(cab);
        });
    } else {
        const board = new THREE.Mesh(new THREE.BoxGeometry(12, 4.5, 0.3), new THREE.MeshBasicMaterial({ map: createSignTexture('کلیک کنید برای شروع فعالیت یا خرید بلیت', '#1e293b', '#38bdf8') }));
        board.position.set(0, 3.2, -11.5);
        ctx.worldGroup.add(board);
        ctx.interactables.push(board);
    }

    ctx.addPortal(0, 9.2, 'plaza', '🏙️ خروج به میدان شهر', 0x10b981);
}
