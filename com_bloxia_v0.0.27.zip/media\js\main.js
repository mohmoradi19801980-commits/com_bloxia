import * as THREE from './three/three.module.js';
import { bridge } from './bridge.js';
import { createCharacterRig, updateCharacterAnimation, renderCharacterPortrait } from './character.js';
import { buildCityPlaza, buildCityInterior } from './city.js';
import { buildHomeInterior, buildRealisticFurniture } from './home.js';
import { CityLifeManager } from './world-life.js';
import { UIController } from './ui-panels.js';

const PLAZA_NPCS = [
    {
        id: 202, name: 'سارا', startNode: 'c_sw',
        appearance: { skin: 'none', mood: 'happy', skinColor: 0xf1c27d, hairStyle: 'long', hairColor: 0x3b2314, shirtColor: 0xec4899, pantsColor: 0x334155, shoesColor: 0xffffff, hat: 'hat_crown', handProp: 'prop_flower' }
    },
    {
        id: 203, name: 'آرش', startNode: 'c_se',
        appearance: { skin: 'none', mood: 'excited', skinColor: 0xffdbac, hairStyle: 'short', hairColor: 0x1e293b, shirtColor: 0x3b82f6, pantsColor: 0x1e293b, shoesColor: 0xef4444, hat: 'hat_cap', handProp: null }
    },
    {
        id: 204, name: 'نیما', startNode: 'sw_nw',
        appearance: { skin: 'none', mood: 'happy', skinColor: 0xe0ac69, hairStyle: 'curly', hairColor: 0x451a03, shirtColor: 0x10b981, pantsColor: 0x1e3a8a, shoesColor: 0xf8fafc, hat: null, handProp: null }
    },
    {
        id: 205, name: 'پریسا', startNode: 'sw_e',
        appearance: { skin: 'nezuko', mood: 'happy', skinColor: 0xffe4d6, hairStyle: 'long', hairColor: 0x111827, shirtColor: 0xf9a8d4, pantsColor: 0xf472b6, shoesColor: 0xffffff, hat: null, handProp: null }
    },
    {
        id: 206, name: 'کاوه', startNode: 'sw_ne',
        appearance: { skin: 'spiderman', mood: 'happy', skinColor: 0xffdbac, hairStyle: 'short', hairColor: 0x111827, shirtColor: 0xdc2626, pantsColor: 0x1d4ed8, shoesColor: 0xdc2626, hat: null, handProp: null }
    }
];

const LOCATION_THOUGHTS = {
    cinema: ['فیلم جدید سینما چقدر هیجان‌انگیز به نظر میاد 🎬', 'کلاکت بزرگ روی سقف سینما رو دیدی؟ 🍿'],
    gamenet: ['بریم گیم‌نت رکورد جدید بزنیم! 🕹️', 'دسته بازی نئونی بالای گیم‌نت خیلی جذابه 🎮'],
    clothes: ['ویترین جدید بوتیک لباس رو دیدی؟ 👗', 'دنبال یه استایل جدیدم ✨'],
    furniture: ['واسه چیدمان خونه‌م یه مبل جدید می‌خوام 🛋️', 'مبل طلایی بالای سقف فروشگاه چه باحاله 💡'],
    cafe: ['بوی قهوه داغ از کافه میاد ☕', 'فنجون بزرگ بالای سقف کافه رو نگاه کن! 🍰'],
    school: ['جشنواره بازی‌سازی مدرسه شروع شده 🎓', 'برج ساعت مدرسه از کل شهر پیداست 🕰️'],
    park: ['محوطه باز شهربازی و کاروسل اسبی عالی شده 🎡', 'کیا پایه چرخ‌وفلک هستن؟ 🎪'],
    nature_park: ['تو پارک بزرگ ۵ تا بازی مختلف گذاشتن! 🌳', 'ماهیگیری کنار برکه پارک خیلی کیف میده 🎣'],
    home: ['خیابون مسکونی چقدر دلباز و آرومه 🏡', 'باغچه خونه‌ها پر از گل و سگ و گربه‌ست 🐕'],
    fountain: ['درخشش کریستال آبنما فوق‌العاده‌ست 💎', 'پرنده‌ها دور میدان پرواز می‌کنن 🐦'],
    plaza: ['چه روز خوبی برای قدم زدن تو شهر 😊', 'ماشین‌ها و دوچرخه‌ها چه نظمی به شهر دادن 🚗'],
    street: ['پیاده‌روهای جدید شهر خیلی راحت شدن 🚶', 'بریم یه سر به محله همسایه‌ها بزنیم 🏘️']
};

const SKIN_REACTIONS = {
    batman: 'واو! بتمن واقعی تو شهر ماست؟! 🦇',
    superman: 'سوپرمن! پرواز هم می‌کنی؟ 🦸',
    green_lantern: 'حلقه گرین لنترن چقدر می‌درخشه! 💚',
    spiderman: 'اسپایدرمن! یه عکس یادگاری بگیریم؟ 🕷️',
    rick: 'ریک سانچز! پورتال بعدی به کدوم بُعده؟ 🧪',
    morty: 'سلام مورتی! ریک کجاست؟ 😄',
    dr_strange: 'شنل دکتر استرنج چقدر باشکوهه! 🔮',
    tanjiro: 'تانجیرو! شمشیر نیچیرین رو ببین! 🌊',
    nezuko: 'نزوکو چقدر بامزه شده! 🎋',
    zenitsu: 'زنیتسو! تنفس آذرخش رو نشون بده ⚡',
    inosuke: 'ماسک گراز اینوسکه رو نگاه کن! 🐗'
};

class MetaverseApp {
    constructor() {
        this.scene = new THREE.Scene();
        this.camera = new THREE.PerspectiveCamera(42, window.innerWidth / window.innerHeight, 0.1, 460);
        this.camera.position.set(0, 26, 31);
        this.camZoom = 1.0;

        this.renderer = new THREE.WebGLRenderer({ antialias: true });
        this.renderer.setSize(window.innerWidth, window.innerHeight);
        this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        this.renderer.shadowMap.enabled = true;
        this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
        this.renderer.toneMappingExposure = 0.96;
        document.getElementById('canvas-container').appendChild(this.renderer.domElement);

        this.hemiLight = new THREE.HemisphereLight(0xfffbeb, 0x3f6212, 0.68);
        this.ambientLight = new THREE.AmbientLight(0xfff7ed, 0.36);
        this.dirLight = new THREE.DirectionalLight(0xffe8a3, 1.35);
        this.dirLight.position.set(38, 58, 34);
        this.dirLight.castShadow = true;
        this.dirLight.shadow.mapSize.set(2048, 2048);
        this.dirLight.shadow.camera.near = 5;
        this.dirLight.shadow.camera.far = 235;
        this.dirLight.shadow.camera.left = -108;
        this.dirLight.shadow.camera.right = 108;
        this.dirLight.shadow.camera.top = 108;
        this.dirLight.shadow.camera.bottom = -108;
        this.scene.add(this.hemiLight, this.ambientLight, this.dirLight);

        this.worldGroup = new THREE.Group();
        this.remotePlayersGroup = new THREE.Group();
        this.homeFurnitureGroup = new THREE.Group();
        this.scene.add(this.worldGroup, this.remotePlayersGroup, this.homeFurnitureGroup);

        this.cityLife = new CityLifeManager(this);

        this.targetRing = new THREE.Mesh(
            new THREE.RingGeometry(0.35, 0.55, 24),
            new THREE.MeshBasicMaterial({ color: 0xfbbf24, side: THREE.DoubleSide })
        );
        this.targetRing.rotation.x = -Math.PI / 2;
        this.targetRing.position.y = 0.08;
        this.targetRing.visible = false;
        this.scene.add(this.targetRing);

        this.currentZone = 'plaza';
        this.groundMesh = null;
        this.worldBounds = null;
        this.navNodes = [];
        this.seats = [];
        this.obstacles = [];
        this.furnitureObstacles = [];
        this.portals = [];
        this.interactables = [];
        this.animatedLandmarks = [];
        this.minimapBuildings = [];
        this.streetLampBulbs = [];
        this.streetLampLights = [];
        this.streetLampPools = [];
        this.activePortal = null;
        this.activeSeat = null;
        this.remoteRigs = new Map();
        this.npcList = [];

        this.timeModes = ['day', 'sunset', 'night'];
        this.weatherModes = ['sunny', 'cloudy', 'rain', 'snow'];
        this.timeIdx = 0;
        this.weatherIdx = 0;

        this.placingItem = null;
        this.placingPreview = null;
        this.placingRot = 0;

        this.setupWeatherParticles();
        this.ui = new UIController(this);
        this.bindInputs();
    }

    setupWeatherParticles() {
        const count = 1100;
        const geo = new THREE.BufferGeometry();
        const pos = new Float32Array(count * 3);
        for (let i = 0; i < count; i++) {
            pos[i * 3] = (Math.random() - 0.5) * 160;
            pos[i * 3 + 1] = Math.random() * 38;
            pos[i * 3 + 2] = (Math.random() - 0.5) * 160;
        }
        geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
        this.weatherMat = new THREE.PointsMaterial({ color: 0xffffff, size: 0.25, transparent: true, opacity: 0.85 });
        this.weatherPoints = new THREE.Points(geo, this.weatherMat);
        this.weatherPoints.visible = false;
        this.scene.add(this.weatherPoints);
    }

    setCharacterMood(moodId, persistServer = false) {
        if (!this.playerState) return;
        this.playerState.appearance.mood = moodId;
        if (this.myRig) this.myRig.applyAppearance(this.playerState.appearance);
        renderCharacterPortrait(this.playerState.appearance);

        document.querySelectorAll('.mood-pill-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.mood === moodId);
        });

        if (persistServer) {
            bridge.saveCharacterAppearance(this.playerState.appearance, this.playerState.name);
        }
    }

    applyAtmosphere() {
        const t = this.timeModes[this.timeIdx];
        const w = this.weatherModes[this.weatherIdx];
        const outdoor = this.currentZone === 'plaza';
        this.weatherPoints.visible = outdoor && (w === 'rain' || w === 'snow');

        if (!outdoor) {
            this.scene.fog = null;
            this.ambientLight.intensity = 0.82;
            this.hemiLight.intensity = 0.65;
            this.dirLight.intensity = 1.05;
            return;
        }

        const isNight = t === 'night';
        const isSunset = t === 'sunset';
        const isOvercast = w === 'cloudy' || w === 'rain';
        const sky = isNight ? 0x0b132b : (isSunset ? 0xfb923c : (w === 'sunny' ? 0x99d5ff : 0x94a3b8));

        this.hemiLight.intensity = isNight ? 0.22 : (isSunset ? 0.5 : 0.72);
        this.ambientLight.intensity = isNight ? 0.18 : (isSunset ? 0.32 : 0.38);
        this.dirLight.color.setHex(isSunset ? 0xf97316 : (isNight ? 0x93c5fd : 0xffe8a3));
        this.dirLight.intensity = isNight ? 0.22 : (isSunset ? 0.95 : 1.35);
        this.scene.background = new THREE.Color(sky);
        this.scene.fog = new THREE.Fog(sky, 115, 275);

        const lampOn = isNight || isSunset || isOvercast;
        const bulbEmissive = isNight ? 2.2 : (isSunset ? 1.5 : (isOvercast ? 0.9 : 0.35));
        const lightPower = isNight ? 4.2 : (isSunset ? 2.4 : (isOvercast ? 1.1 : 0.25));
        const poolOpacity = isNight ? 0.68 : (isSunset ? 0.42 : (isOvercast ? 0.22 : 0.06));

        this.streetLampBulbs.forEach(m => { m.emissiveIntensity = bulbEmissive; });
        this.streetLampLights.forEach(l => {
            l.intensity = lampOn ? lightPower : 0.2;
            l.distance = isNight ? 28 : 20;
        });
        this.streetLampPools.forEach(p => { p.opacity = poolOpacity; });
    }

    setGround(mesh) { this.groundMesh = mesh; }
    setBounds(bounds) { this.worldBounds = bounds; }

    addPortal(x, z, targetZone, promptLabel, color = 0xf59e0b) {
        const pad = new THREE.Mesh(
            new THREE.CylinderGeometry(1.25, 1.25, 0.08, 28),
            new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.4, roughness: 0.35 })
        );
        pad.position.set(x, 0.08, z);
        this.worldGroup.add(pad);
        this.portals.push({ x, z, targetZone, promptLabel });
    }

    findNavPath(startId, goalId) {
        if (!this.navNodes.length || startId === goalId) return [goalId];
        const map = new Map(this.navNodes.map(n => [n.id, n]));
        const queue = [[startId]];
        const visited = new Set([startId]);
        while (queue.length > 0) {
            const path = queue.shift();
            const curr = map.get(path[path.length - 1]);
            if (!curr) continue;
            for (const nextId of curr.links) {
                if (nextId === goalId) return [...path.slice(1), nextId];
                if (!visited.has(nextId)) {
                    visited.add(nextId);
                    queue.push([...path, nextId]);
                }
            }
        }
        return [goalId];
    }

    getNearestNavNode(x, z) {
        let best = null, bestD = Infinity;
        for (const n of this.navNodes) {
            const d = Math.hypot(n.x - x, n.z - z);
            if (d < bestD) { bestD = d; best = n; }
        }
        return best;
    }

    clearNpcs() {
        this.npcList.forEach(n => {
            this.remotePlayersGroup.remove(n.rig.mesh);
            if (n.rig.labelEl) n.rig.labelEl.remove();
        });
        this.npcList = [];
    }

    spawnPlazaNpcs() {
        const nodeMap = new Map(this.navNodes.map(n => [n.id, n]));
        PLAZA_NPCS.forEach((def, idx) => {
            const startNode = nodeMap.get(def.startNode) || this.navNodes[idx % this.navNodes.length] || { id: 'c_s', x: 0, z: 6 };
            const rig = createCharacterRig(def.name, def.appearance, { id: def.id, name: def.name });
            rig.mesh.position.set(startNode.x, 0, startNode.z);
            rig.targetPos.set(startNode.x, 0, startNode.z);
            this.remotePlayersGroup.add(rig.mesh);

            const npc = {
                def,
                rig,
                currentNodeId: startNode.id,
                pathQueue: [],
                pauseTimer: 0.35 * idx,
                sitTimer: 0,
                chatCooldown: 5 + idx * 4.5,
                lastSaid: '',
                stuckTimer: 0,
                lastCheckPos: new THREE.Vector3(startNode.x, 0, startNode.z)
            };
            this.pickNextNpcDestination(npc);
            this.npcList.push(npc);
        });
    }

    pickNextNpcDestination(npc) {
        if (!this.navNodes.length) return;
        const candidates = this.navNodes.filter(n => n.id !== npc.currentNodeId);
        const dest = candidates[Math.floor(Math.random() * candidates.length)];
        if (!dest) return;
        npc.pathQueue = this.findNavPath(npc.currentNodeId, dest.id);
        this.advanceNpcWaypoint(npc);
    }

    advanceNpcWaypoint(npc) {
        if (!npc.pathQueue.length) {
            npc.pauseTimer = 1.4 + Math.random() * 2.0;
            return;
        }
        const nextId = npc.pathQueue.shift();
        const node = this.navNodes.find(n => n.id === nextId);
        if (node) {
            npc.currentNodeId = node.id;
            npc.currentTag = node.tag;
            npc.rig.targetPos.set(node.x, 0, node.z);
        }
    }

    buildContextualThought(npc) {
        const pool = [];
        const w = this.weatherModes[this.weatherIdx];
        const t = this.timeModes[this.timeIdx];

        if (w === 'rain') pool.push('بارون گرفت! چقدر هوا لطیف شد ☔', 'بریم زیر سایبان خیس نشیم! 🌧️');
        else if (w === 'snow') pool.push('برف شروع شد! شهر سفیدپوش میشه ❄️', 'چه هوای برفی باحالی! ⛄');

        if (t === 'night') pool.push('نور چراغ‌های شهر تو شب چقدر قشنگه ✨', 'شب‌های شهر خیلی آرامش‌بخشه 🌙');
        else if (t === 'sunset') pool.push('آسمون غروب رو ببین چقدر نارنجیه 🌅');

        if (this.myRig) {
            const distToPlayer = npc.rig.mesh.position.distanceTo(this.myRig.mesh.position);
            const pSkin = this.playerState?.appearance?.skin;
            if (distToPlayer < 8.5 && pSkin && SKIN_REACTIONS[pSkin]) {
                pool.push(SKIN_REACTIONS[pSkin], SKIN_REACTIONS[pSkin]);
            } else if (distToPlayer < 6.5) {
                pool.push(`سلام ${this.playerState?.name || 'دوست من'}! خوش اومدی 👋`);
            }
        }

        const locList = LOCATION_THOUGHTS[npc.currentTag || 'plaza'] || LOCATION_THOUGHTS.plaza;
        pool.push(...locList);

        const filtered = pool.filter(msg => msg !== npc.lastSaid);
        const list = filtered.length ? filtered : pool;
        const chosen = list[Math.floor(Math.random() * list.length)];
        npc.lastSaid = chosen;
        return chosen;
    }

    updateNpcs(dt, t) {
        this.npcList.forEach(n => {
            if (n.rig.sitting) {
                n.sitTimer -= dt;
                if (n.sitTimer <= 0) {
                    n.rig.standUp();
                    const nearest = this.getNearestNavNode(n.rig.mesh.position.x, n.rig.mesh.position.z);
                    if (nearest) {
                        n.currentNodeId = nearest.id;
                        n.rig.targetPos.set(nearest.x, 0, nearest.z);
                    }
                    this.pickNextNpcDestination(n);
                }
                updateCharacterAnimation(n.rig, dt, t, this.camera, null, null);
                return;
            }

            const pos = n.rig.mesh.position;
            const dist = pos.distanceTo(n.rig.targetPos);

            if (dist < 0.38) {
                if (n.pathQueue.length > 0) {
                    this.advanceNpcWaypoint(n);
                } else {
                    // گاهی شهروند روی نیمکت نزدیک می‌نشیند و استراحت می‌کند
                    const freeSeat = this.seats.find(s =>
                        Math.hypot(s.x - pos.x, s.z - pos.z) < 6.5 &&
                        (!this.myRig?.sitting || this.myRig.sitSeat !== s) &&
                        !this.npcList.some(o => o.rig.sitting && o.rig.sitSeat === s)
                    );
                    if (freeSeat && Math.random() < 0.25) {
                        n.rig.sitOn(freeSeat);
                        n.sitTimer = 4.5 + Math.random() * 3.0;
                        return;
                    }
                    n.pauseTimer -= dt;
                    if (n.pauseTimer <= 0) {
                        this.pickNextNpcDestination(n);
                    }
                }
            } else {
                n.stuckTimer += dt;
                if (n.stuckTimer > 0.9) {
                    const moved = pos.distanceTo(n.lastCheckPos);
                    n.lastCheckPos.copy(pos);
                    n.stuckTimer = 0;
                    if (moved < 0.25) {
                        const nearest = this.getNearestNavNode(pos.x, pos.z);
                        if (nearest) {
                            n.currentNodeId = nearest.id;
                            n.rig.mesh.position.set(nearest.x, 0, nearest.z);
                            n.rig.targetPos.set(nearest.x, 0, nearest.z);
                            n.pathQueue = [];
                            this.pickNextNpcDestination(n);
                        }
                    }
                }
            }

            n.chatCooldown -= dt;
            if (n.chatCooldown <= 0) {
                n.chatCooldown = 14 + Math.random() * 14;
                n.rig.say(this.buildContextualThought(n));
            }

            // چون گراف مسیر پیاده‌رو ۱۰۰٪ بدون مانع است، حرکت مستقیم روی گراف نرم و بدون گیر کردن است
            updateCharacterAnimation(n.rig, dt * 0.8, t, this.camera, null, null);
        });
    }

    async loadZone(zoneId) {
        if (zoneId === 'amusement_park' && this.currentZone === 'plaza') {
            this.ui.openParkActivityHub('carnival_wheel');
            return;
        }

        const overlay = document.getElementById('fade-overlay');
        overlay.classList.add('active');
        await new Promise(r => setTimeout(r, 240));

        if (this.myRig) this.myRig.standUp((x, z) => this.checkCollision(x, z));
        this.clearNpcs();
        this.cityLife.clear();
        this.worldGroup.clear();
        this.homeFurnitureGroup.clear();
        this.worldBounds = null;
        this.navNodes = [];
        this.seats = [];
        this.obstacles = [];
        this.furnitureObstacles = [];
        this.portals = [];
        this.interactables = [];
        this.animatedLandmarks = [];
        this.minimapBuildings = [];
        this.streetLampBulbs = [];
        this.streetLampLights = [];
        this.streetLampPools = [];
        this.activePortal = null;
        this.activeSeat = null;
        this.targetRing.visible = false;
        document.getElementById('portal-prompt').classList.remove('visible');

        this.currentZone = zoneId;
        const isHome = zoneId.startsWith('home_');

        document.getElementById('btn-go-plaza').style.display = zoneId === 'plaza' ? 'none' : 'flex';
        document.getElementById('btn-go-my-home').style.display = zoneId === `home_${this.playerState.userId}` ? 'none' : 'flex';
        document.getElementById('btn-toggle-inventory').style.display = 'none';
        document.getElementById('btn-open-wardrobe').style.display = 'none';

        if (zoneId === 'plaza') {
            document.getElementById('zone-title-display').textContent = '🏙️ میدان اصلی شهر';
            const plots = await bridge.getResidentialPlots();
            buildCityPlaza(this, plots);
            this.myRig.mesh.position.set(0, 0, 7.2);
            this.myRig.targetPos.set(0, 0, 7.2);
            this.spawnPlazaNpcs();
            this.cityLife.spawnForPlaza();
        } else if (isHome) {
            const ownerId = Number(zoneId.replace('home_', ''));
            const homeData = await bridge.getHomeData(ownerId);
            document.getElementById('zone-title-display').textContent = homeData.isMine ? '🏠 خانه من' : `🏠 خانه ${homeData.ownerName}`;
            if (homeData.isMine) {
                document.getElementById('btn-toggle-inventory').style.display = 'flex';
                document.getElementById('btn-open-wardrobe').style.display = 'flex';
            }
            this.scene.background = new THREE.Color(0xbae6fd);
            buildHomeInterior(homeData, this);
            this.currentHomeData = homeData;
            this.renderHomeFurniture();
            this.myRig.mesh.position.set(0, 0, 5.5);
            this.myRig.targetPos.set(0, 0, 5.5);
        } else {
            document.getElementById('zone-title-display').textContent = '🏛️ فضای داخلی';
            this.scene.background = new THREE.Color(0xe0f2fe);
            buildCityInterior(zoneId, this);
            this.myRig.mesh.position.set(0, 0, 5.5);
            this.myRig.targetPos.set(0, 0, 5.5);
        }

        this.applyAtmosphere();
        this.remoteRigs.forEach(r => r.labelEl.remove());
        this.remoteRigs.clear();
        await this.syncWorld();

        overlay.classList.remove('active');
    }

    renderHomeFurniture() {
        this.homeFurnitureGroup.clear();
        this.furnitureObstacles = [];
        const layout = this.currentHomeData?.layout || this.playerState.homeLayout;
        layout.forEach(p => {
            const mesh = buildRealisticFurniture(p.itemId);
            mesh.position.set(p.x, 0, p.z);
            mesh.rotation.y = p.rotY || 0;
            if (p.itemId === 'furn_tv') {
                mesh.userData = { action: 'tv_studio', homeData: this.currentHomeData };
                this.interactables.push(mesh);
                this.furnitureObstacles.push({ cx: p.x, cz: p.z, rot: p.rotY || 0, hw: 0.95, hd: 0.45 });
            } else if (p.itemId === 'furn_sofa') {
                const seatInfo = { x: p.x, z: p.z, rotY: p.rotY || 0, label: '🛋️ نشستن روی مبل' };
                mesh.userData = { action: 'sit_seat', seat: seatInfo };
                this.interactables.push(mesh);
                this.seats.push(seatInfo);
            } else {
                this.furnitureObstacles.push({ cx: p.x, cz: p.z, rot: p.rotY || 0, hw: 0.85, hd: 0.55 });
            }
            this.homeFurnitureGroup.add(mesh);
        });
    }

    startPlacingFurniture(itemDef) {
        this.placingItem = itemDef;
        this.placingRot = 0;
        if (this.placingPreview) this.scene.remove(this.placingPreview);
        this.placingPreview = buildRealisticFurniture(itemDef.id);
        this.scene.add(this.placingPreview);
        document.getElementById('home-edit-banner').style.display = 'flex';
    }

    cancelPlacing() {
        this.placingItem = null;
        if (this.placingPreview) { this.scene.remove(this.placingPreview); this.placingPreview = null; }
        document.getElementById('home-edit-banner').style.display = 'none';
    }

    bindInputs() {
        const timeLabels = ['☀️ تغییر زمان (روز)', '🌅 تغییر زمان (غروب)', '🌙 تغییر زمان (شب)'];
        document.getElementById('btn-cycle-time').onclick = (e) => {
            this.timeIdx = (this.timeIdx + 1) % 3;
            e.currentTarget.textContent = timeLabels[this.timeIdx];
            this.applyAtmosphere();
        };
        const weatherLabels = ['🌤️ آب‌وهوا (آفتابی)', '☁️ آب‌وهوا (ابری)', '🌧️ آب‌وهوا (بارانی)', '❄️ آب‌وهوا (برفی)'];
        document.getElementById('btn-cycle-weather').onclick = (e) => {
            this.weatherIdx = (this.weatherIdx + 1) % 4;
            e.currentTarget.textContent = weatherLabels[this.weatherIdx];
            this.applyAtmosphere();
        };

        document.querySelectorAll('.mood-pill-btn').forEach(btn => {
            btn.onclick = () => {
                const mId = btn.dataset.mood;
                this.setCharacterMood(mId, true);
                const labels = { happy: '😊 حالم عالیه!', excited: '🤩 چقدر هیجان‌انگیز!', angry: '😠 عجب داستانیا!', sad: '😢 دلم گرفته...', surprised: '😮 وای باورم نمیشه!' };
                if (this.myRig && labels[mId]) this.myRig.say(labels[mId]);
            };
        });

        document.getElementById('portal-prompt').onclick = () => {
            if (this.activePortal) {
                this.loadZone(this.activePortal.targetZone);
            } else if (this.myRig?.sitting) {
                this.myRig.standUp((x, z) => this.checkCollision(x, z));
                document.getElementById('portal-prompt').classList.remove('visible');
            } else if (this.activeSeat && this.myRig) {
                this.myRig.sitOn(this.activeSeat);
                this.myRig.say('چقدر نشستن اینجا آرامش داره! 🪑✨');
                this.activeSeat = null;
            }
        };
        document.getElementById('btn-go-my-home').onclick = () => {
            document.getElementById('flyout-bag')?.classList.remove('open');
            this.loadZone(`home_${this.playerState.userId}`);
        };
        document.getElementById('btn-go-plaza').onclick = () => {
            document.getElementById('flyout-bag')?.classList.remove('open');
            this.loadZone('plaza');
        };
        document.getElementById('btn-rotate-furniture').onclick = () => { this.placingRot += Math.PI / 2; if (this.placingPreview) this.placingPreview.rotation.y = this.placingRot; };
        document.getElementById('btn-cancel-place').onclick = () => this.cancelPlacing();

        document.querySelectorAll('.coc-emote-btn').forEach(btn => {
            btn.onclick = () => {
                this.myRig.triggerEmote(btn.dataset.emote);
                this.myRig.say(btn.dataset.text);
                this.npcList.forEach(n => {
                    if (n.rig.mesh.position.distanceTo(this.myRig.mesh.position) < 9.5) {
                        setTimeout(() => {
                            n.rig.triggerEmote('wave');
                            n.rig.say('سلام! چقدر پرانرژی هستی! 🌟');
                        }, 450);
                    }
                });
            };
        });

        this.renderer.domElement.addEventListener('wheel', (e) => {
            e.preventDefault();
            this.camZoom = Math.min(1.65, Math.max(0.48, this.camZoom + e.deltaY * 0.0007));
        }, { passive: false });

        const raycaster = new THREE.Raycaster();
        const pointer = new THREE.Vector2();

        this.renderer.domElement.addEventListener('pointermove', (e) => {
            if (!this.placingItem || !this.placingPreview || !this.groundMesh) return;
            pointer.x = (e.clientX / window.innerWidth) * 2 - 1;
            pointer.y = -(e.clientY / window.innerHeight) * 2 + 1;
            raycaster.setFromCamera(pointer, this.camera);
            const hits = raycaster.intersectObject(this.groundMesh);
            if (hits.length > 0) {
                this.placingPreview.position.x = Math.round(hits[0].point.x);
                this.placingPreview.position.z = Math.round(hits[0].point.z);
            }
        });

        this.renderer.domElement.addEventListener('pointerdown', async (e) => {
            if (e.button !== 0 && e.pointerType === 'mouse') return;
            ['flyout-social', 'flyout-bag', 'flyout-settings'].forEach(fid => document.getElementById(fid)?.classList.remove('open'));

            pointer.x = (e.clientX / window.innerWidth) * 2 - 1;
            pointer.y = -(e.clientY / window.innerHeight) * 2 + 1;
            raycaster.setFromCamera(pointer, this.camera);

            const pHits = raycaster.intersectObjects(this.remotePlayersGroup.children, true);
            if (pHits.length > 0) {
                let obj = pHits[0].object;
                while (obj) {
                    if (obj.userData?.citizenData) { this.ui.openDirectPlayerCard(obj.userData.citizenData); return; }
                    obj = obj.parent;
                }
            }

            const iHits = raycaster.intersectObjects(this.interactables, true);
            if (iHits.length > 0) {
                let obj = iHits[0].object;
                while (obj) {
                    if (obj.userData?.action === 'sit_seat') {
                        if (this.myRig.sitting && this.myRig.sitSeat === obj.userData.seat) {
                            this.myRig.standUp((x, z) => this.checkCollision(x, z));
                        } else {
                            this.myRig.sitOn(obj.userData.seat);
                            this.myRig.say('نشستم استراحت کنم! 🪑✨');
                        }
                        return;
                    }
                    if (obj.userData?.action === 'pet_animal') {
                        this.cityLife.petAnimal(obj.userData.animalRef);
                        this.myRig.triggerEmote('wave');
                        this.myRig.say('آخی چقدر بامزه‌ای! 🥰🐾');
                        return;
                    }
                    if (obj.userData?.action === 'park_game') {
                        this.ui.openParkActivityHub(obj.userData.gameId);
                        return;
                    }
                    if (obj.userData?.action === 'tv_studio') { this.ui.openTvStudioPanel(obj.userData.homeData); return; }
                    if (obj.userData?.action === 'wardrobe') { this.ui.openWardrobePanel(); return; }
                    obj = obj.parent;
                }
                this.ui.openZoneActivity(this.currentZone);
                return;
            }

            if (!this.groundMesh) return;
            const hits = raycaster.intersectObject(this.groundMesh);
            if (hits.length === 0) return;
            const pt = hits[0].point;

            if (this.placingItem && this.placingPreview) {
                const idx = this.playerState.furnitureInventory.indexOf(this.placingItem.id);
                if (idx > -1) this.playerState.furnitureInventory.splice(idx, 1);
                this.playerState.homeLayout.push({ uid: 'f_' + Date.now(), itemId: this.placingItem.id, x: Math.round(pt.x), z: Math.round(pt.z), rotY: this.placingRot });
                this.renderHomeFurniture();
                this.playerState = await bridge.updateHomeAndInventory(this.playerState.homeLayout, this.playerState.furnitureInventory);
                this.cancelPlacing();
                return;
            }

            if (this.myRig.sitting) this.myRig.standUp((x, z) => this.checkCollision(x, z));
            this.myRig.targetPos.set(pt.x, 0, pt.z);
            this.targetRing.position.set(pt.x, 0.08, pt.z);
            this.targetRing.visible = true;
        });

        window.addEventListener('keydown', (e) => {
            if (this.myRig?.sitting && ['Space', 'Escape', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'KeyW', 'KeyA', 'KeyS', 'KeyD'].includes(e.code)) {
                this.myRig.standUp((x, z) => this.checkCollision(x, z));
            }
        });

        window.addEventListener('resize', () => {
            this.camera.aspect = window.innerWidth / window.innerHeight;
            this.camera.updateProjectionMatrix();
            this.renderer.setSize(window.innerWidth, window.innerHeight);
        });
    }

    async syncWorld() {
        if (!this.myRig) return;
        const others = await bridge.syncWorld({ zone: this.currentZone, x: this.myRig.mesh.position.x, z: this.myRig.mesh.position.z });
        const ids = new Set();
        others.forEach(p => {
            ids.add(p.id);
            let rig = this.remoteRigs.get(p.id);
            if (!rig) {
                rig = createCharacterRig(p.name, p.appearance, p);
                rig.mesh.position.set(p.x, 0, p.z);
                rig.targetPos.set(p.x, 0, p.z);
                this.remotePlayersGroup.add(rig.mesh);
                this.remoteRigs.set(p.id, rig);
            } else {
                rig.targetPos.set(p.x, 0, p.z);
            }
        });
        for (const [id, rig] of this.remoteRigs.entries()) {
            if (!ids.has(id)) { this.remotePlayersGroup.remove(rig.mesh); rig.labelEl.remove(); this.remoteRigs.delete(id); }
        }
    }

    renderMiniMap(time = 0) {
        const canvas = document.getElementById('minimap-canvas');
        const ctx = canvas.getContext('2d');
        const w = canvas.width, h = canvas.height;
        const cx = w / 2, cy = h / 2;
        ctx.clearRect(0, 0, w, h);

        const sweepAngle = (time * 0.45) % (Math.PI * 2);
        const grad = ctx.createRadialGradient(cx, cy, 4, cx, cy, w / 2);
        grad.addColorStop(0, 'rgba(255, 255, 255, 0.35)');
        grad.addColorStop(1, 'rgba(187, 247, 208, 0.05)');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.arc(cx, cy, w / 2, sweepAngle - 0.42, sweepAngle + 0.42);
        ctx.closePath();
        ctx.fill();

        ctx.strokeStyle = 'rgba(255, 255, 255, 0.32)';
        ctx.lineWidth = 1.2;
        [34, 68, 98].forEach(r => {
            ctx.beginPath();
            ctx.arc(cx, cy, r, 0, Math.PI * 2);
            ctx.stroke();
        });
        ctx.beginPath();
        ctx.moveTo(cx, 0); ctx.lineTo(cx, h);
        ctx.moveTo(0, cy); ctx.lineTo(w, cy);
        ctx.stroke();

        if (this.currentZone !== 'plaza') return;
        const px = this.myRig ? this.myRig.mesh.position.x : 0;
        const pz = this.myRig ? this.myRig.mesh.position.z : 0;
        const scale = w / 156;
        const tx = (x) => cx + (x - px) * scale;
        const ty = (z) => cy + (z - pz) * scale;

        // نمایش نماد (آیکن) هر مکان روی رادار به جای نقطه ساده!
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        this.minimapBuildings.forEach(b => {
            let bx = tx(b.x), bz = ty(b.z);
            const distFromCenter = Math.hypot(bx - cx, bz - cy);
            const maxR = w / 2 - 13;
            if (distFromCenter > maxR) {
                // چسباندن نماد مکان‌های دور (مثل پارک یا شهربازی) به لبه رادار تا همیشه جهتشان مشخص باشد!
                const ang = Math.atan2(bz - cy, bx - cx);
                bx = cx + Math.cos(ang) * maxR;
                bz = cy + Math.sin(ang) * maxR;
            }
            ctx.fillStyle = 'rgba(15, 23, 42, 0.72)';
            ctx.beginPath();
            ctx.arc(bx, bz, 9.5, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = b.color || '#ffffff';
            ctx.lineWidth = 1.8;
            ctx.stroke();
            ctx.font = '11px sans-serif';
            ctx.fillText(b.icon || '🏢', bx, bz + 1);
        });

        const drawDot = (x, z, col) => {
            const dx = tx(x), dz = ty(z);
            if (Math.hypot(dx - cx, dz - cy) > w / 2 - 8) return;
            ctx.fillStyle = col;
            ctx.beginPath();
            ctx.arc(dx, dz, 4.2, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#fff';
            ctx.lineWidth = 1.2;
            ctx.stroke();
        };
        this.npcList.forEach(n => drawDot(n.rig.mesh.position.x, n.rig.mesh.position.z, '#fde047'));
        this.remoteRigs.forEach(r => drawDot(r.mesh.position.x, r.mesh.position.z, '#4ade80'));

        ctx.save();
        ctx.translate(cx, cy);
        if (this.myRig) ctx.rotate(-this.myRig.mesh.rotation.y + Math.PI);
        ctx.fillStyle = '#38bdf8';
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(0, -9);
        ctx.lineTo(7, 7);
        ctx.lineTo(0, 4);
        ctx.lineTo(-7, 7);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
        ctx.restore();
    }

    checkCollision(nx, nz) {
        const r = 0.42;
        if (this.worldBounds) {
            const b = this.worldBounds;
            if (nx < b.minX + r || nx > b.maxX - r || nz < b.minZ + r || nz > b.maxZ - r) return true;
        }
        const hitBox = (b) => {
            if (b.cx !== undefined) {
                const dx = nx - b.cx;
                const dz = nz - b.cz;
                const c = Math.cos(-b.rot);
                const s = Math.sin(-b.rot);
                const lx = dx * c - dz * s;
                const lz = dx * s + dz * c;
                return Math.abs(lx) < b.hw + r && Math.abs(lz) < b.hd + r;
            }
            return nx > b.minX - r && nx < b.maxX + r && nz > b.minZ - r && nz < b.maxZ + r;
        };
        return this.obstacles.some(hitBox) || this.furnitureObstacles.some(hitBox);
    }

    async start() {
        this.playerState = await bridge.getCharacter();
        document.getElementById('player-name-display').textContent = this.playerState.name;
        this.ui.refreshBitBlox();

        this.myRig = createCharacterRig(this.playerState.name, this.playerState.appearance, null);
        this.scene.add(this.myRig.mesh);
        this.setCharacterMood(this.playerState.appearance.mood || 'happy', false);

        await this.loadZone('plaza');

        const clock = new THREE.Clock();
        const loop = () => {
            requestAnimationFrame(loop);
            const dt = Math.min(clock.getDelta(), 0.1);
            const t = clock.getElapsedTime();

            this.animatedLandmarks.forEach(it => {
                if (it.type === 'spinAndBob') {
                    it.mesh.rotation.y += it.speed * dt;
                    it.mesh.position.y = it.baseY + Math.sin(t * 3) * 0.12;
                } else if (it.type === 'ferris') {
                    it.mesh.rotation.z += it.speed * dt;
                    it.kids.forEach(k => { k.rotation.z = -it.mesh.rotation.z; });
                }
            });

            if (this.weatherPoints.visible) {
                const arr = this.weatherPoints.geometry.attributes.position.array;
                const spd = this.weatherModes[this.weatherIdx] === 'rain' ? 28 * dt : 6 * dt;
                for (let i = 0; i < arr.length; i += 3) {
                    arr[i + 1] -= spd;
                    if (arr[i + 1] < 0) arr[i + 1] = 38;
                }
                this.weatherPoints.geometry.attributes.position.needsUpdate = true;
            }

            if (this.myRig) {
                const isPlaza = this.currentZone === 'plaza';
                const baseY = (isPlaza ? 24.5 : 12.0) * this.camZoom;
                const baseZ = (isPlaza ? 28.5 : 14.2) * this.camZoom;
                const lookZ = isPlaza ? -5.0 : -1.5;
                const camTarget = new THREE.Vector3(this.myRig.mesh.position.x, this.myRig.mesh.position.y + baseY, this.myRig.mesh.position.z + baseZ);
                this.camera.position.lerp(camTarget, 4.5 * dt);
                this.camera.lookAt(this.myRig.mesh.position.x, this.myRig.mesh.position.y + 1.2, this.myRig.mesh.position.z + lookZ);
                this.camera.updateMatrixWorld();
                updateCharacterAnimation(this.myRig, dt, t, this.camera, (x, z) => this.checkCollision(x, z), this.targetRing);

                const btn = document.getElementById('portal-prompt');
                const foundPortal = this.portals.find(p => Math.hypot(this.myRig.mesh.position.x - p.x, this.myRig.mesh.position.z - p.z) < 2.3);
                const foundSeat = !foundPortal && !this.myRig.sitting
                    ? this.seats.find(s => Math.hypot(this.myRig.mesh.position.x - s.x, this.myRig.mesh.position.z - s.z) < 2.4)
                    : null;

                if (foundPortal) {
                    this.activePortal = foundPortal;
                    this.activeSeat = null;
                    btn.textContent = foundPortal.promptLabel;
                    btn.classList.add('visible');
                } else if (this.myRig.sitting) {
                    this.activePortal = null;
                    this.activeSeat = null;
                    btn.textContent = '🚶 بلند شدن از صندلی';
                    btn.classList.add('visible');
                } else if (foundSeat) {
                    this.activePortal = null;
                    this.activeSeat = foundSeat;
                    btn.textContent = foundSeat.label || '🪑 نشستن روی صندلی';
                    btn.classList.add('visible');
                } else if (this.activePortal || this.activeSeat || btn.classList.contains('visible')) {
                    this.activePortal = null;
                    this.activeSeat = null;
                    btn.classList.remove('visible');
                }
            }

            if (this.currentZone === 'plaza') {
                this.updateNpcs(dt, t);
                this.cityLife.update(dt, t, this.camera);
            }
            this.remoteRigs.forEach(r => updateCharacterAnimation(r, dt, t, this.camera, null, null));
            this.renderMiniMap(t);
            this.renderer.render(this.scene, this.camera);
        };
        loop();
        setInterval(() => this.syncWorld(), 2500);
    }
}

new MetaverseApp().start();
