<?php
namespace BastanGraphic\Component\Bloxia\Site\Controller;

use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Factory;
use Joomla\CMS\Session\Session;
use Joomla\CMS\Response\JsonResponse;
use Joomla\CMS\User\User;
use Joomla\CMS\User\UserHelper;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Plugin\PluginHelper;

class AuthController extends BaseController
{
    public function requestOtp()
    {
        Session::checkToken() or die('Invalid Token');
        
        $app = Factory::getApplication();
        $mobile = $app->input->post->getString('mobile', '');

        if (empty($mobile)) {
            echo new JsonResponse(null, 'شماره موبایل نامعتبر است', true);
            $app->close();
        }

        // تولید کد 4 رقمی رندوم امن
        $otp = (string) random_int(1000, 9999);
        
        // ذخیره در سشن برای مرحله بعد همراه با زمان انقضا
        $session = Factory::getSession();
        $session->set('bloxia_temp_mobile', $mobile);
        $session->set('bloxia_temp_otp', $otp);
        $session->set('bloxia_temp_otp_expires', time() + 300);
        $session->set('bloxia_temp_otp_attempts', 0);

        // ارسال کد به فرانت‌اند (فقط برای فاز تستی/Mock)
        echo new JsonResponse(['mock_code' => $otp]);
        $app->close();
    }

    public function verifyOtp()
    {
        Session::checkToken() or die('Invalid Token');
        
        $app = Factory::getApplication();
        $session = Factory::getSession();
        
        $userOtp = trim($app->input->post->getString('otp', ''));
        $savedOtp = $session->get('bloxia_temp_otp');
        $mobile = $session->get('bloxia_temp_mobile');
        $expiresAt = (int) $session->get('bloxia_temp_otp_expires', 0);
        $attempts = (int) $session->get('bloxia_temp_otp_attempts', 0);

        if (empty($savedOtp) || empty($mobile) || time() > $expiresAt) {
            echo new JsonResponse(null, 'کد تایید منقضی شده یا درخواست نشده است', true);
            $app->close();
        }

        if ($attempts >= 5) {
            $session->clear('bloxia_temp_otp');
            echo new JsonResponse(null, 'تعداد تلاش‌های ناموفق بیش از حد مجاز است. لطفاً کد جدید دریافت کنید.', true);
            $app->close();
        }

        if ($userOtp === '' || !hash_equals((string) $savedOtp, $userOtp)) {
            $session->set('bloxia_temp_otp_attempts', $attempts + 1);
            echo new JsonResponse(null, 'کد وارد شده اشتباه است', true);
            $app->close();
        }

        // کد درست بود، حالا کاربر را لاگین یا ثبت‌نام می‌کنیم
        $db = Factory::getContainer()->get('DatabaseDriver');
        
        // آیا این شماره موبایل قبلا ثبت‌نام کرده؟
        $query = $db->getQuery(true)
            ->select('id')
            ->from($db->quoteName('#__users'))
            ->where($db->quoteName('username') . ' = ' . $db->quote($mobile));
            
        $db->setQuery($query);
        $userId = $db->loadResult();

        if (!$userId) {
            // ثبت نام کاربر جدید در جوملا
            $user = new User();
            $user->name = 'کاربر ' . substr($mobile, -4); // اسم موقت
            $user->username = $mobile;
            $user->email = $mobile . '@bloxia.local'; // ایمیل فیک اجباری
            $user->password = UserHelper::hashPassword(UserHelper::genRandomPassword(32));
            $user->set('groups', [2]); // گروه Registered
            $user->save();
            $userId = $user->id;
        } else {
            $user = User::getInstance($userId);
        }

        // لاگین کردن برنامه‌نویسی شده کاربر
        PluginHelper::importPlugin('user');
        $app->triggerEvent('onUserLogin', [
            ['username' => $user->username],
            ['action' => 'core.login.site']
        ]);
        
        $session->set('user', $user);
        $session->clear('bloxia_temp_mobile');
        $session->clear('bloxia_temp_otp');

        // بررسی وضعیت کاربر در دیتابیس
        $query = $db->getQuery(true)
            ->select($db->quoteName('has_onboarded'))
            ->from($db->quoteName('#__bloxia_user_profiles'))
            ->where($db->quoteName('user_id') . ' = ' . (int) $user->id);
            
        $db->setQuery($query);
        $hasOnboarded = $db->loadResult();

        // ساخت پروفایل اولیه اگر نداشت
        if ($hasOnboarded === null) {
            $profile = new \stdClass();
            $profile->user_id = $user->id;
            $profile->bloxia_points = 0;
            $profile->has_onboarded = 0;
            $db->insertObject('#__bloxia_user_profiles', $profile);
        }

        // هدایت یکپارچه به موتور بازی (World)
        $redirectLink = Route::_('index.php?option=com_bloxia&view=world', false);

        echo new JsonResponse(['redirect' => $redirectLink]);
        $app->close();
    }
}